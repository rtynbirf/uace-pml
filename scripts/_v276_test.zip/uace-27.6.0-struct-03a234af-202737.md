# UACE 27.6.0 · PML-STRUCT r1 — отчёт Markdown

- **urlHash:** `abcd1234`
- **Момент:** +12345 мс от старта
- **Viewport:** 1280×800 @dpr 1
- **Соль FNV-1a:** `PMLSTRUCT` · контракт r1+r2

## Каркас (I-1)

maxDepth **9** · blockCount **420**

| тег | роль | путь |
|---|---|---|
| main | — | `body>main` |
| nav | navigation | `body>div>nav` |

### Группы (I-1, скоринг r2 §2)

| sigHash | × | глуб. | однород. | inPrimary | образец |
|---|---|---|---|---|---|
| `f0338710` | 12 | 4 | 0.86 | да | `body>main>ul>li` |

## Скролл (I-2)

primary: `body>main` · ratio **0.2** · 4000/800

| контейнер | scroll/client |
|---|---|
| `body>main` | 4000/800 |

## Мутации (I-3)

окно 60 с · adds 40 · removes 12 · рециклы 5 · медиана 420 мс · поток: да

## Якоря (I-4)


| точка монтажа | режим | h |
|---|---|---|
| `body>header` | fixed | 64 |

стойких путей: 1 · стабильность 0.5

## Резерв (r2 §3)

кандидат `body>main>ul>li` · sigHash `f0338710` · confidence **78**
