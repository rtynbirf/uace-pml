// ==UserScript==
// @name         Universal AI Chat Exporter — Polymat v27.3.0 STYLES+ACCENT
// @namespace    local.universal.ai.exporter
// @version      27.3.0
// @description  STYLES+ACCENT EDITION — слияние двух веток линейки: 5 ГОТОВЫХ стилей PDF/HTML-экспорта по шаблону МАКТ-2026 (Имперский — тёмный фон+золото и кегль 18 для слабого зрения, МАКТ Светлый, Швейцарская сетка, Нео-брутализм, Сепия Вечер; выбор виден в главной панели, дублируется в «Ещё экспорт» и в окне печати, запоминается; PDF силами браузера — векторный текст, 0 CDN; паспорт страницы в каждом экспорте) + весь HUMAN-FIRST UI v27.1 (акцент панели берётся из системы пользователя — CSS Color 4 AccentColor с автоподгонкой контраста ≥4.5:1; сегментный переключатель Авто/Свет/Тьма/Тепло; комфорт-панель; паспорт панели с живым сам-аудитом; контраст ≥4.5:1 без чистого ч/б; кегль 14–21; цели ≥44px; ноль попапов; тёплый вечер; reduced-motion) + движок RESTORED-линии: ZIP DEFLATE (CompressionStream, fallback store), тома 50 МБ, навигация по URL с авто-продолжением сессии (uaice_nav, кап 12), childJob-антишторм дочерних вкладок, origin-чек сообщений, 29+ платформ, 9 форматов, IndexedDB-манифест FNV-1a, onlyNew, Shadow DOM, resume, Alt+E/A/C/S/X/R/T.
// @author       local
// @license      MIT
// @match        *://*/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  const SCRIPT_VER = '27.3.0';
  const UI_ID = 'uaice-273';
  const IS_FRAME = (function () { try { return window.top !== window.self; } catch (e) { return true; } })();

  // PDF-рендер — единственная опциональная CDN-зависимость (с fallback на печать).
  // ZIP — собственная реализация (см. ниже), внешних библиотек не требует.
  const LIBS = {
    html2pdf: [
      'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.12.1/html2pdf.bundle.min.js',
      'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js'
    ]
  };

  function loadScript(urls, globalName) {
    if (globalName && window[globalName]) return Promise.resolve(window[globalName]);
    return new Promise((resolve, reject) => {
      let i = 0;
      const tryNext = () => {
        if (i >= urls.length) return reject(new Error('Не удалось загрузить библиотеку (CSP?)'));
        const s = document.createElement('script');
        s.src = urls[i++];
        s.onload = () => resolve(globalName ? window[globalName] : true);
        s.onerror = () => { s.remove(); tryNext(); };
        (document.head || document.documentElement).appendChild(s);
      };
      tryNext();
    });
  }

  const MSG_REQ = 'UAICE_EXPORT_REQUEST';
  const MSG_RES = 'UAICE_EXPORT_RESULT';

  const CFG = {
    MIN_TEXT: 8, MIN_TOTAL_TEXT: 80, CLICK_WAIT: 800, STABLE_MS: 1200,
    MAX_WAIT: 25000, POLL: 300, SCROLL_ROUNDS: 50, SCROLL_WAIT: 550, TAB_CHILD_TIMEOUT: 65000,
    DEDUPE_CAP: 400, MSG_MIN: 1, MSG_MAX: 800, IMG_PER_MSG: 40, IMG_TOTAL: 60, IMG_TIMEOUT: 10000,
    SNAPSHOT_MAX: 200000, ADAPTIVE: true, BASE_CLICK: 800, BASE_SCROLL: 550, BASE_POLL: 300,
    MAX_CLICK: 1800, MAX_SCROLL: 900, IMG_RETRIES: 3, MAX_ZIP_MB: 50, ARTIFACTS_MAX: 100
  };

  const FORMATS = ['md', 'json', 'txt', 'html', 'pdf', 'zip', 'sharegpt', 'jsonl', 'alpaca'];

  let CANCEL = false;
  let busy = false;
  let tabsExportRunning = false;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ts = () => now().replace(/[: ]/g, '-');
  function safeStorageGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function safeStorageSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function safeStorageRemove(k) { try { localStorage.removeItem(k); } catch (e) {} }

  // ============ v26 POLYMATH: АДАПТИВНЫЕ ЗАДЕРЖКИ ============
  function isPageBusy() {
    try { return document.querySelectorAll('[class*="loading"],[class*="spinner"],[class*="busy"],[aria-busy="true"],[data-loading="true"]').length > 0; } catch (e) { return false; }
  }
  function adaptiveMs(base, maxCap) {
    const enabled = (safeStorageGet('uaice_adaptive') !== '0') && CFG.ADAPTIVE;
    if (!enabled) return base;
    const v = Math.round(base * (isPageBusy() ? 2.1 : 1));
    return maxCap ? Math.min(v, maxCap) : v;
  }
  function clickWait() { return adaptiveMs(CFG.BASE_CLICK || CFG.CLICK_WAIT, CFG.MAX_CLICK); }
  function scrollWait() { return adaptiveMs(CFG.BASE_SCROLL || CFG.SCROLL_WAIT, CFG.MAX_SCROLL); }
  function pollWait() { return adaptiveMs(CFG.BASE_POLL || CFG.POLL, 800); }

  // ============ v26 POLYMATH: INDEXEDDB (манифест без лимита ~5 МБ) ============
  const HAS_IDB = (function () { try { return typeof indexedDB !== 'undefined' && !!indexedDB.open; } catch (e) { return false; } })();
  const IDB_NAME = 'UAICE_POLYMATH_DB';
  const IDB_STORE_MAN = 'manifest';
  let _idbPromise = null;
  function idbOpen() {
    if (_idbPromise) return _idbPromise;
    _idbPromise = new Promise((resolve, reject) => {
      try {
        const req = indexedDB.open(IDB_NAME, 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(IDB_STORE_MAN)) db.createObjectStore(IDB_STORE_MAN, { keyPath: 'id' });
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => reject(req.error || new Error('IDB open failed'));
      } catch (e) { reject(e); }
    });
    return _idbPromise;
  }
  function idbRun(store, mode, fn) {
    return idbOpen().then((db) => new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(store, mode);
        const out = fn(tx.objectStore(store));
        tx.oncomplete = () => resolve(out && out.result !== undefined ? out.result : null);
        tx.onerror = () => reject(tx.error || new Error('IDB tx failed'));
      } catch (e) { reject(e); }
    }));
  }
  function idbGetAll() { return HAS_IDB ? idbRun(IDB_STORE_MAN, 'readonly', (s) => s.getAll()).catch(() => []) : Promise.resolve([]); }
  function idbPutMany(arr) { return HAS_IDB ? idbRun(IDB_STORE_MAN, 'readwrite', (s) => { for (let i = 0; i < arr.length; i++) s.put(arr[i]); }).catch(() => {}) : Promise.resolve(); }
  function idbClearMan() { return HAS_IDB ? idbRun(IDB_STORE_MAN, 'readwrite', (s) => s.clear()).catch(() => {}) : Promise.resolve(); }

  function now() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }
  function sanitize(s, m) {
    m = m || 80;
    const raw = String(s || 'export');
    const norm = raw.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim();
    let out = norm.slice(0, m);
    // v26: имя длиннее лимита получает хеш-суффикс (анти-дубликат на Windows/FS)
    if (norm.length > m) out += '-' + hashString(raw).slice(0, 6);
    return out || 'export';
  }
  function pageTitle() {
    let t = (document.title || '').trim();
    t = t.replace(/\s*[-–|·]\s*[^-–|·]{0,40}$/i, '').trim();
    return t.length > 1 ? t.slice(0, 120) : 'export';
  }
  // Схлопывание повторяющегося текста (артефакт виртуализированного DOM): "abcabcabc" -> "abc"
  function dedupeText(s) {
    s = String(s || '');
    if (s.length < 6 || s.length > 400) return s;
    for (let n = 2; n <= 4; n++) {
      if (s.length % n !== 0) continue;
      const chunk = s.slice(0, s.length / n);
      if (!chunk) continue;
      let rep = true;
      for (let i = 1; i < n; i++) { if (s.slice(i * chunk.length, (i + 1) * chunk.length) !== chunk) { rep = false; break; } }
      if (rep) return chunk;
    }
    return s;
  }
  // Срезание UI-обёрток перед текстом ("Ваш запрос", "Ответ Gemini", "You said" и т.п.)
  function stripUiPrefix(text) {
    if (!text) return text;
    const lines = String(text).split('\n');
    let i = 0;
    while (i < lines.length) {
      const st = lines[i].replace(/^#+\s*/, '').trim();
      if (/^(Ответ\s+\S+|Ваш\s+запрос|Gemini|You\s+said|ChatGPT\s+said|Assistant\s+said|User\s+said|DeepSeek|Claude|Grok|Kimi|Qwen|Mistral|Copilot|GPT)$/i.test(st)) {
        i++;
        while (i < lines.length && !lines[i].trim()) i++;
      } else break;
    }
    return lines.slice(i).join('\n').trim();
  }
  // Прогресс-бар в строке статуса: [█████·----] 3/10 Заголовок
  function progress(i, n, label) {
    const f = Math.max(0, Math.min(10, Math.round(10 * (i) / Math.max(1, n))));
    return '[' + '█'.repeat(f) + '·'.repeat(10 - f) + '] ' + (i + 1) + '/' + n + ' ' + (label || '');
  }

  // ============ ПЛАТФОРМЫ (28 из v22.1.7 + Dola; хосты расширены из v24) ============
  const PLATFORMS = [
    { name: 'ChatGPT', hosts: [/(^|\.)(chatgpt\.com|chat\.openai\.com)$/],
      msgSelectors: ['[data-message-author-role]', 'article[data-testid^="conversation-turn"]'],
      roleAttr: 'data-message-author-role', chatUrlPattern: '/c/{id}',
      sidebarSelectors: ['#stage-slideover-sidebar', 'nav[aria-label*="Chat" i]', 'nav', 'aside'] },
    { name: 'Claude', hosts: [/(^|\.)claude\.ai$/],
      msgSelectors: ['[data-testid="user-message"]', '[data-testid="assistant-message"]', '.font-claude-message', '.font-user-message'],
      role: (el) => el.matches('[data-testid="user-message"], .font-user-message') ? 'user' : 'assistant',
      chatUrlPattern: '/chat/{id}' },
    { name: 'Gemini', hosts: [/(^|\.)(gemini\.google\.com|bard\.google\.com)$/],
      msgSelectors: ['user-query', 'model-response', 'conversation-turn', 'ms-chat-turn'],
      role: (el) => {
        const t = el.tagName.toLowerCase();
        if (t === 'user-query') return 'user';
        if (t === 'model-response') return 'assistant';
        return /user|query|human/i.test(el.className || '') ? 'user' : 'assistant';
      },
      chatUrlPattern: '/app/{id}', sidebarSelectors: ['side-navigation-v2', 'bard-sidenav', 'mat-sidenav'] },
    { name: 'Google AI Studio', hosts: [/(^|\.)aistudio\.google\.com$/],
      msgSelectors: ['[data-test-id="user-message"]', '[data-test-id="model-message"]', 'ms-chat-turn'],
      role: (el) => (el.getAttribute('data-role') || '') === 'user' ? 'user' : 'assistant' },
    { name: 'DeepSeek', hosts: [/(^|\.)deepseek\.com$/],
      msgSelectors: ['[class*="message"]', '[class*="_message"]'],
      role: (el) => /user|human|query/i.test(el.className || '') ? 'user' : 'assistant',
      chatUrlPattern: '/a/chat/s/{id}',
      sidebarSelectors: ['aside', 'nav', '[class*="sidebar"]', '[class*="sider"]', '[class*="history"]'] },
    { name: 'Qwen', hosts: [/(^|\.)(qwen\.ai|tongyi\.aliyun\.com)$/],
      msgSelectors: ['[class*="_message"]', '[data-message-role]', '[class*="chat-message"]', '[class*="markdown"]'],
      role: (el) => {
        const c = (el.className || '') + ' ' + (el.getAttribute('data-message-role') || '') + ' ' + (el.getAttribute('data-role') || '');
        if (/user|human|question/i.test(c)) return 'user';
        if (/assistant|bot|ai|model|response/i.test(c)) return 'assistant';
        return 'unknown';
      },
      chatUrlPattern: '/c/{id}',
      sidebarSelectors: ['.sidebar-side', '.session-list-wrapper', 'a[aria-label="chat-item"]', 'a.chat-item-drag-link', '[class*="sidebar"]', 'aside', 'nav'] },
    { name: 'Kimi', hosts: [/(^|\.)(kimi\.moonshot\.cn|kimi\.ai|kimi\.com)$/],
      msgSelectors: ['.segment', '.segment-container', '[class*="message"]'],
      role: (el) => /user|human/i.test((el.className || '') + ' ' + (el.getAttribute('data-role') || '')) ? 'user' : 'assistant',
      sidebarSelectors: ['aside', 'nav', '.next-sidebar', '[class*="sidebar"]'] },
    { name: 'MiniMax', hosts: [/(^|\.)(minimax\.io|minimaxi\.com)$/],
      msgSelectors: ['[class*="message"]', '[class*="chat-item"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Mistral Le Chat', hosts: [/(^|\.)mistral\.ai$/],
      msgSelectors: ['[data-message-role]', '[class*="Message"]', '[class*="message"]'],
      role: (el) => {
        const r = el.getAttribute('data-message-role') || '';
        if (/user/i.test(r)) return 'user';
        if (/assistant/i.test(r)) return 'assistant';
        return /user/i.test(el.className || '') ? 'user' : 'assistant';
      } },
    { name: 'Groq', hosts: [/(^|\.)groq\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'OpenRouter', hosts: [/(^|\.)openrouter\.ai$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'HuggingChat', hosts: [/(^|\.)huggingface\.co$/], path: /^\/chat/,
      msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'NVIDIA NIM', hosts: [/(^|\.)build\.nvidia\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Z.ai', hosts: [/(^|\.)(z\.ai|chatglm\.cn|space-z\.ai)$/],
      msgSelectors: ['[data-role="user"]', '[data-role="assistant"]', '[data-message-role]', '[class*="UserMessage"]', '[class*="AssistantMessage"]', '[class*="message"]', '[class*="chat-message"]'],
      role: (el) => {
        const e = el.getAttribute('data-role') || el.getAttribute('data-message-role') || '';
        if (e) return /user|human/i.test(e) ? 'user' : 'assistant';
        return /user|human/i.test(el.className || '') ? 'user' : 'assistant';
      },
      chatUrlPattern: '/c/{id}',
      sidebarSelectors: ['.chat-aside', '.chat-history-list', '[class*="chat-aside"]', '[class*="chat-history"]', 'aside', 'nav'] },
    { name: 'Pollinations', hosts: [/(^|\.)pollinations\.ai$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Puter', hosts: [/(^|\.)puter\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Open WebUI', hosts: [/openwebui/, /^localhost(?::\d+)?$/, /^127\.0\.0\.1(?::\d+)?$/],
      msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Cloudflare AI', hosts: [/(^|\.)playground\.ai\.cloudflare\.com$/],
      msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Grok', hosts: [/(^|\.)grok\.com$/], msgSelectors: ['[class*="message"]', '[class*="message-bubble"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant',
      chatUrlPattern: '/c/{id}', sidebarSelectors: ['aside', 'nav', '[class*="sidebar"]', '[class*="sidebar-group"]'] },
    { name: 'Microsoft Copilot', hosts: [/(^|\.)copilot\.microsoft\.com$/],
      msgSelectors: ['[class*="message"]', '[class*="turn"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Perplexity', hosts: [/(^|\.)perplexity\.ai$/],
      msgSelectors: ['[class*="query"]', '[class*="answer"]', '[class*="message"]'],
      role: (el) => /query|user|human/i.test(el.className || '') ? 'user' : 'assistant',
      chatUrlHints: [/\/search\//] },
    { name: 'Poe', hosts: [/(^|\.)poe\.com$/],
      msgSelectors: ['[class*="human-message"]', '[class*="chat-message"]', '[class*="message"]'],
      role: (el) => /human|user/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Character.ai', hosts: [/(^|\.)character\.ai$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'You.com', hosts: [/(^|\.)you\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Doubao', hosts: [/(^|\.)doubao\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Tencent Yuanbao', hosts: [/(^|\.)yuanbao\.tencent\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Meta AI', hosts: [/(^|\.)meta\.ai$/], msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Yandex Alice AI', hosts: [/(^|\.)alice\.yandex\.ru$/],
      msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Yandex Alice (path)', hosts: [/(^|\.)yandex\.(ru|com)$/], path: /\/alice\//i,
      msgSelectors: ['[class*="message"]', '[class*="chat"]'],
      role: (el) => /user|human/i.test(el.className || '') ? 'user' : 'assistant' },
    { name: 'Dola', hosts: [/(^|\.)dola\.com$/], msgSelectors: ['[class*="message"]', '[class*="chat-message"]', '[class*="message-list"] > *', '[class*="v_list"]'],  // + сниффер 2026-09-18: контейнер списка и строки v_list
      role: (el) => {
        const c = (el.className || '').toLowerCase();
        if (/user|human|question/i.test(c)) return 'user';
        if (/bot|assistant|ai|response|reply/i.test(c)) return 'assistant';
        return 'unknown';
      },
      chatUrlPattern: '/chat/{id}',
      sidebarSelectors: ['#flow_chat_sidebar', 'nav[class*="panel-"]', '[class*="conversation-item"]', 'nav', 'aside'] }
  ];

  function getPlatform() {
    const host = location.host, path = location.pathname;
    for (const p of PLATFORMS) {
      let ok = false;
      for (const re of p.hosts) { try { if (re.test(host)) { ok = true; break; } } catch (e) {} }
      if (!ok) continue;
      if (p.path) { try { if (!p.path.test(path)) continue; } catch (e) {} }
      return p;
    }
    return null;
  }

  // ============ DOM-ХЕЛПЕРЫ И ФИЛЬТРЫ ============
  const SKIP_TAGS = new Set(['STYLE','SCRIPT','LINK','META','NOSCRIPT','TEMPLATE','HEAD','TITLE','BASE','HTML','SVG','PATH','G','DEFS','MAT-ICON','BR','HR']);
  const HARD_EXCLUDE = '#' + UI_ID + ',[class*="tooltip"]:not([class*="content"]),[class*="popover"]:not([class*="content"])';
  const CHAT_AREA = 'div.chat-container,#chat-history,[data-test-id="chat-history-container"],conversation-container,div.conversation-container,ms-chat-turn,[class*="chat-history-scroll"],[class*="turn-content"],main,[role="main"]';

  function isInHardExclude(el) {
    let p = el, d = 0;
    while (p && p !== document.body && d < 15) {
      try { if (p.matches && p.matches(HARD_EXCLUDE)) return true; } catch (e) {}
      p = p.parentElement; d++;
    }
    return false;
  }
  function isInNavigation(el) {
    let p = el, d = 0;
    while (p && p !== document.body && d < 12) {
      const tag = p.tagName ? p.tagName.toLowerCase() : '';
      const role = p.getAttribute ? (p.getAttribute('role') || '') : '';
      if (tag === 'nav' || tag === 'aside' || role === 'navigation') return true;
      if (tag === 'mat-sidenav' || tag === 'bard-sidenav' || tag === 'side-navigation-v2') return true;
      const c = (typeof p.className === 'string' ? p.className : (p.className && p.className.baseVal) || '').toLowerCase();
      if (/(^|[-_ ])(sidebar|sidenav|side-nav|drawer|chat-list|conversation-list|history-list|nav-|panel-left)([-_ ]|$)/.test(c)) return true;
      p = p.parentElement; d++;
    }
    return false;
  }
  function isInChatArea(el) {
    if (!el || !el.closest) return false;
    try { if (el.closest('aside, nav, [role="navigation"], [class*="sidebar"], [class*="sider"]')) return false; } catch (e) {}
    try { return !!el.closest(CHAT_AREA); } catch (e) { return false; }
  }
  function cls(el) { if (!el || !el.className) return ''; const c = el.className; return (typeof c === 'string' ? c : c.baseVal || '').toLowerCase(); }
  function clean(s) {
    return String(s || '').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\u00A0/g, ' ')
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  function txt(el) {
    if (!el || SKIP_TAGS.has(el.tagName)) return '';
    let out = '';
    try { const x = el.innerText; if (x && x.trim()) out = x.trim(); } catch (e) {}
    if (!out) out = (el.textContent || '').trim();
    return dedupeText(out);
  }
  function isCssOrJs(s) {
    if (!s) return false;
    const head = s.slice(0, 800);
    if (/_ngcontent|_nghost/.test(head)) return true;
    const decl = (head.match(/[a-z-]+\s*:\s*[^;{}\n]+\s*[;\n]/gi) || []).length;
    if (!decl) return false;
    const lines = head.split('\n').filter((l) => l.trim()).length || 1;
    const hasBraces = /[{}]/.test(head);
    if (hasBraces && decl >= 5 && decl / lines > 0.5) return true;
    if (/@media|@font-face|@keyframes/.test(head) && decl >= 3) return true;
    return false;
  }
  function isSourceListing(s) {
    if (!s || s.length > 400) return false;
    if (/\d+\s*(источник|источника|источников|source|sources)/i.test(s)) return true;
    if (/\d+\s*(дн\.|день|дня|дней|day|days)\s*(назад|ago)/i.test(s)) return true;
    if (/только для скачивания/i.test(s)) return true;
    return false;
  }
  function isVisible(el) { try { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; } catch (e) { return true; } }

  function dedupeNested(els) {
    let arr = Array.from(els);
    if (arr.length > CFG.DEDUPE_CAP) arr = arr.slice(0, CFG.DEDUPE_CAP);
    const isContainer = new Set();
    for (const x of arr) {
      const held = arr.filter((y) => y !== x && x.contains(y) && !arr.some((z) => z !== x && z !== y && z.contains(y) && x.contains(z)));
      if (held.length >= 2) isContainer.add(x);
    }
    const drop = new Set();
    for (const x of arr) {
      if (isContainer.has(x)) continue;
      for (const y of arr) { if (y !== x && y.contains(x) && !isContainer.has(y)) { drop.add(x); break; } }
    }
    return arr.filter((e) => !drop.has(e) && !isContainer.has(e));
  }

  // ============ SHADOW DOM: обход открытых shadow-корней (с TTL-кэшем) ============
  let _srCache = null, _srCacheAt = 0;
  function collectShadowRoots(root) {
    const roots = [];
    const seen = new Set();
    const nowMs = Date.now();
    const cached = (!root && _srCache && (nowMs - _srCacheAt) < 1500) ? _srCache : null;
    if (cached) return cached.slice();
    const walk = (r) => {
      if (!r || seen.has(r)) return;
      seen.add(r);
      let all;
      try { all = r.querySelectorAll('*'); } catch (e) { return; }
      for (let i = 0; i < all.length; i++) {
        const sr = all[i].shadowRoot;
        if (sr) { roots.push(sr); walk(sr); }
      }
    };
    try { walk(root || document); } catch (e) {}
    if (!root) { _srCache = roots; _srCacheAt = nowMs; }
    return roots;
  }
  // querySelectorAll по документу + всем открытым shadow-корням (в порядке появления)
  function deepQueryAll(sel, root) {
    const scopes = [root || document].concat(collectShadowRoots(root));
    const out = [];
    for (const sc of scopes) {
      let found;
      try { found = sc.querySelectorAll(sel); } catch (e) { continue; }
      for (const el of found) if (out.indexOf(el) === -1) out.push(el);
    }
    return out;
  }

  function roleFromValue(v) {
    const x = String(v || '').toLowerCase().trim();
    if (/^(user|human|you|me|client|prompt|question|query)$/.test(x)) return 'user';
    if (/^(assistant|bot|ai|model|response|answer|reply)$/.test(x)) return 'assistant';
    if (/(^|[-_ ])(user|human|query|prompt|question)([-_ ]|$)/.test(x)) return 'user';
    if (/(^|[-_ ])(assistant|bot|model|response|answer|reply)([-_ ]|$)/.test(x)) return 'assistant';
    return null;
  }

  function detectRole(el, platform) {
    if (platform && platform.roleAttr) { const v = roleFromValue(el.getAttribute(platform.roleAttr)); if (v) return v; }
    if (platform && typeof platform.role === 'function') { try { const r = platform.role(el); if (r === 'user' || r === 'assistant') return r; } catch (e) {} }
    if (el.tagName) {
      const tag = el.tagName.toLowerCase();
      if (tag === 'user-query') return 'user';
      if (tag === 'model-response') return 'assistant';
    }
    const score = { user: 0, assistant: 0 };
    const nodes = [el]; let p = el.parentElement;
    for (let i = 0; i < 5 && p; i++, p = p.parentElement) nodes.push(p);
    for (let ni = 0; ni < nodes.length; ni++) {
      const n = nodes[ni]; const w = ni === 0 ? 1 : 0.6;
      for (const a of n.attributes || []) {
        const name = a.name.toLowerCase(), value = String(a.value || '').toLowerCase();
        if (/role|author|sender|speaker|type|side|from/i.test(name)) {
          if (/user|human|you\b|me\b|client|question|prompt|query/i.test(value)) score.user += 8 * w;
          if (/assistant|bot|model|response|answer|reply/i.test(value)) score.assistant += 8 * w;
        }
      }
      const r1 = roleFromValue(cls(n));
      if (r1) score[r1] += (ni === 0 ? 6 : 4) * w;
    }
    if (el.querySelector && el.querySelector('[class*="markdown"],[class*="prose"],.katex')) score.assistant += 5;
    if (score.user >= score.assistant + 4 && score.user >= 5) return 'user';
    if (score.assistant >= score.user + 4 && score.assistant >= 5) return 'assistant';
    return 'unknown';
  }

  function filterValid(found) {
    const valid = [];
    found.forEach((el) => {
      if (isInHardExclude(el)) return;
      if (isInNavigation(el)) return;
      if (!isVisible(el)) return;
      const t = txt(el);
      if (!t || t.length < CFG.MIN_TEXT) return;
      if (isCssOrJs(t) || isSourceListing(t)) return;
      valid.push(el);
    });
    return valid;
  }

  // ============ ПОИСК СООБЩЕНИЙ ============
  function findMessages() {
    const platform = getPlatform();
    const UNIVERSAL = ['[data-message-author-role]','[data-testid="user-message"]','[data-testid="assistant-message"]','user-query','model-response','.segment','.segment-container','[data-message-role]','[data-message-id]','[class*="UserMessage"]','[class*="AssistantMessage"]','[class*="user-message"]:not([class*="input"]):not([class*="fixed"])','[class*="assistant-message"]:not([class*="input"]):not([class*="fixed"])','[class*="Message_container"]','[class*="MessageContainer"]','div.conversation-container'];
    const trySel = (sel) => {
      let found = deepQueryAll(sel);
      if (!found || found.length < 1) return null;
      const valid = dedupeNested(filterValid(found));
      return valid.length ? valid : null;
    };
    if (platform) {
      for (let i = 0; i < platform.msgSelectors.length; i++) {
        const valid = trySel(platform.msgSelectors[i]);
        if (valid && (i === 0 ? valid.length >= 2 : valid.length >= CFG.MSG_MIN)) {
          return { items: valid.slice(0, CFG.MSG_MAX), source: platform.msgSelectors[i], platform: platform };
        }
      }
      let best = null, bestSel = '';
      for (const sel of platform.msgSelectors.concat(UNIVERSAL)) {
        const valid = trySel(sel);
        if (valid && valid.length > (best ? best.length : 0)) { best = valid; bestSel = sel; }
      }
      if (best) return { items: best.slice(0, CFG.MSG_MAX), source: bestSel, platform: platform };
    }
    let best = null, bestSel = '';
    for (const sel of UNIVERSAL) {
      const valid = trySel(sel);
      if (valid && valid.length > (best ? best.length : 0)) { best = valid; bestSel = sel; }
    }
    if (best) return { items: best.slice(0, CFG.MSG_MAX), source: bestSel, platform: platform };

    // Эвристика: крупнейшая группа однотипных детей основного контейнера (из v20)
    const heur = heuristicMessages();
    if (heur && heur.length >= 2) return { items: heur.slice(0, CFG.MSG_MAX), source: 'heuristic', platform: platform };
    return null;
  }

  function heuristicMessages() {
    const containers = deepQueryAll('main, article, section, [role="main"], [class*="conversation"], [class*="chat"]');
    let best = null;
    for (const c of containers) {
      const groups = {};
      Array.from(c.children || []).forEach((child) => {
        const key = child.tagName + '|' + (typeof child.className === 'string' ? child.className : '').split(/\s+/).slice(0, 3).join(' ');
        (groups[key] = groups[key] || []).push(child);
      });
      for (const key of Object.keys(groups)) {
        const group = dedupeNested(filterValid(groups[key]));
        if (group.length >= 3 && (!best || group.length > best.length)) best = group;
      }
      // второй уровень: внуки (виртуализированные списки)
      Array.from(c.children || []).forEach((mid) => {
        Array.from(mid.children || []).forEach((child) => {
          const key = child.tagName + '|' + (typeof child.className === 'string' ? child.className : '').split(/\s+/).slice(0, 3).join(' ');
          (groups['@' + key] = groups['@' + key] || []).push(child);
        });
      });
      for (const key of Object.keys(groups)) {
        if (!/^@/.test(key)) continue;
        const group = dedupeNested(filterValid(groups[key]));
        if (group.length >= 3 && (!best || group.length > best.length)) best = group;
      }
    }
    return best;
  }

  // ============ ТЕКСТ / MARKDOWN ============
  let renderHolder = null;
  function getRenderHolder() {
    if (!renderHolder || !renderHolder.isConnected) {
      renderHolder = document.createElement('div');
      renderHolder.style.cssText = 'position:fixed;left:-10000px;top:0;width:900px;pointer-events:none;opacity:0;z-index:-1;white-space:normal;';
      (document.body || document.documentElement).appendChild(renderHolder);
    }
    return renderHolder;
  }
  // Клон присоединяется к скрытому держателю в документе — innerText считает переносы корректно.
  function extractText(el) {
    const clone = el.cloneNode(true);
    const remove = clone.querySelectorAll('style,script,link,meta,noscript,template,svg,button,nav,footer,[role="button"],[role="toolbar"],.sr-only,time,[class*="timestamp"],[class*="copy-button"],[class*="action-bar"],[class*="toolbar"],[class*="feedback"],[class*="rating"],mat-icon,[class*="icon"]:not([class*="content"]),[data-icon],i[class*="fa-"]');
    for (let i = 0; i < remove.length; i++) remove[i].remove();
    const holder = getRenderHolder();
    holder.appendChild(clone);
    let t = '';
    try { t = clean(clone.innerText || ''); } catch (e) { t = (clone.textContent || '').trim(); }
    clone.remove();
    return t;
  }

  const MD_REMOVE = 'style,script,link,meta,noscript,template,svg,button,nav,footer,header,[role="button"],[role="toolbar"],[aria-hidden="true"],.sr-only,time,[class*="timestamp"],[class*="copy-button"],[class*="action-bar"],[class*="toolbar"],[class*="feedback"],[class*="rating"],mat-icon,[data-icon]';

  // v25.0.1: вычистка хрома код-виджетов (язык «python», кнопки «Run/Copy»),
  // которые рендерятся div/span-ами рядом с <pre> и не ловятся MD_REMOVE.
  // Правило: элемент/текстовый узел-сосед pre удаляется, только если он состоит
  // ТОЛЬКО из токенов-хрома (названия языков и подписки кнопок). React-DOM не
  // вставляет пробелов между span-ами, поэтому «pythonRunCopy» — тоже хром.
  // Проза вида «Run the code» / «Код на Python это круто» не трогается.
  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  const CHROME_TOKENS = ['python', 'python3', 'javascript', 'js', 'typescript', 'ts', 'jsx', 'tsx', 'java', 'c', 'c++', 'cpp', 'csharp', 'cs', 'go', 'golang', 'rust', 'ruby', 'php', 'swift', 'kotlin', 'scala', 'bash', 'sh', 'shell', 'zsh', 'powershell', 'sql', 'html', 'css', 'scss', 'less', 'json', 'json5', 'yaml', 'yml', 'xml', 'toml', 'ini', 'markdown', 'md', 'text', 'txt', 'plaintext', 'perl', 'r', 'matlab', 'dart', 'lua', 'groovy', 'objc', 'objectivec', 'pascal', 'fortran', 'haskell', 'elixir', 'erlang', 'clojure', 'vb', 'vba', 'asm', 'assembly', 'wasm', 'graphql', 'dockerfile', 'makefile', 'diff', 'mermaid', 'run', 'copy', 'код', 'язык', 'запустить', 'выполнить', 'копировать', 'показать', 'скрыть', 'свернуть', 'развернуть', 'collapse', 'expand', 'toggle', 'wrap', 'nowrap', 'edit', 'done', 'save', 'share', 'download'];
  const CHROME_TOKENS_SORTED = CHROME_TOKENS.slice().sort((a, b) => b.length - a.length);
  const CHROME_ALT = CHROME_TOKENS_SORTED.map(escapeRe).join('|');
  const CHROME_TOKEN_PREFIX_RE = new RegExp('^(?:' + CHROME_ALT + ')', 'i');
  const CHROME_TOKEN_FULL_RE = new RegExp('^(?:' + CHROME_ALT + ')$', 'i');
  function isChromeText(t) {
    const s = String(t || '').trim();
    if (!s || s.length > 40) return false;
    const words = s.split(/\s+/);
    if (words.length <= 4 && words.every((w) => CHROME_TOKEN_FULL_RE.test(w))) return true;
    let rest = s.toLowerCase(), guard = 0;
    while (rest.length && guard++ < 10) {
      const m = rest.match(CHROME_TOKEN_PREFIX_RE);
      if (!m) return false;
      rest = rest.slice(m[0].length);
    }
    return rest.length === 0;
  }
  function stripCodeChrome(root) {
    let pres;
    try { pres = Array.from(root.querySelectorAll('pre')); } catch (e) { return; }
    for (const pre of pres) {
      let anc = pre.parentElement;
      for (let lvl = 0; anc && lvl < 2; lvl++) {
        const kids = Array.from(anc.childNodes || []);
        for (const k of kids) {
          if (k.nodeType === 3) { if (isChromeText(k.nodeValue)) k.nodeValue = ''; continue; }
          if (k.nodeType !== 1 || k === pre) continue;
          const tag = (k.tagName || '').toLowerCase();
          if (tag === 'pre' || tag === 'code') continue;
          try { if (k.contains && k.contains(pre)) continue; } catch (e) {}
          if (isChromeText(k.textContent) && typeof k.remove === 'function') k.remove();
        }
        anc = anc.parentElement;
      }
    }
  }

  // v26: Mermaid-диаграммы → ссылка на SVG-рендер (mermaid.ink), zero-dependency
  function mermaidEnabled() { return safeStorageGet('uaice_mermaid') !== '0'; }
  function processMermaid(content) {
    const s = String(content || '');
    if (s.indexOf('```mermaid') === -1) return s;
    return s.replace(/```mermaid\r?\n([\s\S]*?)```/gi, (match, code) => {
      try {
        const src = String(code).trim();
        if (!src || src.length > 50000) return match;
        const b64 = btoa(unescape(encodeURIComponent(src)));
        return match + '\n\n> 📊 [SVG-диаграмма](https://mermaid.ink/svg/' + b64 + ')\n';
      } catch (e) { return match; }
    });
  }

  function domToMarkdown(el) {
    const root = el.cloneNode(true);
    let rm;
    try { rm = root.querySelectorAll(MD_REMOVE); } catch (e) { rm = []; }
    for (let i = 0; i < rm.length; i++) rm[i].remove();
    stripCodeChrome(root);
    // v26: KaTeX/MathJax → LaTeX-математика в markdown. ВАЖНО: до MD_REMOVE,
    // иначе annotation[aria-hidden] вычищается и формула теряется целиком.
    try {
      const maths = root.querySelectorAll('.katex, .katex-display, mjx-container, math[alttext]');
      for (let mi = 0; mi < maths.length; mi++) {
        const mn = maths[mi];
        if (!mn.parentElement || (root.contains && !root.contains(mn))) continue;
        let tex = '';
        const ann = mn.querySelector('annotation[encoding="application/x-tex"]');
        if (ann && ann.textContent) tex = ann.textContent.trim();
        if (!tex && mn.getAttribute) tex = mn.getAttribute('alttext') || '';
        if (!tex) continue;
        const display = (mn.classList && mn.classList.contains('katex-display')) || mn.getAttribute('display') === 'block';
        const doc = root.ownerDocument || document;
        mn.parentElement.replaceChild(doc.createTextNode(display ? '\n\n$$' + tex + '$$\n\n' : ' $' + tex + '$ '), mn);
      }
    } catch (e) {}
    function children(node) { return Array.from(node.childNodes || []).map(walk).join(''); }
    function walk(node) {
      if (node.nodeType === 3) return node.nodeValue || '';
      if (node.nodeType !== 1) return '';
      const tag = node.tagName.toLowerCase();
      if (tag === 'script' || tag === 'style' || tag === 'svg' || tag === 'noscript') return '';
      if (tag === 'br') return '\n';
      if (tag === 'hr') return '\n\n---\n\n';
      if (tag === 'pre') {
        const code = node.querySelector('code');
        const lang = code && code.className && (code.className.match(/language-([\w-]+)/) || [])[1] || '';
        const text = (code ? code.textContent : node.textContent) || '';
        return '\n\n```' + lang + '\n' + String(text).replace(/\r\n/g, '\n').replace(/\n+$/, '') + '\n```\n\n';
      }
      if (tag === 'code') return '`' + clean(node.textContent) + '`';
      if (tag === 'img') { const src = node.getAttribute('src') || ''; if (!src) return ''; return '![' + (node.getAttribute('alt') || '') + '](' + src + ')'; }
      if (tag === 'a') { const href = node.getAttribute('href') || ''; const v = clean(children(node)); return href ? '[' + (v || href) + '](' + href + ')' : v; }
      if (/^h[1-6]$/.test(tag)) return '\n\n' + '#'.repeat(Number(tag[1])) + ' ' + clean(children(node)) + '\n\n';
      if (tag === 'strong' || tag === 'b') { const v = clean(children(node)); return v ? '**' + v + '**' : ''; }
      if (tag === 'em' || tag === 'i') { const v = clean(children(node)); return v ? '*' + v + '*' : ''; }
      if (tag === 'del' || tag === 's') { const v = clean(children(node)); return v ? '~~' + v + '~~' : ''; }
      if (tag === 'blockquote') { const v = clean(children(node)); return '\n\n' + v.split('\n').map((l) => '> ' + l).join('\n') + '\n\n'; }
      if (tag === 'li') { const ordered = node.parentElement && node.parentElement.tagName.toLowerCase() === 'ol'; return (ordered ? '1. ' : '- ') + clean(children(node)) + '\n'; }
      if (tag === 'ul' || tag === 'ol') {
        // v25.0.1: настоящая нумерация <ol> вместо «1. 1. 1.»
        const ordered = tag === 'ol';
        let lis = [];
        try { lis = Array.from(node.children || []).filter((c) => c && c.tagName && c.tagName.toLowerCase() === 'li'); } catch (e) {}
        if (lis.length) {
          const body = lis.map((li, i) => (ordered ? (i + 1) + '. ' : '- ') + clean(children(li)) + '\n').join('');
          return '\n\n' + body + '\n';
        }
        return '\n\n' + children(node) + '\n';
      }
      if (tag === 'table') return tableToMarkdown(node);
      if (tag === 'p' || tag === 'div' || tag === 'section' || tag === 'article' || tag === 'figure') return '\n' + children(node) + '\n';
      return children(node);
    }
    function tableToMarkdown(table) {
      let rows;
      try { rows = Array.from(table.querySelectorAll('tr')); } catch (e) { return ''; }
      if (!rows.length) return '';
      // v26: поддержка colspan — объединённые ячейки дополняются пустыми, колонки не уезжают
      const matrix = rows.map((row) => {
        const cells = [];
        try {
          Array.from(row.querySelectorAll('th,td')).forEach((cell) => {
            const t = clean(cell.innerText || cell.textContent || '').replace(/\|/g, '\\|').replace(/\n/g, ' ');
            const cs = Math.max(1, parseInt(cell.getAttribute('colspan') || '1', 10) || 1);
            cells.push(t);
            for (let k = 1; k < cs; k++) cells.push('');
          });
        } catch (e) {}
        return cells;
      });
      const width = Math.max(1, ...matrix.map((r) => r.length));
      const norm = matrix.map((r) => { const c = r.slice(); while (c.length < width) c.push(''); return c; });
      const head = norm[0];
      let out = '\n\n| ' + head.join(' | ') + ' |\n| ' + head.map(() => '---').join(' | ') + ' |\n';
      out += norm.slice(1).map((r) => '| ' + r.join(' | ') + ' |').join('\n') + '\n\n';
      return out;
    }
    return clean(walk(root));
  }

  const THINK_SELECTORS = ['[class*="think"]','[class*="reason"]','[class*="analysis"]','[class*="thought"]','[data-testid*="think"]','[data-testid*="reason"]','[data-testid*="analysis"]','[aria-label*="thinking" i]','[aria-label*="reasoning" i]'];
  function extractThinking(el) {
    const nodes = [];
    for (const sel of THINK_SELECTORS) { nodes.push(...deepQueryAll(sel, el)); }
    const unique = dedupeNested(nodes);
    const out = [];
    for (const n of unique) { const t = domToMarkdown(n); if (t && out.indexOf(t) === -1) out.push(t); }
    return out;
  }

  // Сбор картинок и вложений сообщения (для ZIP-режима)
  function collectMedia(el, msgIndex) {
    const images = [], attachments = [];
    try {
      const imgs = el.querySelectorAll('img[src]');
      for (let i = 0; i < imgs.length && images.length < CFG.IMG_PER_MSG; i++) {
        const src = imgs[i].getAttribute('src') || '';
        if (!src || /^data:/i.test(src)) continue;
        images.push({ src: new URL(src, location.href).href, alt: imgs[i].getAttribute('alt') || '', msg: msgIndex });
      }
    } catch (e) {}
    try {
      const atts = el.querySelectorAll('a[href][download],[class*="attachment"] a[href],[data-filename]');
      for (let i = 0; i < atts.length; i++) {
        const a = atts[i];
        const href = a.getAttribute('href') || '';
        if (!href || /^(#|javascript:)/i.test(href)) continue;
        attachments.push({
          url: new URL(href, location.href).href,
          name: a.getAttribute('data-filename') || a.getAttribute('download') || (href.split('/').pop() || 'file').split('?')[0]
        });
      }
    } catch (e) {}
    return { images: images, attachments: attachments };
  }

  // v26: артефакты — код-блоки как отдельные файлы для ZIP
  const LANG_EXT = { javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py', ruby: 'rb', go: 'go', golang: 'go', rust: 'rs', java: 'java', c: 'c', cpp: 'cpp', 'c++': 'cpp', csharp: 'cs', 'c#': 'cs', php: 'php', bash: 'sh', shell: 'sh', sh: 'sh', html: 'html', css: 'css', json: 'json', yaml: 'yml', yml: 'yml', xml: 'xml', markdown: 'md', md: 'md', sql: 'sql', r: 'r', swift: 'swift', kotlin: 'kt', scala: 'scala', perl: 'pl', lua: 'lua', dart: 'dart', toml: 'toml', ini: 'ini', tex: 'tex', matlab: 'm', mermaid: 'mmd' };
  function collectArtifacts(el, msgIndex) {
    const arts = [];
    try {
      const pres = el.querySelectorAll('pre');
      for (let i = 0; i < pres.length && arts.length < 30; i++) {
        const pre = pres[i];
        const code = pre.querySelector('code') || pre;
        let lang = '';
        const cls = (code.className || '') + ' ' + (pre.className || '');
        const mm = cls.match(/language-([\w+#-]+)/i) || cls.match(/lang-([\w+#-]+)/i);
        if (mm) lang = mm[1].toLowerCase();
        const text = (code.textContent || '').replace(/\r\n/g, '\n').replace(/\n+$/, '');
        if (!text || text.length < 12) continue;
        if (isCssOrJs(text) && text.length < 80) continue;
        const ext = LANG_EXT[lang] || (lang ? lang.replace(/[^a-z0-9]/gi, '') : '') || 'txt';
        arts.push({ type: 'code', lang: lang || 'text', content: text, ext: ext, msg: msgIndex });
      }
    } catch (e) {}
    return arts;
  }

  // ============ SCRAPE ============
  function scrape(options) {
    options = options || {};
    const found = findMessages();
    if (!found) return { items: [], platform: null, source: null, images: [], attachments: [], artifacts: [] };
    const platform = found.platform;
    const pre = [];
    found.items.forEach((el) => {
      const content = stripUiPrefix(domToMarkdown(el));
      const text = stripUiPrefix(extractText(el));
      if (!content && !text) return;
      const plain = text || content;
      if (plain.length < CFG.MIN_TEXT) return;
      if (isCssOrJs(plain) || isSourceListing(plain)) return;
      pre.push({ el: el, content: content, text: text, thinking: extractThinking(el) });
    });
    const roles = pre.map((m) => detectRole(m.el, platform));
    const allUnknown = roles.length > 0 && roles.every((r) => r === 'unknown');
    const allSame = roles.length > 1 && roles.every((r) => r === roles[0]);
    const parity = allUnknown || (allSame && roles[0] !== 'user');
    const allImages = [], allAttachments = [], allArtifacts = [];
    const out = pre.map((m, i) => {
      let role = roles[i];
      if (role === 'unknown' && parity) role = i % 2 === 0 ? 'user' : 'assistant';
      else if (parity && role === roles[0]) role = i % 2 === 0 ? 'user' : 'assistant';
      let content = m.content;
      if (options.stripThinking && m.thinking.length) {
        // v26: вырезаем ВСЕ вхождения блока (replace по строке бьёт только первое)
        for (const block of m.thinking) {
          if (!block || block.length < 3) continue;
          let guard = 0;
          while (content.indexOf(block) !== -1 && guard++ < 20) content = content.replace(block, '');
        }
        content = clean(content);
      }
      if (mermaidEnabled()) content = processMermaid(content);
      const media = collectMedia(m.el, i);
      collectArtifacts(m.el, i).forEach((a) => allArtifacts.push(a));
      media.images.forEach((x) => allImages.push(x));
      media.attachments.forEach((x) => allAttachments.push(x));
      return { role: role, content: content, text: m.text || clean(m.content), thinking: options.exportThinking ? m.thinking : [] };
    }).filter((m) => (options.stripThinking ? m.content : m.text) && (options.stripThinking ? m.content.length : m.text.length) >= CFG.MIN_TEXT);
    return { items: out.slice(0, CFG.MSG_MAX), source: found.source, platformName: (platform && platform.name) || null, images: allImages.slice(0, CFG.IMG_TOTAL), attachments: allAttachments.slice(0, CFG.IMG_TOTAL), artifacts: allArtifacts.slice(0, 300) };
  }

  // Аварийный снимок страницы, когда точечная структура не распознана (урок из Gemini-беседы)
  function snapshotScrape() {
    try {
      const clone = document.body.cloneNode(true);
      clone.querySelectorAll('#' + UI_ID + ',script,style,noscript,svg').forEach((n) => n.remove());
      const holder = getRenderHolder();
      holder.appendChild(clone);
      let t = '';
      try { t = clean(clone.innerText || ''); } catch (e) { t = (clone.textContent || '').trim(); }
      clone.remove();
      if (!t || t.length < CFG.MIN_TOTAL_TEXT) return null;
      if (t.length > CFG.SNAPSHOT_MAX) t = t.slice(0, CFG.SNAPSHOT_MAX) + '\n\n… (обрезано)';
      return {
        items: [{ role: 'unknown', content: '⚠ Автоснимок страницы (структура не распознана точечно):\n\n' + t, text: '⚠ Автоснимок страницы (структура не распознана точечно):\n\n' + t, thinking: [] }],
        source: 'snapshot', platformName: (getPlatform() || {}).name || null, images: [], attachments: [], artifacts: []
      };
    } catch (e) { return null; }
  }

  function fingerprint() {
    const found = findMessages();
    if (!found) return '';
    return found.items.map((el) => txt(el).slice(0, 80)).join('|');
  }

  function findScrollContainer() {
    const found = findMessages();
    const sample = found && found.items && found.items[0];
    let p = sample;
    for (let i = 0; i < 14 && p; i++, p = p.parentElement) {
      try { const st = getComputedStyle(p); if (/auto|scroll/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 100) return p; } catch (e) {}
    }
    const candidates = [document.scrollingElement, document.documentElement, document.body];
    try { candidates.push(...document.querySelectorAll('main,[role="main"],[class*="scroll"],[class*="conversation"]')); } catch (e) {}
    let sc = null, bestSize = 0;
    for (const el of candidates) {
      if (!el) continue;
      try { const extra = el.scrollHeight - el.clientHeight; if (extra > 100 && el.clientHeight > 150 && el.scrollHeight > bestSize) { bestSize = el.scrollHeight; sc = el; } } catch (e) {}
    }
    return sc;
  }

  // Автопрокрутка истории: к началу, ждём стабилизации высоты, к концу (рабочая версия из v22/v24)
  async function autoScroll(statusFn) {
    const sc = findScrollContainer();
    if (!sc) return;
    if (statusFn) statusFn('Прокручиваю историю...');
    let lastH = -1, stable = 0;
    for (let i = 0; i < CFG.SCROLL_ROUNDS; i++) {
      if (CANCEL) return;
      sc.scrollTop = 0;
      await sleep(CFG.SCROLL_WAIT);
      const h = sc.scrollHeight;
      if (h === lastH) stable++; else stable = 0;
      lastH = h;
      if (stable >= 3) break;
      if (statusFn && i % 5 === 0) statusFn('История: ' + (i + 1) + '/' + CFG.SCROLL_ROUNDS);
    }
    try { sc.scrollTop = sc.scrollHeight; } catch (e) {}
    await sleep(400);
  }

  // Ожидание смены контента после активации чата: фингерпринт + смена URL (фикс «экспорт предыдущего чата»)
  async function waitStable(prevFp, prevHref) {
    const start = Date.now();
    let lastFp = '', lastChangeTime = Date.now();
    let hrefChanged = !!(prevHref && location.href !== prevHref);
    while (Date.now() - start < CFG.MAX_WAIT) {
      if (CANCEL) return false;
      await sleep(CFG.POLL);
      if (!hrefChanged && prevHref && location.href !== prevHref) { hrefChanged = true; lastChangeTime = Date.now(); }
      const cur = fingerprint();
      if (cur && cur !== prevFp) {
        if (cur !== lastFp) { lastFp = cur; lastChangeTime = Date.now(); }
        else if (Date.now() - lastChangeTime >= CFG.STABLE_MS) return true;
      } else if (hrefChanged && Date.now() - lastChangeTime >= CFG.STABLE_MS) {
        return true;
      }
      if (!hrefChanged && !lastFp && Date.now() - start > 6000) return false;
    }
    const fp = fingerprint();
    return (!!fp && fp !== prevFp) || hrefChanged;
  }

  async function waitForContentChange(beforeHref, prevFp, timeoutMs) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (CANCEL) return false;
      await sleep(250);
      if (location.href !== beforeHref) return true;
      if (fingerprint() !== prevFp) return true;
    }
    return false;
  }

  // ============ ФОРМАТЫ ЭКСПОРТА (9) ============
  function platformName(scraped) {
    const n = scraped && scraped.platformName;
    if (n) return n;
    const p = getPlatform();
    return p ? p.name : 'universal-heuristic';
  }
  function roleLabel(role) {
    if (role === 'user') return '🧑‍💻 User';
    if (role === 'assistant') return '🤖 Assistant';
    return '❔ ' + (role || 'Unknown');
  }
  function frontMatterEnabled() { return safeStorageGet('uaice_fm') !== '0'; }

  function toMarkdown(scraped, title) {
    const L = [];
    if (frontMatterEnabled()) {
      const dateTag = '#export-' + now().slice(0, 10);
      const platTag = '#' + String(platformName(scraped)).toLowerCase().replace(/[^a-zа-я0-9]+/gi, '');
      L.push('---',
        'title: ' + JSON.stringify(String(title || 'export')),
        'platform: ' + JSON.stringify(platformName(scraped)),
        'url: ' + JSON.stringify(location.href),
        'exported_at: ' + JSON.stringify(new Date().toISOString()),
        'exporter: ' + JSON.stringify('Universal AI Chat Exporter v' + SCRIPT_VER),
        'messages_count: ' + scraped.items.length,
        'tags: [' + JSON.stringify(platTag) + ', ' + JSON.stringify(dateTag) + ']',
        '---', '', '# ' + title, '');
    } else {
      L.push('# ' + title, '',
        '- **Platform:** ' + platformName(scraped), '- **URL:** ' + location.href,
        '- **Exported:** ' + now() + ' (v' + SCRIPT_VER + ')', '- **Messages:** ' + scraped.items.length, '', '---', '');
    }
    scraped.items.forEach((m) => {
      L.push('### ' + roleLabel(m.role), '', m.content || m.text, '');
      if (m.thinking && m.thinking.length) L.push('<details><summary>🧠 Thinking</summary>', '', m.thinking.join('\n\n'), '', '</details>', '');
    });
    return L.join('\n');
  }
  function toJSON(scraped, title) {
    return JSON.stringify({
      title: title, platform: platformName(scraped), exporter: 'Universal AI Chat Exporter v' + SCRIPT_VER,
      url: location.href, exported_at: new Date().toISOString(), messages_count: scraped.items.length,
      source_selector: scraped.source || null,
      messages: scraped.items.map((m, i) => ({ index: i, role: m.role, content_markdown: m.content, text: m.text, thinking: m.thinking || [] }))
    }, null, 2);
  }
  function toTXT(scraped, title) {
    const lines = [title, '='.repeat(Math.min(title.length, 70)), 'Platform: ' + platformName(scraped), 'URL: ' + location.href, 'Exported: ' + now() + ' (v' + SCRIPT_VER + ')', ''];
    scraped.items.forEach((m) => {
      lines.push('[' + String(m.role || 'unknown').toUpperCase() + ']');
      if (m.thinking && m.thinking.length) lines.push('[REASONING]', m.thinking.join('\n\n'), '');
      lines.push(m.text || m.content); lines.push('');
    });
    return lines.join('\n');
  }
  function htmlCss() {
    return 'body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:800px;margin:2rem auto;padding:0 1rem;line-height:1.6;color:#222}h1{border-bottom:2px solid #eee;padding-bottom:.5rem}.msg{margin:1.5rem 0;padding:1rem;border-radius:8px}.user{background:#e7f3ff;border-left:4px solid #1a73e8}.assistant{background:#f5f5f5;border-left:4px solid #666}.unknown{background:#fff8e1;border-left:4px solid #f0a500}.role{font-weight:600;margin-bottom:.5rem;color:#555}.meta{color:#888;font-size:.9rem;margin-bottom:2rem}.think{background:#fafafa;border:1px dashed #ccc;border-radius:6px;padding:.6rem;margin:.6rem 0;font-size:.92em;color:#555}';
  }
  function htmlBody(scraped, title) {
    const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    let h = '<h1>' + esc(title) + '</h1>';
    h += '<div class="meta">Platform: ' + esc(platformName(scraped)) + '<br>URL: ' + esc(location.href) + '<br>Exported: ' + now() + ' (v' + SCRIPT_VER + ')<br>Messages: ' + scraped.items.length + '</div>';
    scraped.items.forEach((m) => {
      h += '<div class="msg ' + esc(String(m.role || 'unknown')) + '">';
      h += '<div class="role">' + esc(roleLabel(m.role)) + '</div>';
      if (m.thinking && m.thinking.length) h += '<div class="think"><b>🧠 Thinking</b><br>' + esc(m.thinking.join('\n\n')).replace(/\n/g, '<br>') + '</div>';
      h += '<div>' + esc(m.text || m.content).replace(/\n/g, '<br>') + '</div></div>';
    });
    return h;
  }
  // ShareGPT: {title,url,conversations:[{from:'human'|'gpt'|'system', value}]}
  function sharegptFrom(role) {
    if (role === 'user') return 'human';
    if (role === 'assistant') return 'gpt';
    return 'system';
  }
  function toShareGPT(scraped, title) {
    return JSON.stringify({
      title: title,
      url: location.href,
      exported_at: new Date().toISOString(),
      conversations: scraped.items.map((m) => ({ from: sharegptFrom(m.role), value: m.text || m.content }))
    }, null, 2);
  }
  // JSONL: одна строка на сообщение
  function toJSONL(scraped, title) {
    return scraped.items.map((m, i) => JSON.stringify({
      chat: title, i: i, role: m.role, text: m.text || m.content
    })).join('\n');
  }
  // Alpaca: пары instruction(user) -> output(assistant)
  function toAlpaca(scraped, title) {
    const samples = [];
    let pending = null;
    scraped.items.forEach((m) => {
      if (m.role === 'user') {
        if (pending) samples.push({ instruction: pending, input: '', output: '' });
        pending = m.text || m.content;
      } else if (m.role === 'assistant') {
        samples.push({ instruction: pending || '', input: '', output: m.text || m.content });
        pending = null;
      } else if (pending) {
        samples.push({ instruction: pending, input: '', output: '' });
        pending = null;
      }
    });
    if (pending) samples.push({ instruction: pending, input: '', output: '' });
    return JSON.stringify({ chat: title, url: location.href, samples: samples }, null, 2);
  }
  function contentFor(format, scraped, title) {
    if (format === 'json') return { content: toJSON(scraped, title), ext: 'json', mime: 'application/json;charset=utf-8' };
    if (format === 'txt') return { content: toTXT(scraped, title), ext: 'txt', mime: 'text/plain;charset=utf-8' };
    if (format === 'html') return { content: toHTML(scraped, title), ext: 'html', mime: 'text/html;charset=utf-8' };
    if (format === 'sharegpt') return { content: toShareGPT(scraped, title), ext: 'sharegpt.json', mime: 'application/json;charset=utf-8' };
    if (format === 'jsonl') return { content: toJSONL(scraped, title), ext: 'jsonl', mime: 'application/x-ndjson;charset=utf-8' };
    if (format === 'alpaca') return { content: toAlpaca(scraped, title), ext: 'alpaca.json', mime: 'application/json;charset=utf-8' };
    return { content: toMarkdown(scraped, title), ext: 'md', mime: 'text/markdown;charset=utf-8' };
  }

  // ============ v27.2 STYLES ENGINE: PDF/HTML по шаблону МАКТ-2026 ============
  // 5 стилей на выбор, один из них — ИМПЕРСКИЙ (тёмный фон + золото, крупный кегль:
  // сделано для человека со слабым зрением). Печать → PDF силами браузера:
  // векторный текст, 0 внешних запросов, 0 CDN (html2pdf удалён — он и был
  // причиной пустых PDF: оффскрин-holder не рендерится html2canvas).
  // Каждый стиль проверен по WCAG 2.2: контраст текста ≥4.5:1, без чистого
  // чёрного/белого, интерлиньяж ≥1.6, мера ≤78ch, цели кнопок ≥44px.
  const TPL_STYLES = {
    imperial: { name: 'Имперский', hint: 'Тёмный фон, золото, кегль 18 — для слабого зрения' },
    makt: { name: 'МАКТ Светлый', hint: 'Человекоцентричный светлый стандарт проекта' },
    swiss: { name: 'Швейцарская сетка', hint: 'Editorial-типографика, жёсткая сетка линий' },
    brutal: { name: 'Нео-брутализм', hint: 'Тренд 2026: жирные рамки и жёсткие тени' },
    sepia: { name: 'Сепия Вечер', hint: 'Тёплые тона для вечернего чтения — забота о глазах' }
  };
  const TPL_KEY = 'uaice_tpl';
  function tplStyleId() {
    const v = safeStorageGet(TPL_KEY);
    return (v && TPL_STYLES[v]) ? v : 'imperial';
  }
  function tplEscape(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function tplCss() {
    return `
/* ===== БАЗА: единая анатомия, стиль = набор переменных ===== */
*{box-sizing:border-box}
html{background:var(--bg)}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--font-body);font-size:var(--fs);line-height:var(--lh)}
.page{max-width:78ch;margin:0 auto;padding:26px 22px 70px}
a{color:var(--accent);text-decoration:underline;text-underline-offset:3px}
code{font-family:ui-monospace,SFMono-Regular,Consolas,'Liberation Mono',monospace;font-size:.9em;background:var(--code-bg);border:1px solid var(--line);border-radius:4px;padding:.08em .35em;overflow-wrap:anywhere}
/* --- Шапка-обложка --- */
.cover{border:var(--cover-border);border-radius:var(--radius);background:var(--paper);padding:22px 24px 20px;margin:0 0 28px}
.kicker{font-family:var(--font-head);font-size:.72em;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--accent);margin:0 0 10px}
h1{font-family:var(--font-head);font-size:1.85em;line-height:1.28;margin:0 0 16px;color:var(--ink);overflow-wrap:anywhere}
.meta{display:grid;grid-template-columns:max-content 1fr;gap:4px 14px;margin:0 0 4px;font-size:.86em;color:var(--ink2)}
.meta b{color:var(--ink);font-weight:600}
.meta .u{overflow-wrap:anywhere}
.passport{margin-top:14px;padding-top:12px;border-top:1px solid var(--line);font-size:.8em;line-height:1.7;color:var(--ink2)}
.passport b{color:var(--accent)}
/* --- Поток сообщений --- */
.flow{list-style:none;margin:0;padding:0}
.msg{margin:0 0 18px;background:var(--paper);border:1px solid var(--line);border-left:4px solid var(--line);border-radius:var(--radius);padding:14px 18px 15px;box-shadow:var(--shadow)}
.msg.user{background:var(--user-bg);border-left-color:var(--user-edge)}
.msg.assistant{background:var(--as-bg);border-left-color:var(--as-edge)}
.role{font-family:var(--font-head);font-size:.74em;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--role-tx);margin:0 0 8px}
.role .num{font-weight:400;letter-spacing:.02em;color:var(--ink2)}
.body{overflow-wrap:break-word}
.body p{margin:0 0 .7em}
.think{margin:12px 0 0;background:var(--think-bg);color:var(--think-tx);border:1px dashed var(--line);border-radius:6px;padding:10px 14px;font-size:.9em}
.think summary{cursor:pointer;font-family:var(--font-head);font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-size:.85em}
.think[open] summary{margin-bottom:8px}
/* --- Многочатовник --- */
.chat{margin:0}
.chat + .chat{margin-top:34px}
.chat-head{border-top:2px solid var(--line);padding-top:16px;margin-bottom:16px}
.chat-head h2{font-family:var(--font-head);font-size:1.3em;margin:0 0 6px;line-height:1.3;overflow-wrap:anywhere}
.chat-head .chat-url{font-size:.8em;color:var(--ink2);overflow-wrap:anywhere}
/* --- Колофон --- */
.colophon{margin-top:38px;padding-top:14px;border-top:1px solid var(--line);font-size:.78em;color:var(--ink2);line-height:1.7}
/* --- Панель стилей (не печатается) --- */
.tpl-bar{position:sticky;top:0;z-index:9;display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 14px;background:var(--bar-bg);color:var(--bar-tx);border-bottom:2px solid var(--accent)}
.tpl-bar .lbl{font-size:.78em;font-weight:700;letter-spacing:.12em;text-transform:uppercase;margin-right:2px}
.tpl-btn{font:inherit;font-size:.86em;min-height:44px;padding:6px 14px;border-radius:8px;border:1px solid var(--bar-line);background:var(--bar-btn);color:var(--bar-tx);cursor:pointer}
.tpl-btn[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:var(--accent-tx);font-weight:700}
.tpl-btn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.tpl-print{margin-left:auto;font-weight:700;background:var(--accent);border-color:var(--accent);color:var(--accent-tx)}
.tpl-hint{flex-basis:100%;font-size:.74em;line-height:1.5;opacity:.78}
@media (max-width:640px){.tpl-print{margin-left:0}}
/* ===== СТИЛЬ 1: ИМПЕРСКИЙ — тёмный фон + золото, крупный кегль ===== */
html[data-tpl="imperial"]{
  --bg:#191410;--paper:#211b14;--ink:#f2e9d3;--ink2:#c9b98a;--line:#413524;
  --accent:#d4af37;--accent-tx:#191410;--code-bg:#1a1510;
  --user-bg:#2a2312;--user-edge:#d4af37;--as-bg:#1e1913;--as-edge:#6b5a2e;
  --think-bg:#1b1611;--think-tx:#bca982;--role-tx:#e8c96a;
  --font-head:Georgia,'Times New Roman',serif;--font-body:Georgia,'Times New Roman',serif;
  --fs:18px;--lh:1.78;--radius:6px;--shadow:none;--cover-border:3px double #8a7430;
  --bar-bg:#100d0a;--bar-tx:#f2e9d3;--bar-btn:#241d15;--bar-line:#413524;
}
html[data-tpl="imperial"] h1{letter-spacing:.015em}
html[data-tpl="imperial"] .kicker{color:#e8c96a}
/* ===== СТИЛЬ 2: МАКТ СВЕТЛЫЙ — человекоцентричный стандарт ===== */
html[data-tpl="makt"]{
  --bg:#f6f6f8;--paper:#fdfdfd;--ink:#1d1d1f;--ink2:#51515b;--line:#d9d9e0;
  --accent:#0b66c3;--accent-tx:#ffffff;--code-bg:#f0f0f4;
  --user-bg:#eaf2fc;--user-edge:#0b66c3;--as-bg:#f4f4f7;--as-edge:#9a9aa4;
  --think-bg:#fafafa;--think-tx:#51515b;--role-tx:#444a56;
  --font-head:-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
  --font-body:-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
  --fs:16px;--lh:1.65;--radius:10px;--shadow:0 1px 2px rgba(20,20,30,.06);
  --cover-border:1px solid var(--line);
  --bar-bg:#fdfdfd;--bar-tx:#1d1d1f;--bar-btn:#f0f0f4;--bar-line:#d9d9e0;
}
/* ===== СТИЛЬ 3: ШВЕЙЦАРСКАЯ СЕТКА — editorial-типографика ===== */
html[data-tpl="swiss"]{
  --bg:#fbfbf8;--paper:#fefefe;--ink:#161616;--ink2:#5b5b55;--line:#161616;
  --accent:#d43518;--accent-tx:#ffffff;--code-bg:#f1f1ea;
  --user-bg:#fefefe;--user-edge:#d43518;--as-bg:#f0f0ea;--as-edge:#161616;
  --think-bg:#f5f5ef;--think-tx:#44443e;--role-tx:#161616;
  --font-head:'Helvetica Neue',Helvetica,Arial,sans-serif;
  --font-body:'Helvetica Neue',Helvetica,Arial,sans-serif;
  --fs:16px;--lh:1.6;--radius:0;--shadow:none;--cover-border:2px solid #161616;
  --bar-bg:#161616;--bar-tx:#fbfbf8;--bar-btn:#232320;--bar-line:#3a3a36;
}
html[data-tpl="swiss"] h1{letter-spacing:-.02em;text-transform:uppercase}
html[data-tpl="swiss"] .msg{border:1px solid transparent;border-top:2px solid var(--ink);border-left:none;border-radius:0;background:transparent;box-shadow:none;padding:12px 2px 14px}
html[data-tpl="swiss"] .msg.user{border-top-color:#d43518}
html[data-tpl="swiss"] .role .num{font-size:1.5em;color:#b9b9ae}
/* ===== СТИЛЬ 4: НЕО-БРУТАЛИЗМ — тренд 2026 ===== */
html[data-tpl="brutal"]{
  --bg:#f3ecdd;--paper:#fffdf4;--ink:#151515;--ink2:#4c4a42;--line:#151515;
  --accent:#2c49d0;--accent-tx:#ffffff;--code-bg:#efeadb;
  --user-bg:#ffd23f;--user-edge:#151515;--as-bg:#fffdf4;--as-edge:#151515;
  --think-bg:#efeadb;--think-tx:#3f3d36;--role-tx:#151515;
  --font-head:'Segoe UI',Arial,sans-serif;--font-body:'Segoe UI',Arial,sans-serif;
  --fs:16px;--lh:1.6;--radius:0;--shadow:5px 5px 0 #151515;--cover-border:3px solid #151515;
  --bar-bg:#ffd23f;--bar-tx:#151515;--bar-btn:#fffdf4;--bar-line:#151515;
}
html[data-tpl="brutal"] h1{font-weight:900;text-transform:uppercase;letter-spacing:-.01em}
html[data-tpl="brutal"] .msg{border-width:2.5px;border-left-width:2.5px;border-radius:0;box-shadow:5px 5px 0 #151515}
html[data-tpl="brutal"] .msg.user{box-shadow:5px 5px 0 #151515}
html[data-tpl="brutal"] .role{display:inline-block;background:#151515;color:#ffd23f;padding:3px 10px;border-radius:0;margin-bottom:10px}
html[data-tpl="brutal"] .msg.user .role{background:#151515;color:#ffd23f}
html[data-tpl="brutal"] .msg.assistant .role{background:#2c49d0;color:#ffffff}
/* ===== СТИЛЬ 5: СЕПИЯ ВЕЧЕР — тёплые тона, забота о глазах ===== */
html[data-tpl="sepia"]{
  --bg:#f2e9d5;--paper:#f9f3e3;--ink:#443522;--ink2:#6f5d40;--line:#d8c8a6;
  --accent:#8a4d20;--accent-tx:#fff8ec;--code-bg:#ece2c9;
  --user-bg:#ecdfc0;--user-edge:#8a4d20;--as-bg:#f4ecd8;--as-edge:#b09468;
  --think-bg:#efe5cc;--think-tx:#5c4c32;--role-tx:#7a4a22;
  --font-head:Georgia,'Times New Roman',serif;--font-body:Georgia,'Times New Roman',serif;
  --fs:17px;--lh:1.75;--radius:8px;--shadow:none;--cover-border:1px solid #c9b287;
  --bar-bg:#e9ddc2;--bar-tx:#443522;--bar-btn:#f9f3e3;--bar-line:#c9b287;
}
/* ===== ПЕЧАТЬ → PDF: векторный текст, фон сохраняется ===== */
@page{size:A4;margin:15mm 13mm 17mm}
@media print{
  *{-webkit-print-color-adjust:exact !important;print-color-adjust:exact !important}
  html,body{background:var(--bg) !important}
  body{margin:0}
  .tpl-bar{display:none !important}
  .page{max-width:none;margin:0;padding:0}
  .cover,.think{break-inside:avoid}
  .cover{break-after:avoid}
  .role{break-after:avoid}
  .chat + .chat{break-before:page}
  .body{orphans:3;widows:3}
  .msg{break-inside:auto}
  a{color:inherit}
}
`;
  }
  function tplBarHTML() {
    let h = '<div class="tpl-bar" role="toolbar" aria-label="Стиль оформления экспорта"><span class="lbl">Стиль:</span>';
    Object.keys(TPL_STYLES).forEach((id) => {
      const s = TPL_STYLES[id];
      h += '<button type="button" class="tpl-btn" data-style="' + id + '" aria-pressed="' + (id === tplStyleId() ? 'true' : 'false') + '" title="' + tplEscape(s.hint) + '">' + tplEscape(s.name) + '</button>';
    });
    h += '<button type="button" class="tpl-btn tpl-print" data-act="print" title="Печать / Сохранить как PDF (Ctrl+P)">🖨 Печать / PDF</button>';
    h += '<span class="tpl-hint">Выбор стиля запоминается · Тёмным стилям (Имперский) фон даёт свойство print-color-adjust: exact — если браузер спросит про «Фоновую графику», включите.</span></div>';
    return h;
  }
  function tplPassportHTML(msgs) {
    const st = TPL_STYLES[tplStyleId()];
    return '<div class="passport"><b>Паспорт страницы</b> · стиль «<span id="pp-style">' + tplEscape(st.name) + '</span>»' +
      ' · кегль <span id="pp-fs">—</span> · интерлиньяж <span id="pp-lh">—</span>' +
      ' · контраст текста <span id="pp-cr">—</span>' +
      ' · сообщений: ' + msgs + ' · внешних запросов: <b>0</b>' +
      ' · экспортёр UAICE v' + SCRIPT_VER + '</div>';
  }
  function tplChatHTML(scraped, title, idx, withHead, url) {
    const esc = tplEscape;
    let h = '';
    if (withHead) {
      h += '<section class="chat"><header class="chat-head"><h2>' + (idx + 1) + '. ' + esc(title) + '</h2>' +
        '<div class="chat-url">' + esc(url || location.href) + ' · ' + esc(platformName(scraped)) + '</div></header>';
    }
    h += '<ol class="flow">';
    (scraped.items || []).forEach((m, i) => {
      const role = String(m.role || 'unknown');
      h += '<li class="msg ' + esc(role) + '"><div class="role"><span class="num">' + String(i + 1).padStart(2, '0') + '</span> ' + esc(roleLabel(m.role)) + '</div>';
      if (m.thinking && m.thinking.length) {
        h += '<details class="think"><summary>🧠 Thinking</summary><div>' + esc(m.thinking.join('\n\n')).replace(/\n/g, '<br>') + '</div></details>';
      }
      h += '<div class="body">' + esc(m.text || m.content).replace(/\n/g, '<br>') + '</div></li>';
    });
    h += '</ol>';
    if (withHead) h += '</section>';
    return h;
  }
  function tplPageScript() {
    return '<script>(function(){' +
      'var VALID=["imperial","makt","swiss","brutal","sepia"];' +
      'try{var s=localStorage.getItem("uaice_tpl");' +
      'if(s&&VALID.indexOf(s)>=0&&s!==document.documentElement.getAttribute("data-tpl"))document.documentElement.setAttribute("data-tpl",s);}catch(e){}' +
      'function lum(c){var m=c.match(/rgba?\\(([^)]+)\\)/);if(!m)return null;var p=m[1].split(",").map(function(x){return parseFloat(x)});' +
      'var r=p[0]/255,g=p[1]/255,b=p[2]/255;var f=function(v){return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};' +
      'return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b);}' +
      'function bgOf(el){var e=el;while(e){var c=getComputedStyle(e).backgroundColor;if(c&&c.indexOf("rgba(0, 0, 0, 0)")!==0&&c!=="transparent")return c;e=e.parentElement;}return "rgb(255,255,255)";}' +
      'function ratio(a,b){var l1=lum(a),l2=lum(b);if(l1===null||l2===null)return null;var hi=Math.max(l1,l2),lo=Math.min(l1,l2);return (hi+0.05)/(lo+0.05);}' +
      'function pass(){try{var b=getComputedStyle(document.body);var fs=parseFloat(b.fontSize);var lh=parseFloat(b.lineHeight);' +
      'var cr=ratio(b.color,bgOf(document.body));' +
      'var f=function(id,v){var n=document.getElementById(id);if(n)n.textContent=v;};' +
      'f("pp-fs",Math.round(fs)+" px");f("pp-lh",(lh/fs).toFixed(2));f("pp-cr",cr?cr.toFixed(1)+" : 1":"—");' +
      'var st=document.documentElement.getAttribute("data-tpl");var names={imperial:"Имперский",makt:"МАКТ Светлый",swiss:"Швейцарская сетка",brutal:"Нео-брутализм",sepia:"Сепия Вечер"};' +
      'f("pp-style",names[st]||st);}catch(e){}}' +
      'var bar=document.querySelector(".tpl-bar");' +
      'if(bar)bar.addEventListener("click",function(ev){var b=ev.target&&ev.target.closest?ev.target.closest(".tpl-btn"):null;if(!b||b.__wired)return;b.__wired=true;' +
      'if(b.dataset.style){document.documentElement.setAttribute("data-tpl",b.dataset.style);' +
      'bar.querySelectorAll(".tpl-btn[data-style]").forEach(function(x){x.setAttribute("aria-pressed",x===b?"true":"false")});' +
      'try{localStorage.setItem("uaice_tpl",b.dataset.style)}catch(e){}pass();}' +
      'else if(b.dataset.act==="print"){try{window.print()}catch(e){}}});' +
      'window.addEventListener("beforeprint",function(){document.querySelectorAll("details.think").forEach(function(d){d.open=true})});' +
      'pass();window.passportRefresh=pass;})();<\/script>';
  }
  function buildStyledHTML(scrapedOrList, title, opts) {
    opts = opts || {};
    const isList = Array.isArray(scrapedOrList);
    const list = isList ? scrapedOrList : [{ scraped: scrapedOrList, title: title, url: location.href }];
    const styleId = tplStyleId();
    const stName = TPL_STYLES[styleId].name;
    const esc = tplEscape;
    let msgs = 0;
    list.forEach((r) => { msgs += (r.scraped && r.scraped.items ? r.scraped.items.length : 0); });
    const docTitle = isList ? (title || 'AI Chats') : title;
    let body = '';
    body += '<main class="page">';
    body += '<header class="cover"><p class="kicker">' + (isList ? 'Сводный экспорт диалогов' : 'Экспорт диалога') + ' · ' + esc(platformName(list[0].scraped)) + '</p>' +
      '<h1>' + esc(docTitle) + '</h1>' +
      '<dl class="meta">' +
      '<dt>Экспортировано</dt><dd>' + esc(now()) + '</dd>' +
      '<dt>Диалогов</dt><dd>' + list.length + '</dd>' +
      '<dt>Сообщений</dt><dd>' + msgs + '</dd>' +
      (isList ? '' : '<dt>Источник</dt><dd class="u">' + esc(location.href) + '</dd>') +
      '</dl>' + tplPassportHTML(msgs) + '</header>';
    body += list.map((r, i) => tplChatHTML(r.scraped, r.title, i, isList, r.url)).join('\n');
    body += '<footer class="colophon">Сделано человеком с заботой о человеке · Universal AI Chat Exporter v' + SCRIPT_VER +
      ' · шаблон МАКТ-2026 · стиль «' + esc(stName) + '» · печать: Ctrl+P → «Сохранить как PDF» · 0 внешних запросов</footer>';
    body += '</main>';
    return '<!DOCTYPE html><html lang="ru" data-tpl="' + styleId + '"><head><meta charset="UTF-8">' +
      '<meta name="viewport" content="width=device-width, initial-scale=1">' +
      '<title>' + esc(docTitle) + '</title>' +
      '<style>' + tplCss() + '</style></head><body>' +
      tplBarHTML() + body + tplPageScript() + '</body></html>';
  }
  function openPrintWindow(html) {
    let url = '';
    try {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      url = URL.createObjectURL(blob);
    } catch (e) { return null; }
    const w = window.open(url, '_blank');
    if (!w) { setTimeout(() => URL.revokeObjectURL(url), 30000); return null; }
    // Проводка кнопок со стороны opener — работает даже при строгом CSP
    // (встроенные скрипты окна могут быть запрещены политикой страницы).
    const wire = () => {
      try {
        const doc = w.document;
        if (!doc || !doc.body) return;
        const bar = doc.querySelector('.tpl-bar');
        if (bar && !bar.__wiredOpener) {
          bar.__wiredOpener = true;
          bar.addEventListener('click', (ev) => {
            const t = ev.target && ev.target.closest ? ev.target.closest('.tpl-btn') : null;
            if (!t) return;
            if (t.dataset.style) {
              doc.documentElement.setAttribute('data-tpl', t.dataset.style);
              bar.querySelectorAll('.tpl-btn[data-style]').forEach((x) => x.setAttribute('aria-pressed', x === t ? 'true' : 'false'));
              try { localStorage.setItem(TPL_KEY, t.dataset.style); } catch (e) {}
              try { w.passportRefresh && w.passportRefresh(); } catch (e) {}
            } else if (t.dataset.act === 'print') { try { w.print(); } catch (e) {} }
          });
        }
        doc.querySelectorAll('details.think').forEach((d) => { d.open = true; });
      } catch (e) {}
    };
    setTimeout(wire, 350);
    setTimeout(wire, 1200);
    // Печать инициируем со стороны opener: не зависит от CSP окна.
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) {} }, 600);
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return w;
  }
  function toHTML(scraped, title) {
    return buildStyledHTML(scraped, title, {});
  }

  // ============ ДОСТАВКА: BLOB / СОБСТВЕННЫЙ ZIP (без CDN) / PDF ============
  function downloadBlob(content, filename, mime) {
    const blob = (content instanceof Blob) ? content : new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.rel = 'noopener';
    (document.body || document.documentElement).appendChild(a);
    a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  // v26: стриминговая запись больших ZIP/PDF через File System Access API (без удержания blob в памяти вкладки)
  async function downloadSmart(content, filename, mime) {
    const blob = (content instanceof Blob) ? content : new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
    if (typeof window.showSaveFilePicker === 'function' && /\.(zip|pdf)$/i.test(String(filename || ''))) {
      try {
        const h = await window.showSaveFilePicker({ suggestedName: filename });
        const wr = await h.createWritable();
        await wr.write(blob);
        await wr.close();
        return true;
      } catch (e) { if (e && e.name === 'AbortError') return false; }
    }
    downloadBlob(blob, filename, mime);
    return false;
  }

  // Собственный ZIP-писатель (метод store, UTF-8 имена). Никаких внешних библиотек.
  const CRC_TABLE = (function () {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(u8) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  function dosDateTime(d) {
    const time = ((d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2)) & 0xFFFF;
    const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time: time, date: date };
  }
  // entries: [{name, data:string|Uint8Array, date?}] -> Blob (application/zip)
  // v26.1 (из RESTORED): нативное сжатие DEFLATE (deflate-raw) через CompressionStream —
  // без CDN. Нет поддержки в браузере / не сжало -> запись методом store (method 0).
  // Бинарные/уже сжатые данные (картинки, PDF) не жмём — только текстовые записи.
  async function deflateRaw(u8) {
    if (typeof CompressionStream === 'undefined') return null;
    try {
      const cs = new CompressionStream('deflate-raw');
      const ab = await new Response(new Blob([u8]).stream().pipeThrough(cs)).arrayBuffer();
      const out = new Uint8Array(ab);
      return (out.length > 0 && out.length < u8.length) ? out : null;
    } catch (e) { return null; }
  }
  function zipNoCompress(name) { return /\.(png|jpe?g|gif|webp|bmp|svgz|pdf|zip|bin)$/i.test(String(name || '')); }
  async function zipStore(entries) {
    const enc = new TextEncoder();
    const localChunks = [], centralChunks = [];
    let offset = 0;
    const d = new Date();
    const { time, date } = dosDateTime(d);
    for (const e of entries) {
      const name = enc.encode(e.name);
      const raw = (e.data instanceof Uint8Array) ? e.data : enc.encode(String(e.data));
      let data = raw, method = 0;
      if (!zipNoCompress(e.name)) {
        const deflated = await deflateRaw(raw);
        if (deflated) { data = deflated; method = 8; }
      }
      const crc = crc32(raw);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true);
      lh.setUint16(8, method, true);
      lh.setUint16(10, time, true);
      lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, data.length, true);
      lh.setUint32(22, raw.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      localChunks.push(new Uint8Array(lh.buffer), name, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, method, true);
      ch.setUint16(12, time, true);
      ch.setUint16(14, date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, data.length, true);
      ch.setUint32(24, raw.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint16(30, 0, true);
      ch.setUint16(32, 0, true);
      ch.setUint16(34, 0, true);
      ch.setUint16(36, 0, true);
      ch.setUint32(38, 0, true);
      ch.setUint32(42, offset, true);
      centralChunks.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + data.length;
    }
    let cdSize = 0;
    for (const c of centralChunks) cdSize += c.length;
    const eocd = new DataView(new ArrayBuffer(22));
    eocd.setUint32(0, 0x06054b50, true);
    eocd.setUint16(4, 0, true);
    eocd.setUint16(6, 0, true);
    eocd.setUint16(8, entries.length, true);
    eocd.setUint16(10, entries.length, true);
    eocd.setUint32(12, cdSize, true);
    eocd.setUint32(16, offset, true);
    eocd.setUint16(20, 0, true);
    return new Blob(localChunks.concat(centralChunks, [new Uint8Array(eocd.buffer)]), { type: 'application/zip' });
  }

  function blobToU8(blob) { return blob.arrayBuffer().then((ab) => new Uint8Array(ab)); }
  function extFromMime(mime) {
    const m = String(mime || '').toLowerCase();
    if (m.indexOf('jpeg') !== -1) return 'jpg';
    if (m.indexOf('png') !== -1) return 'png';
    if (m.indexOf('webp') !== -1) return 'webp';
    if (m.indexOf('gif') !== -1) return 'gif';
    if (m.indexOf('svg') !== -1) return 'svg';
    if (m.indexOf('bmp') !== -1) return 'bmp';
    return 'bin';
  }
  async function fetchImageU8(url) {
    // v26: до 3 попыток с прогрессивной паузой; 401/403 помечаются как session-bound
    const tries = CFG.IMG_RETRIES || 3;
    let lastErr = null;
    for (let attempt = 0; attempt < tries; attempt++) {
      const ctrl = (typeof AbortController === 'function') ? new AbortController() : null;
      const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, CFG.IMG_TIMEOUT) : null;
      try {
        const resp = await fetch(url, { mode: 'cors', cache: attempt === 0 ? 'force-cache' : 'no-cache', signal: ctrl ? ctrl.signal : undefined, credentials: 'omit' });
        if (!resp.ok) throw new Error('HTTP ' + resp.status + (resp.status === 401 || resp.status === 403 ? ' (session-bound)' : ''));
        const blob = await resp.blob();
        return { data: await blobToU8(blob), ext: extFromMime(blob.type) };
      } catch (e) {
        lastErr = e;
        if (attempt < tries - 1) await sleep(350 * (attempt + 1));
      } finally { if (timer) clearTimeout(timer); }
    }
    throw lastErr || new Error('fetch failed');
  }

  function resolveInner() {
    const v = (safeStorageGet('uaice_zipinner') || 'md').toLowerCase();
    return ['md', 'json', 'txt', 'html', 'pdf', 'both'].indexOf(v) !== -1 ? v : 'md';
  }
  function imagesEnabled() { return safeStorageGet('uaice_images') !== '0'; }

  // ZIP из результатов массового экспорта: chats/ + images/ + artifacts/ + _index.json + _FAILURES.txt
  // v26: возвращает список записей; разбивку на тома делает splitZipVolumes
  async function buildZipEntries(results, failures, innerFmt, statusFn) {
    const entries = [];
    const index = [];
    const imagesFailed = [];
    const attachmentsAll = [];
    let imgSeq = 0, artSeq = 0;
    for (let i = 0; i < results.length; i++) {
      if (CANCEL) break;
      const r = results[i];
      if (statusFn) statusFn('ZIP ' + progress(i, results.length, sanitize(r.title, 24)));
      const base = String(i + 1).padStart(3, '0') + '-' + sanitize(r.title);
      const rec = { file: '', title: r.title, url: r.url, messages: r.scraped.items.length };
      if (innerFmt === 'both') {
        // v26: двойной формат для ML-пайплайнов — md + json рядом
        const fm = contentFor('md', r.scraped, r.title);
        const fj = contentFor('json', r.scraped, r.title);
        rec.file = base + '.md+.json';
        entries.push({ name: 'chats/' + base + '.md', data: fm.content });
        entries.push({ name: 'chats/' + base + '.json', data: fj.content });
      } else if (innerFmt === 'pdf') {
        // v27.3: внутри ZIP «PDF» — это .print.html по шаблону: открыть -> Ctrl+P.
        // Настоящий PDF силами браузера (векторный текст), без CDN, честно.
        rec.file = base + '.print.html';
        rec.note = 'PDF по шаблону: откройте файл и нажмите Ctrl+P (0 CDN)';
        entries.push({ name: 'chats/' + rec.file, data: buildStyledHTML(r.scraped, r.title, { inZip: true }) });
      } else {
        const f = contentFor(innerFmt, r.scraped, r.title);
        rec.file = base + '.' + f.ext;
        entries.push({ name: 'chats/' + rec.file, data: f.content });
      }
      if (imagesEnabled() && r.scraped && Array.isArray(r.scraped.images)) {
        let perChat = 0;
        for (const im of r.scraped.images) {
          if (imgSeq >= CFG.IMG_TOTAL || perChat >= 20) break;
          try {
            const got = await fetchImageU8(im.src);
            imgSeq++; perChat++;
            entries.push({ name: 'images/' + String(i + 1).padStart(3, '0') + '-' + String(perChat).padStart(2, '0') + '.' + got.ext, data: got.data });
            rec.images = (rec.images || 0) + 1;
          } catch (e) { imagesFailed.push(im.src + ' — ' + (e && e.message || 'ошибка')); }
        }
      }
      if (r.scraped && Array.isArray(r.scraped.attachments)) {
        r.scraped.attachments.forEach((a) => attachmentsAll.push({ chat: r.title, url: a.url, name: a.name }));
      }
      // v26: артефакты кода — отдельные файлы artifacts/NNN-MM-lang.ext
      if (r.scraped && Array.isArray(r.scraped.artifacts)) {
        for (const a of r.scraped.artifacts) {
          if (artSeq >= CFG.ARTIFACTS_MAX) break;
          artSeq++;
          entries.push({ name: 'artifacts/' + String(i + 1).padStart(3, '0') + '-' + String((a.msg || 0) + 1).padStart(2, '0') + '-' + sanitize(a.lang || 'text', 20) + '.' + (a.ext || 'txt'), data: a.content || '' });
          rec.artifacts = (rec.artifacts || 0) + 1;
        }
      }
      index.push(rec);
    }
    // v26: прямые ссылки на все картинки — ручная дозагрузка при CORS-блоках
    if (imagesEnabled()) {
      const links = [];
      for (const r of results) { if (r.scraped && Array.isArray(r.scraped.images)) r.scraped.images.forEach((im) => links.push('- [' + sanitize(r.title, 40) + '] ' + im.src)); }
      if (links.length) entries.push({ name: '_image-links.txt', data: ['# Все найденные изображения (для ручной загрузки при CORS-блоках)', ''].concat(links).join('\n') });
    }
    if (failures.length) entries.push({ name: '_FAILURES.txt', data: ['# Не удалось', ''].concat(failures.map((f) => '- ' + f.title + ': ' + f.error)).join('\n') });
    if (attachmentsAll.length) entries.push({ name: '_attachments.txt', data: attachmentsAll.map((a) => '- [' + sanitize(a.chat, 40) + '] ' + a.name + ' — ' + a.url).join('\n') });
    if (imagesFailed.length) entries.push({ name: '_images-failed.txt', data: ['# Не скачались (CORS/доступ)', ''].concat(imagesFailed).join('\n') });
    entries.push({ name: '_index.json', data: JSON.stringify({ exporter: 'UACE v' + SCRIPT_VER, created: now(), format: innerFmt, chats: index, failures: failures, images_failed: imagesFailed.length }, null, 2) });
    return entries;
  }

  // v26: разбивка записей ZIP на тома при превышении лимита (анти-краш вкладки)
  function splitZipVolumes(entries, maxBytes) {
    const limit = maxBytes || CFG.MAX_ZIP_MB * 1024 * 1024;
    const size = (e) => 30 + (e.name ? e.name.length : 0) + (e.data ? (e.data.length || 0) : 0) + 46;
    const total = entries.reduce((s, e) => s + size(e), 0);
    if (total <= limit) return [entries];
    const vols = [];
    let cur = [], curSize = 0;
    for (const e of entries) {
      const s = size(e);
      if (cur.length && curSize + s > limit) { vols.push(cur); cur = []; curSize = 0; }
      cur.push(e); curSize += s;
    }
    if (cur.length) vols.push(cur);
    return vols;
  }
  async function volumesToDownloads(vols, baseName, statusFn) {
    for (let i = 0; i < vols.length; i++) {
      if (statusFn && vols.length > 1) statusFn('ZIP: том ' + (i + 1) + '/' + vols.length + '...');
      const name = vols.length > 1 ? baseName + '-part' + (i + 1) + '.zip' : baseName + '.zip';
      await downloadSmart(zipStore(vols[i]), name, 'application/zip');
    }
    if (vols.length > 1) toast('⚠ ZIP разбит на ' + vols.length + ' томов (лимит ' + CFG.MAX_ZIP_MB + ' МБ)', 5000);
  }

  async function renderPdfBlob(scraped, title) {
    await loadScript(LIBS.html2pdf, 'html2pdf');
    const holder = document.createElement('div');
    holder.style.cssText = 'position:fixed;left:-10000px;top:0;width:800px;background:#fff;';
    holder.innerHTML = '<style>' + htmlCss() + '</style>' + htmlBody(scraped, title);
    (document.body || document.documentElement).appendChild(holder);
    try {
      const pdf = await window.html2pdf().set({
        margin: 10, image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
      }).from(holder).toPdf().get('pdf');
      return pdf.output('blob');
    } finally { holder.remove(); }
  }
  function printFallback(scraped, title) {
    const w = window.open('', '_blank');
    if (!w) { setStatusSafe('PDF: popup заблокирован, откройте окно печати вручную.'); return; }
    w.document.open(); w.document.write(toHTML(scraped, title)); w.document.close();
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) {} }, 500);
  }
  function setStatusSafe(t) { try { console.warn('[UAICE] ' + t); } catch (e) {} }
  async function exportAsPDF(scraped, title) {
    // v27.3: PDF = печать по шаблону (5 стилей МАКТ-2026), без CDN, векторный текст.
    // Прежний CDN-путь (html2pdf, опция uaice_pdfcdn='1') сохранён как опция —
    // настоящий PDF-файл для вложений. Дефолт — печать по шаблону: документ реален,
    // пустой страницей быть не может (оффскрин-holder html2canvas не рендерил).
    if (safeStorageGet('uaice_pdfcdn') === '1') {
      try {
        const blob = await renderPdfBlob(scraped, title);
        downloadBlob(blob, sanitize(title) + '-' + ts() + '.pdf', 'application/pdf');
        return;
      } catch (e) { console.error('PDF CDN error:', e); }
    }
    const html = buildStyledHTML(scraped, title, {});
    const w = openPrintWindow(html);
    if (!w) {
      // Окно заблокировано: отдаём готовый шаблон файлом — открыть и Ctrl+P.
      downloadBlob(html, sanitize(title) + '-' + ts() + '.print.html', 'text/html;charset=utf-8');
      setStatusSafe('PDF: окно печати заблокировано — сохранён .print.html, откройте его и нажмите Ctrl+P.');
    } else {
      setStatusSafe('PDF: окно печати открыто — стиль выбирается в панели окна (запоминается).');
    }
  }
  async function saveInFormat(scraped, title, format) {
    if (format === 'pdf') { await exportAsPDF(scraped, title); return; }
    if (format === 'zip') {
      const entries = await buildZipEntries([{ title: title, url: location.href, scraped: scraped }], [], resolveInner(), null);
      await volumesToDownloads(splitZipVolumes(entries), sanitize(title) + '-' + ts(), null);
      return;
    }
    const f = contentFor(format, scraped, title);
    downloadBlob(f.content, sanitize(title) + '-' + ts() + '.' + f.ext, f.mime);
  }

  function buildMerged(results, innerFmt) {
    if (innerFmt === 'json') return JSON.stringify({ exporter: 'UACE v' + SCRIPT_VER, created: now(), chats: results.map((r) => ({ title: r.title, url: r.url, platform: platformName(r.scraped), messages: r.scraped.items })) }, null, 2);
    if (innerFmt === 'sharegpt') return JSON.stringify({ exporter: 'UACE v' + SCRIPT_VER, created: now(), chats: results.map((r) => ({ title: r.title, url: r.url, conversations: r.scraped.items.map((m) => ({ from: sharegptFrom(m.role), value: m.text || m.content })) })) }, null, 2);
    if (innerFmt === 'alpaca') return JSON.stringify({ exporter: 'UACE v' + SCRIPT_VER, created: now(), chats: results.map((r) => JSON.parse(toAlpaca(r.scraped, r.title))) }, null, 2);
    if (innerFmt === 'jsonl') return results.map((r) => toJSONL(r.scraped, r.title)).join('\n');
    if (innerFmt === 'html') {
      return buildStyledHTML(results.map((r) => ({ scraped: r.scraped, title: r.title, url: r.url })), 'AI Chats — ' + now(), {});
    }
    const sep = '='.repeat(60);
    return results.map((r, i) => {
      const f = contentFor(innerFmt === 'pdf' ? 'md' : innerFmt, r.scraped, r.title);
      return '\n\n' + sep + '\n' + (i + 1) + '. ' + r.title + '\n' + r.url + '\n' + sep + '\n\n' + f.content;
    }).join('\n');
  }

  async function finalizeResults(results, failures, format, inner, statusFn) {
    if (!results.length) {
      if (failures.length) downloadBlob(['# Не удалось', ''].concat(failures.map((f) => '- ' + f.title + ': ' + f.error)).join('\n'), '_FAILURES-' + ts() + '.txt', 'text/plain;charset=utf-8');
      return;
    }
    if (format === 'zip') {
      try {
        if (statusFn) statusFn('Собираю ZIP...');
        const entries = await buildZipEntries(results, failures, inner, statusFn);
        await volumesToDownloads(splitZipVolumes(entries), 'ai-chats-' + ts(), statusFn);
        return;
      } catch (e) { console.error(e); if (statusFn) statusFn('⚠ ZIP не удался, объединённый файл'); }
    }
    if (inner === 'pdf') {
      for (let i = 0; i < results.length; i++) {
        if (CANCEL) break;
        const r = results[i];
        if (statusFn) statusFn('PDF ' + progress(i, results.length, sanitize(r.title, 24)));
        try { await exportAsPDF(r.scraped, String(i + 1).padStart(3, '0') + '-' + r.title); } catch (e) {}
        await sleep(700);
      }
    } else {
      const merged = buildMerged(results, inner);
      const f = contentFor(inner, results[0].scraped, results[0].title);
      downloadBlob(merged, 'ai-chats-' + ts() + '.' + f.ext, f.mime);
    }
    if (failures.length) downloadBlob(['# Не удалось', ''].concat(failures.map((f) => '- ' + f.title + ': ' + f.error)).join('\n'), '_FAILURES-' + ts() + '.txt', 'text/plain;charset=utf-8');
  }

  // ============ САЙДБАР / СПИСОК ЧАТОВ (мерж v22 + v24) ============
  const UUID_RE = /([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i;

  function extractChatTarget(el) {
    if (!el) return { href: null, id: null };
    if (el.attributes) {
      for (let i = 0; i < el.attributes.length; i++) {
        const a = el.attributes[i];
        const v = a.value || '';
        if (a.name === 'href' && v) {
          try { return { href: new URL(v, location.href).href, id: null }; } catch (e) {}
        }
        const m = v.match(UUID_RE);
        if (m) return { href: null, id: m[1] };
        if (/^(data-(chat|conversation|session|thread|id)|id)$/i.test(a.name) && v.length >= 6 && v.length <= 80) {
          return { href: null, id: v };
        }
      }
    }
    const innerA = el.querySelector && el.querySelector('a[href]');
    if (innerA && innerA.href) return { href: innerA.href, id: null };
    const html = el.outerHTML || '';
    const m1 = html.match(UUID_RE);
    if (m1) return { href: null, id: m1[1] };
    try {
      const keys = Object.keys(el);
      for (let ki = 0; ki < keys.length; ki++) {
        const k = keys[ki];
        if (k.indexOf('__reactProps$') !== 0 && k.indexOf('__reactFiber$') !== 0) continue;
        let node = el[k];
        for (let depth = 0; depth < 10 && node; depth++) {
          const props = node.memoizedProps;
          if (props && typeof props === 'object') {
            const keys2 = Object.keys(props);
            for (let pi = 0; pi < keys2.length; pi++) {
              const pv = props[keys2[pi]];
              if (typeof pv === 'string') {
                const m = pv.match(UUID_RE);
                if (m) return { href: null, id: m[1] };
                if (/^(id|chatId|conversationId|sessionId|threadId|key)$/i.test(keys2[pi]) && pv.length >= 6 && pv.length <= 80) {
                  return { href: null, id: pv };
                }
                if (/^href$|^to$|^url$/i.test(keys2[pi]) && pv.length > 1) {
                  try { return { href: new URL(pv, location.href).href, id: null }; } catch (e) {}
                }
              } else if (pv && typeof pv === 'object') {
                const innerKeys = Object.keys(pv);
                for (let ii = 0; ii < innerKeys.length; ii++) {
                  const ipv = pv[innerKeys[ii]];
                  if (typeof ipv === 'string') {
                    const m = ipv.match(UUID_RE);
                    if (m) return { href: null, id: m[1] };
                  }
                }
              }
            }
          }
          node = node.return;
        }
      }
    } catch (e) {}
    return { href: null, id: null };
  }

  function buildChatUrl(id) {
    if (!id) return null;
    const platform = getPlatform();
    if (platform && platform.chatUrlPattern) return location.origin + platform.chatUrlPattern.replace('{id}', id);
    const m = location.pathname.match(/^(.*\/)(c|chat|conversation|app|thread)\/[^\/]+/i);
    if (m) return location.origin + m[1] + m[2] + '/' + id;
    return location.origin + '/c/' + id;
  }

  function tryReactOnClick(el) {
    try {
      const keys = Object.keys(el);
      for (let i = 0; i < keys.length; i++) {
        if (keys[i].indexOf('__reactProps$') !== 0) continue;
        const props = el[keys[i]];
        if (props && typeof props.onClick === 'function') {
          const evt = {
            type: 'click', target: el, currentTarget: el,
            nativeEvent: { button: 0, ctrlKey: false, metaKey: false, shiftKey: false, altKey: false },
            preventDefault: function () {}, stopPropagation: function () {},
            isDefaultPrevented: function () { return false; },
            isPropagationStopped: function () { return false; },
            persist: function () {}, defaultPrevented: false, bubbles: true, cancelable: true
          };
          props.onClick(evt);
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  // Строгий фильтр URL чата (мерж v22 + v24): сегменты + query-параметры + явные исключения
  function isChatUrl(href) {
    if (!href) return false;
    try {
      const u = new URL(href, location.href);
      if (u.origin !== location.origin) return false;
      if (/^\/(new|create|edit|settings|help|login|signup|logout|terms|privacy|about|contact|faq|legal|pricing|billing|account|profile|drive|create-image|cron-jobs|tasks|discover|explore|search|upgrade|download|auth|oauth|reset|verify)/i.test(u.pathname)) return false;
      if (/\/(chat|work|code|c|conversation|thread|app|gem|s|share|session|talk|a)\/[a-zA-Z0-9][a-zA-Z0-9_\/-]{7,}/i.test(u.pathname)) return true;
      if (/[?&](id|chat|conversation|thread|session)=/i.test(u.search)) return true;
      return false;
    } catch (e) { return false; }
  }

  const NAV_KEYWORDS = [
    'проекты','проект','новая папка','новый проект','vibe','work','code','chat','projects',
    'настройки','settings','профиль','profile','новый чат','new chat','помощь','help',
    'сообщество','community','обновления','updates','поиск','search','архив','archive',
    'избранное','library','библиотека','gpts','sora','explore','discover','temporary chat','временный чат',
    '新对话','新建对话','新聊天','新建会话','设置','帮助',
    'delete','удалить','rename','переименовать','pin','закрепить','share','поделиться',
    'все чаты','all chats','история','history','activity','gemini','extensions','расширения','gems',
    'notebooklm','new notebook','upgrade','обновить','попробовать','блокноты','недавние','artifacts',
    'customize','pinned','new','claude','images','scheduled','plugins','health','codex',
    'создание контента ии','запланированные задачи','диск','dola','поиск по чатам','новый блокнот','новая беседа'
  ];
  function normalizeNavKey(s) { return String(s || '').replace(/[\s.…,;:!?—–-]+$/g, '').toLowerCase().trim(); }
  function isNavKeyword(s) {
    if (!s) return false;
    const low = normalizeNavKey(s);
    if (!low || low.length > 40) return false;
    return NAV_KEYWORDS.indexOf(low) !== -1;
  }

  function isClickable(el) {
    if (!el) return false;
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'a' && el.hasAttribute && el.hasAttribute('href')) return true;
    if (tag === 'button') return true;
    const role = el.getAttribute ? (el.getAttribute('role') || '') : '';
    if (role === 'button' || role === 'link' || role === 'listitem' || role === 'option' || role === 'tab') return true;
    const tab = el.getAttribute ? el.getAttribute('tabindex') : null;
    if (tab !== null && tab !== undefined && tab !== '-1') return true;
    return false;
  }
  function isNavContainer(el) {
    if (!el) return false;
    const tag = (el.tagName || '').toLowerCase();
    const role = el.getAttribute ? (el.getAttribute('role') || '') : '';
    if (tag === 'mat-sidenav' || tag === 'bard-sidenav' || tag === 'side-navigation-v2') return true;
    if (tag === 'aside' || tag === 'nav' || role === 'navigation') return true;
    const c = (typeof el.className === 'string' ? el.className : '').toLowerCase();
    if (/sidenav|sidebar|side-nav|drawer|history-list|chat-list|conversation-list|side-bar|chat-aside|chat-history/.test(c)) return true;
    return false;
  }
  function isLeftSide(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const vw = window.innerWidth || document.documentElement.clientWidth || 1920;
      if (r.height < 100) return false;
      if (r.width < 20) return false;
      if (r.left > vw * 0.40) return false;
      if (r.left + r.width > vw * 0.65) return false;
      return true;
    } catch (e) { return false; }
  }
  function looksLikeCode(s) {
    if (!s) return true;
    const t = s.trim();
    if (t.length < 2) return true;
    if (/\b(is not defined|is not a function|TypeError|ReferenceError|SyntaxError)\b/.test(t)) return true;
    if (/^https?:\/\/\S+$/i.test(t)) return true;
    if (/^Thought for \d+/i.test(t)) return true;
    if (/^```/.test(t)) return true;
    return false;
  }
  function looksLikeChatItem(el) {
    if (!el || !isVisible(el)) return false;
    if (el.closest && el.closest('#' + UI_ID)) return false;
    if (isInChatArea(el)) return false;
    let t = txt(el);
    if (!t || t.length < 2) { const p = el.parentElement; if (p) t = txt(p); }
    if (!t || t.length < 2 || t.length > 120) return false;
    if (isNavKeyword(t) || isCssOrJs(t) || isSourceListing(t)) return false;
    if (t.indexOf('\n') !== -1) return false;
    if (looksLikeCode(t)) return false;
    if (t.indexOf('::') !== -1) return false;
    if (/^[#>*-]\s/.test(t)) return false;
    if (/[.…]{2,}\s*$/.test(t)) return false;
    if (/^[A-Za-z]{2,6}$/.test(t)) return false;
    return true;
  }

  function findLeftPanel() {
    const cands = [];
    const sels = 'mat-sidenav, bard-sidenav, side-navigation-v2, aside, nav, [role="navigation"], [class*="sidenav"], [class*="sidebar"], [class*="sider"], [class*="side-bar"], [class*="history"], [class*="conversation"], [class*="chat-aside"], [class*="chat-history"], [class*="chat-list"], #flow_chat_sidebar, nav[class*="panel-"]';
    let els = [];
    try { els = document.querySelectorAll(sels); } catch (e) { els = []; }
    els.forEach((el) => {
      try {
        if (el.closest && el.closest('#' + UI_ID)) return;
        if (!isLeftSide(el)) return;
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        const scrollable = /auto|scroll/.test(st.overflowY) || /auto|scroll/.test(st.overflow);
        let score = Math.max(r.height, 200) * (scrollable ? 2 : 1);
        if (isNavContainer(el)) score *= 4;
        const cc = el.querySelectorAll('a[href*="/a/chat/s/"], a[href*="/chat/"], a[href*="/c/"], [class*="conversation-item"]').length;
        if (cc > 0) score *= 5;
        cands.push({ el: el, score: score });
      } catch (e) {}
    });
    cands.sort((a, b) => b.score - a.score);
    return cands[0] ? cands[0].el : null;
  }

  function isDrawerOpen() {
    return !!document.querySelector('mat-sidenav.mat-drawer-opened, mat-sidenav.mat-drawer-opening, bard-sidenav.mat-drawer-opened, bard-sidenav.mat-drawer-opening, aside.mat-drawer-opened');
  }
  function isSidebarOpen() {
    if (isDrawerOpen()) return true;
    const panel = findLeftPanel();
    if (!panel) return false;
    const r = panel.getBoundingClientRect();
    return r.left >= -5 && r.width >= 20 && r.height >= 100;
  }
  async function waitForDrawerOpen(t) {
    const s = Date.now();
    while (Date.now() - s < t) {
      if (isDrawerOpen()) { await sleep(600); return true; }
      await sleep(150);
    }
    return isDrawerOpen();
  }
  async function dispatchFullClick(el) {
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    await sleep(120);
    try { if (typeof el.focus === 'function') el.focus(); } catch (e) {}
    let cx = 1, cy = 1;
    try {
      const r = el.getBoundingClientRect();
      cx = Math.floor(r.left + r.width / 2) || 1;
      cy = Math.floor(r.top + r.height / 2) || 1;
    } catch (e) {}
    const base = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, detail: 1 };
    try { el.dispatchEvent(new PointerEvent('pointerover', Object.assign({}, base, { pointerId: 1, pointerType: 'mouse', buttons: 0, isPrimary: true }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseover', Object.assign({}, base, { buttons: 0 }))); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerenter', Object.assign({}, base, { pointerId: 1, pointerType: 'mouse', buttons: 0, isPrimary: true }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseenter', Object.assign({}, base, { buttons: 0 }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousemove', base)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({}, base, { pointerId: 1, pointerType: 'mouse', buttons: 1, isPrimary: true }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', Object.assign({}, base, { buttons: 1 }))); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', Object.assign({}, base, { pointerId: 1, pointerType: 'mouse', buttons: 0, isPrimary: true }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, base, { buttons: 0 }))); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('click', base)); } catch (e) {}
    try { if (typeof el.click === 'function') el.click(); } catch (e) {}
  }
  async function tryOpenSidebar() {
    if (isSidebarOpen()) return true;
    const seen = new Set(), cands = [];
    const pushC = (el) => { if (!el || seen.has(el)) return; if (!isVisible(el)) return; seen.add(el); cands.push(el); };
    try { const q = document.querySelector('#sidebar-toggle-button'); if (q) pushC(q); } catch (e) {}
    const sels = ['button[aria-label*="Main menu" i]','button[aria-label*="Side panel" i]','button[aria-label*="sidebar" i]','button[aria-label*="sidenav" i]','button[aria-label*="Toggle sidebar" i]','button[aria-label*="menu" i]','button[aria-label*="Open" i]','button[aria-label*="Открыть" i]','button[aria-label*="меню" i]','[class*="sidebar-toggle"]','[class*="menu-toggle"]','[class*="hamburger"]','.slide-switch'];
    for (const sel of sels) {
      try { document.querySelectorAll(sel).forEach(pushC); } catch (e) {}
    }
    for (const c of cands) {
      try { await dispatchFullClick(c); if (await waitForDrawerOpen(2000)) return true; } catch (e) {}
    }
    return isSidebarOpen();
  }
  async function ensureSidebar() {
    let ok = await tryOpenSidebar();
    if (!ok) { await sleep(800); ok = await tryOpenSidebar(); }
    if (!ok) { await sleep(1200); ok = await tryOpenSidebar(); }
    return ok;
  }

  function extractItemsFromPanel(panel) {
    if (!panel) return [];
    const groups = {};
    panel.querySelectorAll('*').forEach((el) => {
      try {
        if (el.closest && el.closest('#' + UI_ID)) return;
        if (!looksLikeChatItem(el)) return;
        if (el.children.length > 10) return;
        let clickable = isClickable(el);
        if (!clickable) { const anc = el.closest && el.closest('a[href], button, [role="button"], [role="listitem"]'); if (anc) clickable = true; }
        if (!clickable) return;
        const key = el.tagName;
        (groups[key] = groups[key] || []).push(el);
      } catch (e) {}
    });
    let best = null;
    Object.keys(groups).forEach((key) => {
      const els = groups[key];
      if (els.length < 2) return;
      const cleanList = els.filter((el) => !els.some((o) => o !== el && o.contains(el)));
      if (cleanList.length < 2) return;
      if (!best || cleanList.length > best.items.length) best = { key: key, items: cleanList };
    });
    if (!best) return [];
    return best.items.map((el) => {
      const ex = extractChatTarget(el);
      const title = txt(el).slice(0, 120);
      return { el: el, href: (ex && ex.href) || '', title: title, dataId: (ex && ex.id) || null };
    });
  }

  function collectChatLinks(rootEl) {
    const root = rootEl || document;
    const out = [];
    const seen = new Set();
    const curUrl = location.href.split('?')[0].replace(/\/$/, '');
    const push = (item) => {
      if (!item || !item.el) return;
      if (seen.has(item.el)) return;
      for (let i = 0; i < out.length; i++) {
        if (out[i].el === item.el) return;
        if (out[i].el.contains(item.el) || item.el.contains(out[i].el)) return;
      }
      seen.add(item.el);
      out.push(item);
    };
    const platform = getPlatform();
    const hints = platform && platform.chatUrlHints;
    // A) платформенные URL-подсказки
    if (hints && hints.length) {
      try {
        root.querySelectorAll('a[href]').forEach((a) => {
          if (!isVisible(a)) return;
          const href = a.getAttribute('href') || '';
          let matched = false;
          for (const h of hints) { try { if (h.test(href)) { matched = true; break; } } catch (e) {} }
          if (!matched) return;
          if (!isChatUrl(a.href)) return;
          const t = txt(a);
          if (!t || t.length < 2 || t.length > 200) return;
          if (looksLikeCode(t) || isNavKeyword(t)) return;
          push({ el: a, href: a.href || '', title: t.slice(0, 120), dataId: null });
        });
      } catch (e) {}
    }
    // B) известные селекторы элементов чата
    try {
      const sel = 'a[aria-label="chat-item"], a.chat-item-drag-link, [class*="conversation-item"], [class*="chat-item"], [class*="history-item"], [class*="session-item"], [data-chat-id], [data-conversation-id], [data-session-id], [data-thread-id]';
      root.querySelectorAll(sel).forEach((el) => {
        if (!isVisible(el)) return;
        const t = txt(el);
        if (!t || t.length < 2 || t.length > 200) return;
        if (looksLikeCode(t) || isNavKeyword(t)) return;
        const extracted = extractChatTarget(el);
        const innerA = el.querySelector('a[href]');
        const dataId = el.getAttribute('data-chat-id') || el.getAttribute('data-conversation-id') || el.getAttribute('data-session-id') || el.getAttribute('data-thread-id') || (extracted && extracted.id) || null;
        const href = (innerA && innerA.href) || (extracted && extracted.href) || '';
        if (!href && !dataId) return;
        if (href && href.split('?')[0].replace(/\/$/, '') === curUrl) return;
        push({ el: el, href: href, title: t.slice(0, 120), dataId: dataId });
      });
    } catch (e) {}
    // C) все ссылки того же origin, похожие на чат
    try {
      root.querySelectorAll('a[href]').forEach((a) => {
        if (isInChatArea(a)) return;
        if (!isVisible(a)) return;
        const t = txt(a);
        if (!t || t.length < 2 || t.length > 200) return;
        if (isNavKeyword(t) || isCssOrJs(t) || isSourceListing(t) || looksLikeCode(t)) return;
        try { const u = new URL(a.href, location.href); if (u.origin !== location.origin) return; } catch (e) { return; }
        if (!isChatUrl(a.href)) return;
        if (a.href.split('?')[0].replace(/\/$/, '') === curUrl) return;
        push({ el: a, href: a.href || '', title: t.slice(0, 120), dataId: null });
      });
    } catch (e) {}
    // D) элементы левой панели (группировка по тегу)
    try {
      const panel = (root === document) ? findLeftPanel() : root;
      if (panel) extractItemsFromPanel(panel).forEach((it) => {
        if (it.href && it.href.split('?')[0].replace(/\/$/, '') === curUrl) return;
        push(it);
      });
    } catch (e) {}
    return out;
  }

  function scanContainers(selector) {
    let containers;
    try { containers = document.querySelectorAll(selector); } catch (e) { return null; }
    const cands = [];
    for (const c of containers) {
      if (c.closest && c.closest('#' + UI_ID)) continue;
      if (!isLeftSide(c)) continue;
      const links = collectChatLinks(c);
      if (links.length >= 2) cands.push({ container: c, items: links, score: links.length, via: 'container' });
    }
    cands.sort((a, b) => b.score - a.score);
    return cands[0] || null;
  }
  function findStructuralChatItems() {
    const panel = findLeftPanel();
    if (!panel) return null;
    const items = extractItemsFromPanel(panel);
    return items.length >= 2 ? { container: panel, items: items, score: items.length, via: 'left-panel' } : null;
  }
  function findClickableChatItems() {
    const panel = findLeftPanel();
    if (!panel) return null;
    const items = [];
    const curUrl = location.href.split('?')[0].replace(/\/$/, '');
    let nl = [];
    try { nl = panel.querySelectorAll('[role="button"], [role="link"], [role="listitem"], [tabindex]:not([tabindex="-1"]), button, li, a[aria-label="chat-item"], a.chat-item-drag-link, [class*="conversation-item"]'); } catch (e) {}
    for (const el of nl) {
      if (el.closest && el.closest('#' + UI_ID)) continue;
      if (!isVisible(el)) continue;
      if (el.children.length > 6) continue;
      const t = txt(el);
      if (!t || t.length < 2 || t.length > 120) continue;
      if (looksLikeCode(t) || isNavKeyword(t) || isCssOrJs(t)) continue;
      if (t.indexOf('\n') !== -1) continue;
      const href = el.href || '';
      if (href && href.split('?')[0].replace(/\/$/, '') === curUrl) continue;
      items.push({ el: el, href: href, title: t.slice(0, 120), dataId: null });
    }
    if (items.length >= 2) return { container: panel, items: items, score: items.length, via: 'click-items' };
    return null;
  }
  function findList() {
    const platform = getPlatform();
    const strategies = [];
    if (platform && platform.sidebarSelectors && platform.sidebarSelectors.length) {
      strategies.push({ name: 'platform', fn: () => scanContainers(platform.sidebarSelectors.join(',')) });
    }
    strategies.push({ name: 'generic', fn: () => scanContainers('nav,aside,[role="navigation"],[class*="sidebar"],[class*="history"],[class*="chat-list"],[class*="conversation-list"],[class*="sider"]') });
    strategies.push({ name: 'conversation-item', fn: () => {
      const items = [];
      try {
        document.querySelectorAll('[class*="conversation-item"], a[id^="conversation_"]').forEach((el) => {
          const t = txt(el);
          if (!t || t.length < 2) return;
          const href = el.href || '';
          if (href && href.split('?')[0] === location.href.split('?')[0]) return;
          items.push({ el: el, href: href, title: t.slice(0, 120), dataId: null });
        });
      } catch (e) {}
      return items.length >= 2 ? { container: null, items: items, score: items.length, via: 'conversation-item' } : null;
    } });
    strategies.push({ name: 'structural', fn: findStructuralChatItems });
    strategies.push({ name: 'click-items', fn: findClickableChatItems });
    for (const st of strategies) {
      try {
        const r = st.fn();
        if (r && r.items && r.items.length >= 2) return r;
      } catch (e) {}
    }
    // последний шанс: все ссылки документа
    const docLinks = collectChatLinks(document).filter((it) => it.href || it.dataId);
    if (docLinks.length >= 2) return { container: null, items: docLinks, score: docLinks.length, via: 'doc-links', fallback: true };
    return null;
  }
  async function prescrollList(container) {
    if (!container) return;
    const step = Math.max(200, Math.floor(container.clientHeight * 0.8));
    for (let k = 0; k < 4; k++) {
      container.scrollTop = 0; await sleep(150);
      for (let y = 0; y < container.scrollHeight; y += step) { container.scrollTop = y; await sleep(120); }
      container.scrollTop = container.scrollHeight; await sleep(200);
    }
    container.scrollTop = 0; await sleep(150);
  }

  // ============ МАНИФЕСТ (onlyNew) И СЕССИЯ (RESUME) — v26: IndexedDB + FNV-1a ============
  const MANIFEST_KEY = 'uaice_manifest_v1';
  const SESSION_KEY = 'uaice_bulk_v1';
  // FNV-1a 64-bit (BigInt): детерминированный хеш вместо коллидирующего «role:length»
  function hashString(s) {
    let h = 0xcbf29ce484222325n;
    const prime = 0x100000001b3n;
    const mask = 0xffffffffffffffffn;
    const text = String(s || '');
    for (let i = 0; i < text.length; i++) { h ^= BigInt(text.charCodeAt(i)); h = (h * prime) & mask; }
    return h.toString(16).padStart(16, '0');
  }
  function chatHash(s) {
    const items = (s && Array.isArray(s.items)) ? s.items : [];
    return hashString(items.map((x) => (x.role || 'unknown') + '\u0000' + (x.text || x.content || '')).join('\u0001'));
  }
  // Единый ключ манифеста для чтения И записи (фикс расхождения href/dataId/title)
  function manifestKey(it) {
    if (!it) return '';
    if (it.href) { try { const u = new URL(it.href, location.href); u.hash = ''; return u.href; } catch (e) {} }
    if (it.dataId) return 'id:' + String(it.dataId);
    return 'title:' + normalizeNavKey(it.title || '');
  }
  // v26: лёгкий отпечаток сайдбара для resume-выравнивания
  function fingerprintSidebar() {
    try {
      const list = findList();
      if (!list || !list.items) return '';
      return hashString(list.items.slice(0, 40).map((x) => (x.dataId || '') + '\u0000' + normalizeNavKey(x.title || '') + '\u0000' + (x.href || '')).join('\u0001'));
    } catch (e) { return ''; }
  }
  let MANIFEST_MEM = null;
  function loadManifest() { try { return JSON.parse(safeStorageGet(MANIFEST_KEY) || '{}'); } catch (e) { return {}; } }
  async function getManifest() {
    if (MANIFEST_MEM) return MANIFEST_MEM;
    const base = loadManifest();
    try {
      const rows = await idbGetAll();
      if (rows && rows.length) {
        const o = {};
        rows.forEach((r) => { if (r && r.id) o[r.id] = { hash: r.hash, exported_at: r.exported_at, title: r.title }; });
        MANIFEST_MEM = Object.assign({}, base, o);
        return MANIFEST_MEM;
      }
    } catch (e) {}
    MANIFEST_MEM = base;
    return MANIFEST_MEM;
  }
  let _persistTimer = null;
  function saveManifest(m) {
    MANIFEST_MEM = m || {};
    if (_persistTimer) clearTimeout(_persistTimer);
    _persistTimer = setTimeout(() => { flushManifest(); }, 400);
  }
  async function flushManifest() {
    const m = MANIFEST_MEM || loadManifest();
    try { safeStorageSet(MANIFEST_KEY, JSON.stringify(m)); } catch (e) {}
    const rows = Object.keys(m).map((k) => ({ id: k, hash: m[k].hash, exported_at: m[k].exported_at, title: m[k].title }));
    try { await idbPutMany(rows); } catch (e) {}
  }
  async function clearManifestAll() {
    MANIFEST_MEM = {};
    if (_persistTimer) { clearTimeout(_persistTimer); _persistTimer = null; }
    safeStorageRemove(MANIFEST_KEY);
    try { await idbClearMan(); } catch (e) {}
  }
  function loadSession() { try { const s = JSON.parse(safeStorageGet(SESSION_KEY) || 'null'); return (s && Array.isArray(s.items)) ? s : null; } catch (e) { return null; } }
  function saveSession(s) {
    try { s.sidebarFp = fingerprintSidebar(); } catch (e) {}
    safeStorageSet(SESSION_KEY, JSON.stringify(s));
  }
  function clearSession() { safeStorageRemove(SESSION_KEY); }

  function askOptions() {
    return {
      filter: (safeStorageGet('uaice_filter') || '').toLowerCase(),
      onlyNew: safeStorageGet('uaice_onlynew') === '1',
      exportThinking: safeStorageGet('uaice_think') === '1',
      stripThinking: safeStorageGet('uaice_strip') === '1'
    };
  }

  // ============ КОПИРОВАНИЕ ============
  async function copyTextToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(text); return; }
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
    (document.body || document.documentElement).appendChild(ta);
    ta.select(); document.execCommand('copy'); ta.remove();
  }
  async function copyCurrentMd(options) {
    await autoScroll(null);
    const scraped = scrape(options);
    if (!scraped.items.length) throw new Error('Сообщения не найдены');
    await copyTextToClipboard(toMarkdown(scraped, pageTitle()));
    return scraped.items.length;
  }
  // Промпт-перенос: диалог в формате для продолжения в другом AI (фича v24)
  async function copyContinuePrompt(options) {
    await autoScroll(null);
    const scraped = scrape(options);
    if (!scraped.items.length) throw new Error('Сообщения не найдены');
    const L = ['# Перенос диалога в другой AI', '', 'Продолжи диалог ниже. История от другого AI-ассистента:', ''];
    scraped.items.forEach((m) => {
      L.push(m.role === 'user' ? 'USER:' : 'ASSISTANT:');
      L.push(m.text || m.content);
      L.push('');
    });
    L.push('---', 'Продолжи с этого места. Не пересказывай, отвечай как продолжение.');
    await copyTextToClipboard(L.join('\n'));
    return scraped.items.length;
  }

  // ============ ЭКСПОРТ ТЕКУЩЕГО ЧАТА ============
  async function exportCurrent(format, options, statusFn) {
    if (statusFn) statusFn('Ищу сообщения...');
    await autoScroll(statusFn);
    let scraped = scrape(options);
    if (!scraped.items.length) {
      for (let i = 0; i < 20; i++) {
        await sleep(500);
        if (statusFn) statusFn('Жду текста... (' + (i + 1) + ')');
        scraped = scrape(options);
        if (scraped.items.length > 0) break;
      }
    }
    if (!scraped.items.length) {
      const snap = snapshotScrape();
      if (snap) {
        await saveInFormat(snap, pageTitle() + '-snapshot', format === 'zip' ? 'md' : format);
        return { count: 1, snapshot: true };
      }
      debugDump();
      throw new Error('Сообщения не найдены. F12 → Console.');
    }
    await saveInFormat(scraped, pageTitle(), format);
    return { count: scraped.items.length };
  }

  // ============ v26.1 (из RESTORED): АВТО-ПРОДОЛЖЕНИЕ ПОСЛЕ URL-ПЕРЕХОДА ============
  function sameUrl(a, b) {
    try { return String(a || '').split('?')[0].replace(/\/+$/, '') === String(b || '').split('?')[0].replace(/\/+$/, ''); } catch (e) { return false; }
  }
  function urlNavAllowed() { return safeStorageGet('uaice_urlnav') !== '0'; }
  function urlNavCount() { return Number(safeStorageGet('uaice_nav_n') || '0') || 0; }
  function urlNavBump() { safeStorageSet('uaice_nav_n', String(urlNavCount() + 1)); }
  function navByURL(href) {
    if (!href || sameUrl(href, location.href)) return false; // уже здесь — цикла не будет
    if (!urlNavAllowed() || urlNavCount() >= 12) return false; // кап: защита от циклов навигации
    urlNavBump();
    safeStorageSet('uaice_nav', '1'); // после перезагрузки boot продолжит сессию сам
    try { location.assign(href); return true; } catch (e) { return false; }
  }

  // ===== АКТИВАЦИЯ ЧАТА В САЙДБАРЕ (переключение на чат) =====
  // ФИКС v25.0.2: в v25.0.0/v25.0.1 exportAllSameTab вызывал activateChatItem(),
  // но сама функция нигде не определялась → ReferenceError на каждом чате масс-сбора
  // («✗ <чат>: activateChatItem is not defined» — только заголовки, без содержимого).
  async function activateChatItem(it) {
    if (!it) return false;
    let el = (it.el && it.el.isConnected) ? it.el : null;
    // RESUME: в сессии el не сериализуется — переищем элемент по заголовку в сайдбаре
    if (!el && it.title) {
      try {
        const list = findList();
        if (list && Array.isArray(list.items)) {
          const t = String(it.title).trim().toLowerCase();
          for (const x of list.items) {
            if (x && x.el && x.el.isConnected && String(x.title || '').trim().toLowerCase() === t) { el = x.el; break; }
          }
        }
      } catch (e) {}
    }
    const hrefBefore = location.href;
    const fpBefore = fingerprint();
    if (el) {
      try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
      await sleep(120);
      // Цели клика: сам элемент, внутренняя ссылка/кнопка, внешняя ссылка-обёртка
      const targets = [el];
      try {
        const inner = el.querySelector('a[href],button,[role="link"],[role="button"],[role="menuitem"]');
        if (inner) targets.push(inner);
        const outer = el.closest && el.closest('a[href],[role="link"]');
        if (outer) targets.push(outer);
      } catch (e) {}
      for (let k = 0; k < targets.length; k++) {
        if (CANCEL) return true;
        const t = targets[k];
        // 1) обычный click(), 2) React synthetic onClick, 3) полная серия мышиных событий
        try { t.click(); } catch (e) {}
        try { tryReactOnClick(t); } catch (e) {}
        try {
          ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach((type) => {
            t.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
          });
        } catch (e) {}
        await sleep(300);
        if (location.href !== hrefBefore || fingerprint() !== fpBefore) return true;
      }
      // SPA ещё думает — дать последнюю отсрочку и проверить смену контента
      try {
        const changed = await waitForContentChange(hrefBefore, fpBefore, 2500);
        if (changed) return true;
      } catch (e) {}
    }
    // ПОСЛЕДНИЙ РЕЗЕРВ (v26.1): прямая навигация по href/dataId (полная перезагрузка).
    // Сессия сохранена; перед переходом ставится флаг uaice_nav — после рестарта
    // boot продолжит масс-сбор сам (авто-резюм), без ручного «▶ Продолжить».
    let url = it.href || '';
    if (!url && it.dataId) { try { url = buildChatUrl(it.dataId) || ''; } catch (e) {} }
    if (url && navByURL(url)) { await sleep(1200); return true; }
    return false;
  }

  // ============ МАССОВЫЙ ЭКСПОРТ (тот же таб) ============
  async function exportAllSameTab(format, options, statusFn, session) {
    let items = null, startIdx = 0;
    if (session && Array.isArray(session.items) && session.items.length) {
      items = session.items;
      startIdx = Math.max(0, Math.min(session.idx || 0, items.length - 1));
      if (statusFn) statusFn('▶ Продолжаю с ' + (startIdx + 1) + '/' + items.length);
      await ensureSidebar();
      // v26: перепривязка el по нормализованному ключу (сайдбар мог перерисоваться)
      try {
        const list = findList();
        if (list && Array.isArray(list.items)) {
          const byKey = new Map();
          list.items.forEach((x) => { const k = manifestKey(x); if (k && !byKey.has(k)) byKey.set(k, x.el); });
          let re = 0;
          items.forEach((it) => { const el = byKey.get(manifestKey(it)); if (el) { it.el = el; re++; } });
          const cur = fingerprintSidebar();
          if (session.sidebarFp && cur && cur !== session.sidebarFp) console.log('[UAICE] Сайдбар изменился с прошлого запуска — привязано ' + re + '/' + items.length);
        }
      } catch (e) {}
    } else {
      await ensureSidebar();
      let list = findList();
      if (list && list.container) { await prescrollList(list.container); list = findList() || list; }
      if (!list) throw new Error('Список чатов не найден.');
      const deduped = [], seen = new Set();
      list.items.forEach((it) => {
        const key = it.href || it.dataId || it.el;
        if (!key || seen.has(key)) return;
        if (!it.title || it.title.length < 2) return;
        seen.add(key);
        let id = it.dataId, href = it.href;
        if (!id && it.el) {
          const ex = extractChatTarget(it.el);
          if (ex.id) id = ex.id;
          if (!href && ex.href) href = ex.href;
        }
        deduped.push({ title: it.title, href: href || '', dataId: id || null, el: it.el });
      });
      if (deduped.length < 2) {
        console.log('[UAICE] Сырых элементов списка: ' + (list.items ? list.items.length : 0) + ', после дедупа: ' + deduped.length);
        throw new Error('В списке меньше двух чатов.');
      }
      items = deduped;
    }
    if (options && options.filter) {
      items = items.filter((it) => (it.title || '').toLowerCase().indexOf(options.filter) !== -1);
      if (!items.length) { clearSession(); throw new Error('Фильтр "' + options.filter + '" не дал совпадений.'); }
    }
    if (statusFn) statusFn('Найдено ' + items.length + ' чатов.');
    if (!session) saveSession({ mode: 'same', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId })), idx: 0 });

    const results = [], failures = [];
    const manifest = await getManifest();
    let lastChatFp = '', skipped = 0;

    for (let i = startIdx; i < items.length; i++) {
      if (CANCEL) { if (statusFn) statusFn('⏹ Остановлено. ' + progress(i, items.length, 'Продолжите кнопкой ▶')); saveSession({ mode: 'same', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId })), idx: i }); return { results, failures, total: items.length, skipped, stopped: true }; }
      const it = items[i];
      if (statusFn) statusFn(progress(i, items.length, it.title.slice(0, 30)));
      try {
        const beforeHref = location.href;
        const fpBefore = fingerprint();
        const activated = await activateChatItem(it);
        if (!activated) throw new Error('клик не сработал — используйте "🗂 Все (вкладками)"');
        const ok = await waitStable(fpBefore, beforeHref);
        if (!ok) throw new Error('контент не догрузился');
        await autoScroll(statusFn);
        await sleep(500);
        const scraped = scrape(options);
        if (!scraped.items.length) throw new Error('сообщения не найдены');
        const chatFp = chatHash(scraped);
        const mkey = manifestKey(it);
        if (options && options.onlyNew) {
          if (manifest[mkey] && manifest[mkey].hash === chatFp) {
            skipped++;
            console.log('  ⏭ ' + it.title + ' (уже экспортирован)');
            continue;
          }
        }
        if (chatFp === lastChatFp && location.href === beforeHref) throw new Error('дубликат');
        lastChatFp = chatFp;
        results.push({ title: it.title, scraped: scraped, url: location.href });
        manifest[mkey] = { hash: chatFp, exported_at: new Date().toISOString(), title: it.title };
        saveManifest(manifest);
        console.log('  ✓ ' + it.title + ' — ' + scraped.items.length);
      } catch (e) {
        console.warn('  ✗ ' + it.title + ': ' + e.message);
        failures.push({ title: it.title, url: it.href || '', error: e.message });
      }
      saveSession({ mode: 'same', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId })), idx: i + 1 });
      await sleep(300);
    }
    clearSession();
    await flushManifest();
    return { results, failures, total: items.length, skipped };
  }

  // ============ МАССОВЫЙ ЭКСПОРТ (ДОЧЕРНИЕ ВКЛАДКИ) ============
  let childJob = null;
  window.addEventListener('message', (event) => {
    if (event.source === window) return;
    try { if (event.origin && event.origin !== 'null' && event.origin !== location.origin) return; } catch (e) {}
    const d = event.data;
    if (!d || d.type !== MSG_REQ || !d.nonce) return;
    if (tabsExportRunning) return;
    const respond = (payload) => {
      try { event.source.postMessage(Object.assign({ type: MSG_RES, nonce: d.nonce }, payload), event.origin === 'null' ? '*' : event.origin); } catch (e) {}
    };
    if (childJob && childJob.nonce === d.nonce) { childJob.promise.then(respond, respond); return; }
    if (childJob) return; // заняты другим nonce — родитель повторит пинг
    const promise = (async () => {
      try {
        await autoScroll(null);
        await waitStable(fingerprint(), location.href);
        const scraped = scrape(d.options || {});
        return { ok: scraped.items.length > 0, url: location.href, title: pageTitle() || document.title, data: scraped };
      } catch (e) { return { ok: false, url: location.href, title: document.title, error: String(e && e.message || e) }; }
    })();
    childJob = { nonce: d.nonce, promise: promise };
    const release = () => { if (childJob && childJob.nonce === d.nonce) childJob = null; };
    promise.then(release, release);
    promise.then(respond, respond);
  });

  function waitForChildResult(child, nonce, timeout, options) {
    return new Promise((resolve) => {
      let done = false, timer = null, pingTimer = null;
      const finish = (v) => {
        if (done) return; done = true;
        try { window.removeEventListener('message', listener); } catch (e) {}
        if (timer) clearTimeout(timer);
        if (pingTimer) clearInterval(pingTimer);
        resolve(v);
      };
      const listener = (event) => {
        const d = event.data;
        if (!d || d.type !== MSG_RES || d.nonce !== nonce) return;
        if (event.source !== child) return;
        finish(d);
      };
      window.addEventListener('message', listener);
      timer = setTimeout(() => finish({ ok: false, error: 'тайм-аут дочерней вкладки' }), timeout);
      const ping = () => {
        try { child.postMessage({ type: MSG_REQ, nonce: nonce, options: options || {} }, '*'); }
        catch (e) { finish({ ok: false, error: String(e && e.message || e) }); }
      };
      ping();
      pingTimer = setInterval(() => { if (!done) ping(); }, 1500);
    });
  }

  async function exportAllTabs(format, options, statusFn, session) {
    let items = null, startIdx = 0;
    if (session && Array.isArray(session.items) && session.items.length) {
      items = session.items;
      startIdx = Math.max(0, Math.min(session.idx || 0, items.length - 1));
      await ensureSidebar();
    } else {
      await ensureSidebar();
      let list = findList();
      if (list && list.container) { await prescrollList(list.container); list = findList() || list; }
      if (!list) throw new Error('Список чатов не найден.');
      const deduped = [], seen = new Set();
      list.items.forEach((it) => {
        let href = it.href;
        if (!href && it.dataId) href = buildChatUrl(it.dataId);
        if (!href && it.el) {
          const ex = extractChatTarget(it.el);
          if (ex.href) href = ex.href;
          else if (ex.id) href = buildChatUrl(ex.id);
        }
        if (!href) return;
        if (seen.has(href)) return;
        if (!it.title || it.title.length < 2) return;
        seen.add(href);
        deduped.push({ title: it.title, href: href, dataId: it.dataId || null });
      });
      if (deduped.length < 2) throw new Error('Меньше двух чатов с URL.');
      items = deduped;
    }
    if (options && options.filter) {
      items = items.filter((it) => (it.title || '').toLowerCase().indexOf(options.filter) !== -1);
      if (!items.length) { clearSession(); throw new Error('Фильтр "' + options.filter + '" не дал совпадений.'); }
    }
    if (!session) saveSession({ mode: 'tabs', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId || null })), idx: 0 });

    tabsExportRunning = true;
    const results = [], failures = [];
    const manifest = await getManifest();
    let skipped = 0;
    try {
      for (let i = startIdx; i < items.length; i++) {
        if (CANCEL) {
          if (statusFn) statusFn('⏹ Остановлено. ' + progress(i, items.length, 'Продолжите кнопкой ▶'));
          saveSession({ mode: 'tabs', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId || null })), idx: i });
          return { results, failures, total: items.length, skipped, stopped: true };
        }
        const it = items[i];
        if (statusFn) statusFn('Вкладки ' + progress(i, items.length, it.title.slice(0, 26)));
        const nonce = Date.now() + '-' + Math.random().toString(36).slice(2);
        let child = null;
        try {
          child = window.open(it.href, '_blank');
          if (!child) throw new Error('POPUP_BLOCKED');
          await sleep(800);
          const response = await waitForChildResult(child, nonce, CFG.TAB_CHILD_TIMEOUT, options);
          if (!response.ok) throw new Error(response.error || 'нет данных');
          if (!response.data || !Array.isArray(response.data.items) || !response.data.items.length) throw new Error('пусто');
          const chatFp = chatHash(response.data);
          const mkey = manifestKey(it);
          if (options && options.onlyNew) {
            if (manifest[mkey] && manifest[mkey].hash === chatFp) { skipped++; continue; }
          }
          results.push({ title: response.title || it.title, url: response.url || it.href, scraped: response.data });
          manifest[mkey] = { hash: chatFp, exported_at: new Date().toISOString(), title: it.title };
          saveManifest(manifest);
        } catch (e) {
          const msg = e.message === 'POPUP_BLOCKED' ? 'popup заблокирован' : String(e && e.message || e);
          failures.push({ title: it.title, url: it.href, error: msg });
          if (e.message === 'POPUP_BLOCKED' && results.length === 0 && i === 0) throw new Error('Всплывающие окна заблокированы.');
        } finally { try { if (child) child.close(); } catch (e) {} }
        saveSession({ mode: 'tabs', fmt: format, items: items.map((x) => ({ title: x.title, href: x.href, dataId: x.dataId || null })), idx: i + 1 });
        await sleep(200);
      }
    } finally { tabsExportRunning = false; }
    clearSession();
    await flushManifest();
    return { results, failures, total: items.length, skipped };
  }

  async function exportAll(format, mode, options, statusFn, session) {
    const inner = format === 'zip' ? resolveInner() : format;
    const outcome = (mode === 'tabs')
      ? await exportAllTabs(format, options, statusFn, session)
      : await exportAllSameTab(format, options, statusFn, session);
    await finalizeResults(outcome.results, outcome.failures, format, inner, statusFn);
    try { toast('✅ Готово: ' + outcome.results.length + ' чатов' + (outcome.failures.length ? ', ошибок: ' + outcome.failures.length : ''), 3000); } catch (e) {}
    return { ok: outcome.results.length, fail: outcome.failures.length, total: outcome.total, skipped: outcome.skipped || 0, stopped: !!outcome.stopped };
  }

  // ============ ДИАГНОСТИКА ============
  function debugDump() {
    try { console.groupCollapsed('%c[UAICE v' + SCRIPT_VER + '] DEBUG', 'color:#4af;font-weight:bold'); } catch (e) {}
    console.log('URL:', location.href);
    const platform = getPlatform();
    console.log('Платформа:', platform ? platform.name : 'не определена');
    const s = scrape({ exportThinking: true });
    console.log('Найдено:', s.items.length, 'источник:', s.source, '| картинок:', s.images.length, '| вложений:', s.attachments.length);
    s.items.slice(0, 20).forEach((m, i) => console.log('  [' + i + '] role=' + m.role + ' len=' + (m.text || '').length + ' text="' + (m.text || '').slice(0, 120) + '..."'));
    const sc = findScrollContainer();
    console.log('Скролл-контейнер:', sc ? { clientHeight: sc.clientHeight, scrollHeight: sc.scrollHeight } : null);
    const list = findList();
    console.log('Список чатов:', list ? list.items.length + ' (via ' + list.via + ')' : 'НЕ НАЙДЕН');
    if (list) console.table(list.items.slice(0, 30).map((x, i) => ({ idx: i, title: String(x.title || '').slice(0, 50), href: String(x.href || '').slice(0, 70), dataId: x.dataId || '' })));
    const sess = loadSession();
    if (sess) console.log('Незавершённый экспорт:', sess.idx + '/' + sess.items.length, 'формат:', sess.fmt, 'режим:', sess.mode);
    try { console.groupEnd(); } catch (e) {}
    return s;
  }

  function exportDebugReport() {
    const platform = getPlatform();
    const report = {
      meta: { exporter: 'UACE v' + SCRIPT_VER, generated_at: new Date().toISOString(), url: location.href, userAgent: navigator.userAgent },
      environment: {
        hostname: location.hostname, pathname: location.pathname,
        platform: platform ? platform.name : null,
        msgSelectors: platform ? platform.msgSelectors : [],
        sidebarSelectors: platform ? (platform.sidebarSelectors || []) : []
      },
      dom: {
        totalNodes: document.querySelectorAll('*').length,
        links: document.querySelectorAll('a[href]').length,
        shadowRoots: collectShadowRoots().length,
        chatClassEls: document.querySelectorAll('[class*="chat"],[class*="message"]').length
      },
      scrape: (function () { try { const s = scrape({}); return { items_count: s.items.length, source: s.source, images: s.images.length }; } catch (e) { return { error: String(e && e.message || e) }; } })(),
      list: (function () { try { const l = findList(); return l ? { via: l.via, count: l.items.length } : null; } catch (e) { return { error: String(e && e.message || e) }; } })(),
      session: loadSession()
    };
    downloadBlob(JSON.stringify(report, null, 2), 'uaice-debug-' + ts() + '.json', 'application/json;charset=utf-8');
  }

  function debugSniffer() {
    function snap(el, depth, maxDepth) {
      if (!el || depth > maxDepth) return null;
      let r;
      try { r = el.getBoundingClientRect(); } catch (e) { r = { width: 0, height: 0, left: 0, top: 0 }; }
      const vis = r.width > 0 && r.height > 0;
      let t = '';
      if (el.children.length === 0) { try { t = dedupeText((el.textContent || '').trim()).slice(0, 100); } catch (e) {} }
      const attrs = {};
      for (let i = 0; i < el.attributes.length; i++) {
        const a = el.attributes[i];
        if (/^data-|^aria-|^role$|^href$|^id$|^class$/i.test(a.name)) attrs[a.name] = String(a.value).slice(0, 120);
      }
      const kids = [];
      if (depth < maxDepth) for (let j = 0; j < el.children.length && j < 30; j++) { const s = snap(el.children[j], depth + 1, maxDepth); if (s) kids.push(s); }
      return { tag: el.tagName.toLowerCase(), cls: (typeof el.className === 'string' ? el.className : '').slice(0, 200), id: el.id || '', attrs: attrs, rect: [Math.round(r.width), Math.round(r.height), Math.round(r.left), Math.round(r.top)], vis: vis, text: t, childCount: el.children.length, children: kids };
    }
    const platform = getPlatform();
    const report = { meta: { url: location.href, hostname: location.hostname, ver: SCRIPT_VER, ts: now() }, platform: platform ? platform.name : null, leftPanel: null, chatItemCandidates: [], messageCandidates: [], summary: {} };
    try { const lp = findLeftPanel(); if (lp) report.leftPanel = snap(lp, 0, 3); } catch (e) {}
    try { const l = findList(); if (l) report.chatItemCandidates = l.items.slice(0, 40).map((it) => ({ title: (it.title || '').slice(0, 80), href: (it.href || '').slice(0, 120) })); } catch (e) {}
    try {
      const m = findMessages();
      if (m) report.messageCandidates = m.items.slice(0, 40).map((el) => ({ tag: el.tagName.toLowerCase(), cls: (typeof el.className === 'string' ? el.className : '').slice(0, 120), textLen: (txt(el) || '').length, text: (txt(el) || '').slice(0, 100) }));
    } catch (e) {}
    report.summary = { chatItems: report.chatItemCandidates.length, messageCandidates: report.messageCandidates.length, sidebarDetected: !!report.leftPanel };
    downloadBlob(JSON.stringify(report, null, 2), 'uaice-sniffer-' + sanitize(location.hostname) + '-' + ts() + '.json', 'application/json;charset=utf-8');
  }

  // ============ UI v27.1 HUMAN-FIRST (по нормам MAKT-2026 / GOLOGRAMMA) ============
  // Девять норм вшиты в панель: контраст WCAG 2.2 1.4.3 (без чистого ч/б 21:1),
  // APCA Lc75, строка 45-75 знаков, мерцание 0 Гц, тёплый вечер (Harvard, 460-480 нм),
  // цели касания >=44px, поле зрения 4-6 контролов (Коэн 2015: 4±1), ноль попапов
  // (Gloria Mark: 23 мин возврата), кегль >=14px, без тонких начертаний.
  // Автоном по построению: system-ui шрифты, ноль CDN по умолчанию (PDF = печать браузера).
  // v27.1: акцент панели берётся из системы пользователя (CSS Color 4: AccentColor) с автоподгонкой
  // контраста ≥4.5:1 под текущую тему; симпатичный сегментный переключатель режима вшит в шапку
  // панели (радиогруппа: стрелки ←→, Home/End, roving tabindex); живая перекраска при смене
  // темы/акцента ОС (matchMedia + focus + visibilitychange).

  // --- Палитры (просчитаны по WCAG; чистые чёрный/белый запрещены — Zhang 2023) ---
  const HF_PALETTES = {
    light: { bg:'#fbfbfd', surface:'#ffffff', tx:'#1d1d1f', tx2:'#55555c', line:'#d9d9e0',
             accent:'#0b66c3', accentTx:'#ffffff', ok:'#1d7a3c', warn:'#a04b00',
             btn:'#ffffff', btnHover:'#f0f0f4', btnTx:'#1d1d1f', ring:'rgba(11,102,195,.55)' },
    dark:  { bg:'#1d1d24', surface:'#26262e', tx:'#f2f2f6', tx2:'#b9b9c3', line:'#43434e',
             accent:'#74b3ff', accentTx:'#10131a', ok:'#6fd08c', warn:'#ffb066',
             btn:'#2d2d37', btnHover:'#35353f', btnTx:'#f2f2f6', ring:'rgba(116,179,255,.6)' },
    warm:  { bg:'#f6efe2', surface:'#fdf8ee', tx:'#3a3226', tx2:'#6b5f4c', line:'#d8ccb4',
             accent:'#8a5a00', accentTx:'#ffffff', ok:'#4a6b1f', warn:'#a04b00',
             btn:'#fdf8ee', btnHover:'#f1e8d6', btnTx:'#3a3226', ring:'rgba(138,90,0,.5)' }
  };
  function hfTheme() {
    const t = safeStorageGet('uaice_theme') || 'auto';
    // v27.1: явный «Тепло» теперь честно форсится (в v27.0 кнопка писала 'warm', но читалась только вечером)
    if (t === 'light' || t === 'dark' || t === 'warm') return t;
    // auto: вечер после 20:00 и утро до 07:00 — тёплый режим (синий свет/мелатонин, Harvard)
    const evening = safeStorageGet('uaice_evening') !== '0';
    const h = new Date().getHours();
    if (evening && (h >= 20 || h < 7)) return 'warm';
    try { if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark'; } catch (e) {}
    return 'light';
  }
  function hfMotionOn() {
    if (safeStorageGet('uaice_motion') === '0') return false;
    try { if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false; } catch (e) {}
    return true;
  }
  // WCAG-контраст живьём — паспорт панели считает сам, не ссылается на чужие обещания
  function hfLum(hex) {
    const c = hex.replace('#', '');
    const v = [0, 2, 4].map((i) => {
      let x = parseInt(c.slice(i, i + 2), 16) / 255;
      return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  function hfContrast(fg, bg) {
    const l1 = hfLum(fg), l2 = hfLum(bg);
    return ((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05));
  }

  // --- v27.1: системный акцент ОС (CSS Color 4: AccentColor) — «цвет панели как у пользователя в системе» ---
  // Пробный элемент читает computed color ключевого слова AccentColor (Chromium 93+/Firefox 118+/Safari 16.4+).
  // Движки без поддержки отдают чёрный/серый — берём только насыщенные цвета, иначе остаёмся на эталоне.
  let hfSysAccentCache = null;
  function hfSystemAccent() {
    if (hfSysAccentCache) return hfSysAccentCache;
    try {
      const pr = document.createElement('span');
      pr.style.cssText = 'color:AccentColor;position:absolute;visibility:hidden;pointer-events:none;';
      (document.head || document.documentElement).appendChild(pr);
      const cs = getComputedStyle(pr).color || '';
      pr.remove();
      const m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i.exec(cs);
      if (!m) return null;
      const rgb = [+m[1], +m[2], +m[3]];
      const mx = Math.max(rgb[0], rgb[1], rgb[2]) / 255, mn = Math.min(rgb[0], rgb[1], rgb[2]) / 255;
      if (mx < 0.08 || (mx - mn) / mx < 0.18) return null; // вырожденный ответ движка — эталонный акцент
      hfSysAccentCache = rgb;
      return rgb;
    } catch (e) { return null; }
  }
  function hfRgbToHex(rgb) {
    return '#' + rgb.map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('');
  }
  function hfShiftLum(rgb, k) { // k>0 — светлее, k<0 — темнее
    const f = (x) => (k >= 0 ? x + (255 - x) * k : x * (1 + k));
    return [f(rgb[0]), f(rgb[1]), f(rgb[2])];
  }
  // Подгонка по норме 1 (WCAG ≥4.5:1): двигаем светлоту ОТ фона темы, пока контраст не дотянут.
  // Светлые темы — акцент темнеет, тёмная — светлеет; оттенок системы сохраняется.
  // Проход 2 — «ловушка средней светлоты»: текст НА акценте (тумблер переключателя) тоже обязан
  // дать ≥4.5:1, поэтому акцент уводится дальше, пока обе проверки не сойдутся.
  function hfTuneAccent(rgb, bgHex) {
    let c = rgb.slice();
    const dir = hfLum(hfRgbToHex(rgb)) > hfLum(bgHex) ? 1 : -1;
    for (let i = 0; i < 60 && hfContrast(hfRgbToHex(c), bgHex) < 4.5; i++) c = hfShiftLum(c, dir * 0.04);
    if (hfContrast(hfRgbToHex(c), bgHex) < 4.5) return null;
    for (let i = 0; i < 60 && hfContrast(hfPickAccentTx(hfRgbToHex(c)), hfRgbToHex(c)) < 4.5; i++) c = hfShiftLum(c, dir * 0.04);
    const hex = hfRgbToHex(c);
    return (hfContrast(hex, bgHex) >= 4.5 && hfContrast(hfPickAccentTx(hex), hex) >= 4.5) ? c : null;
  }
  // Текст на акценте: без чистых чёрного/белого (Zhang 2023), выбор по контрасту ≥4.5:1
  function hfPickAccentTx(accentHex) {
    return hfContrast(accentHex, '#f7f7fa') >= hfContrast(accentHex, '#10131a') ? '#f7f7fa' : '#10131a';
  }
  // Акцент ОС меняется вне страницы — кэш сбрасывается, панель переспрашивает при возврате фокуса
  try {
    const hfInv = () => { hfSysAccentCache = null; };
    window.addEventListener('focus', hfInv, true);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) hfInv(); });
  } catch (e) {}

  function injectModernStyles() {
    if (document.getElementById(UI_ID + '-styles')) return;
    const css = `
#${UI_ID}{position:fixed;right:16px;bottom:16px;z-index:2147483647;font:14px/1.6 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;color:var(--hf-tx);}
#${UI_ID} .box{display:flex;flex-direction:column;gap:8px;background:var(--hf-bg);padding:12px;border-radius:14px;border:1px solid var(--hf-line);box-shadow:0 8px 30px rgba(0,0,0,.22);min-width:262px;max-width:340px;max-height:88vh;overflow-y:auto;overflow-x:hidden;box-sizing:border-box;}
#${UI_ID} button{border:1px solid var(--hf-line);border-radius:9px;padding:9px 12px;min-height:44px;cursor:pointer;font:inherit;font-weight:400;color:var(--hf-btn-tx);background:var(--hf-btn);text-align:left;box-sizing:border-box;}
#${UI_ID} button:hover:not(:disabled){background:var(--hf-btn-hover);}
#${UI_ID} button:disabled{opacity:.45;cursor:not-allowed;}
#${UI_ID} button:focus-visible, #${UI_ID} select:focus-visible, #${UI_ID} input:focus-visible, #${UI_ID} summary:focus-visible{outline:2px solid var(--hf-accent);outline-offset:2px;}
#${UI_ID} select{min-height:44px;background:var(--hf-surface);color:var(--hf-tx);border:1px solid var(--hf-line);border-radius:9px;padding:4px 8px;font:inherit;flex:1;}
#${UI_ID} .status{font-size:14px;line-height:1.6;color:var(--hf-tx);max-width:65ch;white-space:pre-wrap;text-align:left;overflow-wrap:anywhere;}
#${UI_ID} .mini{font-size:12px;line-height:1.5;color:var(--hf-tx2);}
#${UI_ID} .grip{display:flex;align-items:center;justify-content:space-between;gap:6px;cursor:move;user-select:none;-webkit-user-select:none;font-size:14px;font-weight:600;line-height:1.3;padding:1px 2px;}
#${UI_ID} .grip .title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
#${UI_ID} .grip button{flex:0 0 auto;min-height:44px;min-width:44px;padding:4px 10px;text-align:center;font-size:14px;}
#${UI_ID} .row2{display:flex;gap:8px;align-items:stretch;}
#${UI_ID} .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
#${UI_ID} .stop{grid-column:1 / -1;text-align:center;border-color:var(--hf-warn);color:var(--hf-warn);}
#${UI_ID} details{border:1px solid var(--hf-line);border-radius:9px;background:var(--hf-surface);}
#${UI_ID} summary{list-style:none;cursor:pointer;padding:9px 12px;min-height:44px;display:flex;align-items:center;font-weight:400;color:var(--hf-btn-tx);}
#${UI_ID} summary::-webkit-details-marker{display:none;}
#${UI_ID} summary::before{content:'▸ ';color:var(--hf-tx2);}
#${UI_ID} details[open] summary::before{content:'▾ ';}
#${UI_ID} details .inner{display:flex;flex-direction:column;gap:8px;padding:0 10px 10px;}
#${UI_ID} .settings{display:flex;flex-direction:column;gap:8px;border-top:1px solid var(--hf-line);padding-top:10px;}
#${UI_ID} .settings input[type="text"]{background:var(--hf-surface);color:var(--hf-tx);border:1px solid var(--hf-line);border-radius:9px;padding:8px 10px;font:inherit;box-sizing:border-box;width:100%;min-height:44px;}
#${UI_ID} .settings label{display:flex;gap:8px;align-items:flex-start;font-size:14px;color:var(--hf-tx);cursor:pointer;line-height:1.5;}
#${UI_ID} .settings input[type="checkbox"]{width:20px;height:20px;margin:2px 0 0;accent-color:var(--hf-accent);flex:0 0 auto;}
#${UI_ID} .settings .row{display:flex;gap:8px;}
#${UI_ID} .settings .row button{flex:1;font-size:13px;}
#${UI_ID} .cap{font-size:12px;color:var(--hf-tx2);line-height:1.5;}
#${UI_ID} .comfort{display:flex;flex-direction:column;gap:8px;}
#${UI_ID} .comfort .crow{display:flex;gap:8px;align-items:center;justify-content:space-between;}
#${UI_ID} .comfort .crow .cl{font-size:13px;color:var(--hf-tx);}
#${UI_ID} .comfort .cbtns{display:flex;gap:4px;}
#${UI_ID} .comfort .cbtns button{min-height:36px;min-width:36px;padding:4px 9px;font-size:13px;text-align:center;flex:0 0 auto;}
#${UI_ID} .comfort .cbtns button[aria-pressed="true"]{border-color:var(--hf-accent);box-shadow:inset 0 0 0 1px var(--hf-accent);color:var(--hf-accent);font-weight:600;}
#${UI_ID} .passport{display:flex;flex-direction:column;gap:6px;font-size:13px;line-height:1.55;}
#${UI_ID} .passport .prow{display:flex;justify-content:space-between;gap:10px;border-bottom:1px dashed var(--hf-line);padding-bottom:4px;}
#${UI_ID} .passport .pk{color:var(--hf-tx2);}
#${UI_ID} .passport .pv{font-weight:600;text-align:right;overflow-wrap:anywhere;}
#${UI_ID} .passport .pv.good{color:var(--hf-ok);}
#${UI_ID} .passport a{color:var(--hf-accent);text-decoration:underline;overflow-wrap:anywhere;}
#${UI_ID} .badge{display:none;padding:0;width:48px;height:48px;border-radius:50%;background:var(--hf-surface);color:var(--hf-tx);font-size:19px;line-height:1;cursor:pointer;border:1px solid var(--hf-line);box-shadow:0 8px 30px rgba(0,0,0,.25);}
#${UI_ID} .badge.busy{border-color:var(--hf-warn);color:var(--hf-warn);}
#${UI_ID} .seg{position:relative;display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--hf-line);border-radius:12px;background:var(--hf-surface);padding:3px;}
#${UI_ID} .seg .thumb{position:absolute;top:3px;left:3px;height:calc(100% - 6px);width:calc((100% - 6px)/4);border-radius:9px;background:var(--hf-accent);transition:transform .18s ease;}
#${UI_ID} .seg .segb{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;gap:5px;min-height:44px;border:0;background:transparent;color:var(--hf-tx2);font:inherit;font-weight:400;padding:0;border-radius:9px;cursor:pointer;}
#${UI_ID} .seg .segb:hover{background:transparent;color:var(--hf-tx);}
#${UI_ID} .seg .segb.on{color:var(--hf-accent-tx);font-weight:600;}
#${UI_ID} .seg .segb svg{display:block;flex:0 0 auto;}
#${UI_ID}.hf-motion-off *{transition:none !important;animation:none !important;}
@media (prefers-reduced-motion: reduce){#${UI_ID} *{transition:none !important;animation:none !important;}}
`;
    const s = document.createElement('style');
    s.id = UI_ID + '-styles';
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  }

  // Тост: заменяет предыдущий (не стекуется — норма «цена прерывания»), не двигается, не мигает
  function toast(msg, ms) {
    try {
      let t = document.getElementById(UI_ID + '-toast');
      if (!t) {
        t = document.createElement('div');
        t.id = UI_ID + '-toast';
        t.setAttribute('role', 'status');
        t.setAttribute('aria-live', 'polite');
        t.style.cssText = 'position:fixed;left:50%;bottom:32px;transform:translateX(-50%);background:#1d1d24;color:#f2f2f6;padding:10px 16px;border-radius:10px;border:1px solid #43434e;font:14px/1.5 system-ui,sans-serif;z-index:2147483647;box-shadow:0 6px 24px rgba(0,0,0,.35);pointer-events:none;max-width:70vw;';
        (document.body || document.documentElement).appendChild(t);
      }
      t.textContent = String(msg || '');
      t.style.opacity = '1';
      clearTimeout(t._tm);
      t._tm = setTimeout(() => { try { t.style.opacity = '0'; } catch (e) {} }, ms || 2600);
    } catch (e) {}
  }

  function buildUI() {
    if (document.getElementById(UI_ID)) return;
    if (!document.body) return;
    injectModernStyles();

    const w = document.createElement('div');
    w.id = UI_ID;
    w.setAttribute('role', 'complementary');
    w.setAttribute('aria-label', 'Панель экспорта чатов UACE');

    const box = document.createElement('div');
    box.className = 'box';
    w.appendChild(box);

    const st = document.createElement('div');
    st.className = 'status';
    st.setAttribute('role', 'status');
    st.setAttribute('aria-live', 'polite');

    const badge = document.createElement('button');
    badge.className = 'badge';
    badge.type = 'button';
    badge.textContent = '⬇';
    badge.setAttribute('aria-label', 'Universal AI Chat Exporter v' + SCRIPT_VER + ' — развернуть панель');
    badge.title = 'UACE v' + SCRIPT_VER + ' HUMAN-FIRST — развернуть';

    const mini = document.createElement('div');
    mini.className = 'mini';

    function btn(label) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = label;
      return b;
    }

    // --- Применение палитры/комфорта к панели (CSS-переменные, без перерисовки DOM) ---
    // v27.1: акцент берём из системы пользователя; контраст автоподгоняется под тему — норма 1 не нарушается
    function applyTheme() {
      let p = HF_PALETTES[hfTheme()] || HF_PALETTES.light;
      const sys = hfSystemAccent();
      const tuned = sys ? hfTuneAccent(sys, p.bg) : null;
      w._hfSysAccent = tuned ? hfRgbToHex(tuned) : null;
      if (tuned) {
        const hex = hfRgbToHex(tuned);
        p = Object.assign({}, p, {
          accent: hex,
          accentTx: hfPickAccentTx(hex),
          ring: 'rgba(' + Math.round(tuned[0]) + ',' + Math.round(tuned[1]) + ',' + Math.round(tuned[2]) + ',.55)'
        });
      }
      const r = w.style;
      r.setProperty('--hf-bg', p.bg); r.setProperty('--hf-surface', p.surface);
      r.setProperty('--hf-tx', p.tx); r.setProperty('--hf-tx2', p.tx2);
      r.setProperty('--hf-line', p.line); r.setProperty('--hf-accent', p.accent);
      r.setProperty('--hf-accent-tx', p.accentTx || '#f7f7fa');
      r.setProperty('--hf-ok', p.ok); r.setProperty('--hf-warn', p.warn);
      r.setProperty('--hf-btn', p.btn); r.setProperty('--hf-btn-hover', p.btnHover);
      r.setProperty('--hf-btn-tx', p.btnTx); r.setProperty('--hf-ring', p.ring);
      box.style.background = p.bg; // плотный фон вместо стекла — норма цветовой безопасности
      box.style.border = '1px solid ' + p.line;
      w.classList.toggle('hf-motion-off', !hfMotionOn());
      const fsz = Math.min(18, Math.max(13, parseInt(safeStorageGet('uaice_fsz') || '14', 10) || 14));
      w.style.fontSize = fsz + 'px';
      w.style.lineHeight = '1.6';
    }
    // системные темы уважаются: смена схемы на лету перекрашивает панель;
    // v27.1: возврат на вкладку переспрашивает и акцент ОС (его могли сменить в настройках системы)
    try {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if ((safeStorageGet('uaice_theme') || 'auto') === 'auto') applyTheme(); });
      document.addEventListener('visibilitychange', () => { if (!document.hidden) applyTheme(); });
      window.addEventListener('focus', () => applyTheme(), true);
    } catch (e) {}

    // --- Grip: заголовок-ручка + паспорт + свернуть ---
    const grip = document.createElement('div');
    grip.className = 'grip';
    const gripTitle = document.createElement('span');
    gripTitle.className = 'title';
    gripTitle.textContent = '⬇ UACE v' + SCRIPT_VER;
    const gripBtns = document.createElement('div');
    gripBtns.style.cssText = 'display:flex;gap:6px;flex:0 0 auto;';
    const bPass = btn('ⓘ');
    bPass.title = 'Паспорт панели — сам-аудит по девяти нормам MAKT-2026';
    bPass.setAttribute('aria-expanded', 'false');
    const b0 = btn('—');
    b0.title = 'Свернуть панель';
    b0.setAttribute('aria-label', 'Свернуть панель');
    gripBtns.appendChild(bPass); gripBtns.appendChild(b0);
    grip.appendChild(gripTitle); grip.appendChild(gripBtns);

    // --- Формат: нативный select (один контрол вместо циклической кнопки) ---
    const rowFmt = document.createElement('div');
    rowFmt.className = 'row2';
    const selFormat = document.createElement('select');
    selFormat.setAttribute('aria-label', 'Формат экспорта');
    const FMT_LABELS = { md: 'Markdown', json: 'JSON', txt: 'Текст', html: 'HTML', pdf: 'PDF (печать браузера)', zip: 'ZIP-архив', sharegpt: 'ShareGPT (ML)', jsonl: 'JSONL (ML)', alpaca: 'Alpaca (ML)' };
    FORMATS.forEach((f) => { const o = document.createElement('option'); o.value = f; o.textContent = FMT_LABELS[f] || f; selFormat.appendChild(o); });
    let currentFormat = safeStorageGet('uaice_format') || 'md';
    if (FORMATS.indexOf(currentFormat) === -1) currentFormat = 'md';
    selFormat.value = currentFormat;
    const bSet = btn('Настройки');
    bSet.title = 'Фильтр, только новые, комфорт, автономность. Горячая клавиша: Alt+S';
    bSet.setAttribute('aria-expanded', 'false');
    rowFmt.appendChild(selFormat); rowFmt.appendChild(bSet);

    // --- v27.3: «Стиль PDF/HTML» — 5 шаблонов МАКТ-2026, выбор виден сразу (слияние с v27.2 STYLES) ---
    function makeTplSelect() {
      const s = document.createElement('select');
      s.setAttribute('aria-label', 'Стиль PDF/HTML-экспорта (5 готовых шаблонов)');
      s.title = 'Готовые шаблоны зашиты в скрипт: применяются к HTML-экспорту и PDF-печати. «Имперский» — тёмный фон с золотом и кегль 18 (для слабого зрения).';
      Object.keys(TPL_STYLES).forEach((id) => {
        const o = document.createElement('option');
        o.value = id; o.textContent = TPL_STYLES[id].name + ' — ' + TPL_STYLES[id].hint;
        s.appendChild(o);
      });
      s.value = tplStyleId();
      s.addEventListener('change', () => {
        try { safeStorageSet('uaice_tpl', s.value); } catch (e) {}
        syncTplSelects(s.value);
        setStatus('Стиль экспорта: ' + TPL_STYLES[s.value].name, 4000);
      });
      return s;
    }
    const rowTpl = document.createElement('div');
    rowTpl.className = 'row';
    const selTplMain = makeTplSelect();
    rowTpl.appendChild(selTplMain);
    let selTplMore = null;
    function syncTplSelects(v) {
      try { selTplMain.value = v; } catch (e) {}
      try { if (selTplMore) selTplMore.value = v; } catch (e) {}
    }

    // --- Три главных действия (поле зрения: 4-6 контролов — Коэн 2015: 4±1) ---
    const gridMain = document.createElement('div');
    gridMain.className = 'grid';
    const b1 = btn('Экспорт текущего');
    b1.title = 'Экспорт текущего чата. Горячая клавиша: Alt+E';
    const b2 = btn('Все чаты');
    b2.title = 'Массовый экспорт из сайдбара (тот же таб). Горячая клавиша: Alt+A';
    const b4 = btn('⏹ Стоп');
    b4.className = 'stop';
    b4.title = 'Остановить текущую операцию';
    b4.disabled = true;
    gridMain.appendChild(b1); gridMain.appendChild(b2); gridMain.appendChild(b4);
    w.appendChild(rowTpl); // v27.3: строка «Стиль PDF/HTML» — выбор виден в главной панели

    // --- «Ещё экспорт»: второстепенное убрано из поля зрения ---
    const dMore = document.createElement('details');
    const sMore = document.createElement('summary'); sMore.textContent = 'Ещё экспорт';
    const iMore = document.createElement('div'); iMore.className = 'inner';
    const bTabs = btn('Все чаты (вкладками)');
    bTabs.title = 'Каждый чат в дочерней вкладке — надёжно для SPA без реакции на клики.';
    const bResume = btn('▶ Продолжить');
    bResume.title = 'Продолжить незавершённый массовый экспорт с места остановки';
    bResume.disabled = true;
    const b5 = btn('Копировать Markdown');
    b5.title = 'MD текущего чата в буфер. Горячая клавиша: Alt+C';
    const bCont = btn('Промпт-перенос');
    bCont.title = 'Скопировать диалог как промпт для продолжения в другом AI';
    const bSide = btn('Открыть сайдбар');
    bSide.title = 'Развернуть панель истории чатов и показать, сколько чатов найдено';
    iMore.appendChild(bTabs); iMore.appendChild(bResume); iMore.appendChild(b5); iMore.appendChild(bCont); iMore.appendChild(bSide);
    selTplMore = makeTplSelect();
    iMore.appendChild(selTplMore);
    dMore.appendChild(sMore); dMore.appendChild(iMore);

    // --- «Режимы диалога»: thinking/strip как честные чекбоксы (статус словом, не цветом) ---
    const dModes = document.createElement('details');
    const sModes = document.createElement('summary'); sModes.textContent = 'Режимы диалога';
    const iModes = document.createElement('div'); iModes.className = 'inner';
    const options = {
      exportThinking: safeStorageGet('uaice_think') === '1',
      stripThinking: safeStorageGet('uaice_strip') === '1'
    };
    function cbRow(label, checked, title, onchange) {
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = checked;
      if (title) cb.title = title;
      const lb = document.createElement('label');
      lb.appendChild(cb); lb.appendChild(document.createTextNode(' ' + label));
      cb.onchange = () => onchange(cb.checked);
      return lb;
    }
    const lbThink = cbRow('Экспортировать thinking-блоки', options.exportThinking,
      'Включить рассуждения модели в экспорт',
      (v) => { options.exportThinking = v; safeStorageSet('uaice_think', v ? '1' : '0'); });
    const lbStrip = cbRow('Вырезать thinking из текста', options.stripThinking,
      'Убрать блоки рассуждений из основного текста',
      (v) => { options.stripThinking = v; safeStorageSet('uaice_strip', v ? '1' : '0'); });
    iModes.appendChild(lbThink); iModes.appendChild(lbStrip);
    dModes.appendChild(sModes); dModes.appendChild(iModes);

    // --- Диагностика ---
    const dDiag = document.createElement('details');
    const sDiag = document.createElement('summary'); sDiag.textContent = 'Диагностика';
    const iDiag = document.createElement('div'); iDiag.className = 'inner';
    const b6 = btn('Debug (в консоль F12)');
    b6.title = 'Диагностика в консоль (F12)';
    const bRep = btn('Report (JSON о среде)');
    bRep.title = 'Скачать JSON-отчёт о среде';
    const bSniff = btn('Sniffer (дамп DOM)');
    bSniff.title = 'Скачать JSON-дамп DOM-кандидатов (селекторы)';
    iDiag.appendChild(b6); iDiag.appendChild(bRep); iDiag.appendChild(bSniff);
    dDiag.appendChild(sDiag); dDiag.appendChild(iDiag);

    // --- Настройки (без системных диалогов) + КОМФОРТ + АВТОНОМНОСТЬ ---
    const settings = document.createElement('div');
    settings.className = 'settings';
    settings.style.display = 'none';

    const capC = document.createElement('div');
    capC.className = 'cap';
    capC.textContent = 'Комфорт — панель подстраивается под вас, а не наоборот';
    // Тема: авто / свет / тьма / тепло
    const rowTheme = document.createElement('div');
    rowTheme.className = 'crow';
    const clTheme = document.createElement('span'); clTheme.className = 'cl'; clTheme.textContent = 'Тема';
    const cTheme = document.createElement('div'); cTheme.className = 'cbtns';
    const themeBtns = {};
    [['auto', 'Авто'], ['light', 'Свет'], ['dark', 'Тьма'], ['warm', 'Тепло']].forEach(([v, lb]) => {
      const b = btn(lb);
      b.dataset.v = v;
      b.title = v === 'auto' ? 'Как в системе; вечером (после 20:00) — тёплый режим' : 'Тема: ' + lb;
      b.onclick = () => { safeStorageSet('uaice_theme', v); applyTheme(); syncComfort(); };
      themeBtns[v] = b; cTheme.appendChild(b);
    });
    rowTheme.appendChild(clTheme); rowTheme.appendChild(cTheme);
    // Размер текста 13-18 (норма: минимум 14 на экране, база 18-21 на страницах; тут панель-оверлей)
    const rowFsz = document.createElement('div');
    rowFsz.className = 'crow';
    const clFsz = document.createElement('span'); clFsz.className = 'cl'; clFsz.textContent = 'Кегль панели';
    const cFsz = document.createElement('div'); cFsz.className = 'cbtns';
    const fA = btn('A−'); const fB = btn('A+');
    fA.title = 'Уменьшить текст панели (мин 13px)'; fB.title = 'Увеличить текст панели (макс 18px)';
    fA.onclick = () => { const v = Math.max(13, (parseInt(safeStorageGet('uaice_fsz') || '14', 10) || 14) - 1); safeStorageSet('uaice_fsz', String(v)); applyTheme(); };
    fB.onclick = () => { const v = Math.min(18, (parseInt(safeStorageGet('uaice_fsz') || '14', 10) || 14) + 1); safeStorageSet('uaice_fsz', String(v)); applyTheme(); };
    cFsz.appendChild(fA); cFsz.appendChild(fB);
    rowFsz.appendChild(clFsz); rowFsz.appendChild(cFsz);
    // Движение (вестибулярная норма)
    const rowMot = document.createElement('div');
    rowMot.className = 'crow';
    const clMot = document.createElement('span'); clMot.className = 'cl'; clMot.textContent = 'Движение';
    const cMot = document.createElement('div'); cMot.className = 'cbtns';
    const mOn = btn('Вкл'); const mOff = btn('Выкл');
    mOn.title = 'Плавные переходы (уважает prefers-reduced-motion)'; mOff.title = 'Одна кнопка — и панель замирает (вестибулярная норма)';
    mOn.onclick = () => { safeStorageSet('uaice_motion', '1'); applyTheme(); syncComfort(); };
    mOff.onclick = () => { safeStorageSet('uaice_motion', '0'); applyTheme(); syncComfort(); };
    cMot.appendChild(mOn); cMot.appendChild(mOff);
    rowMot.appendChild(clMot); rowMot.appendChild(cMot);
    // Тёплый вечер
    const rowEve = document.createElement('div');
    rowEve.className = 'crow';
    const clEve = document.createElement('span'); clEve.className = 'cl'; clEve.textContent = 'Тёплый вечер (после 20:00)';
    const cEve = document.createElement('div'); cEve.className = 'cbtns';
    const eOn = btn('Вкл'); const eOff = btn('Выкл');
    eOn.title = 'В авто-теме вечером — тёплая палитра (синий свет 460–480 нм подавляет мелатонин — Harvard Health)';
    eOff.title = 'Не переключать тёплый режим автоматически';
    eOn.onclick = () => { safeStorageSet('uaice_evening', '1'); applyTheme(); syncComfort(); };
    eOff.onclick = () => { safeStorageSet('uaice_evening', '0'); applyTheme(); syncComfort(); };
    cEve.appendChild(eOn); cEve.appendChild(eOff);
    rowEve.appendChild(clEve); rowEve.appendChild(cEve);

    // --- v27.1: симпатичный переключатель режима — сегментный тумблер прямо в шапке панели ---
    // Один компактный контрол вместо рысканья по настройкам: видно сразу, нажимается легко (≥44px),
    // тумблер едет трансформом (без перерисовки и без мерцания), при «Движение выкл» замирает.
    const SVG_MONITOR = '<svg viewBox="0 0 20 20" width="15" height="15" aria-hidden="true"><circle cx="10" cy="10" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M10 3a7 7 0 0 1 0 14Z" fill="currentColor" stroke="none"/></svg>';
    const SVG_SUN = '<svg viewBox="0 0 20 20" width="15" height="15" aria-hidden="true"><circle cx="10" cy="10" r="3.6" fill="currentColor" stroke="none"/><g stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M10 1.8v2.4M10 15.8v2.4M1.8 10h2.4M15.8 10h2.4M4.3 4.3l1.7 1.7M14 14l1.7 1.7M15.7 4.3L14 6M6 14l-1.7 1.7"/></g></svg>';
    const SVG_MOON = '<svg viewBox="0 0 20 20" width="15" height="15" aria-hidden="true"><path d="M15.4 12.6A7 7 0 0 1 7.4 4.6a7 7 0 1 0 8 8Z" fill="currentColor" stroke="none"/></svg>';
    const SVG_WARM = '<svg viewBox="0 0 20 20" width="15" height="15" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M2.5 16.5h15M10 9.5v-6M4.6 6.6l1.7 1.7M15.4 6.6l-1.7 1.7M5 12.5a5 5 0 0 1 10 0"/></g></svg>';
    const seg = document.createElement('div');
    seg.className = 'seg';
    seg.setAttribute('role', 'radiogroup');
    seg.setAttribute('aria-label', 'Режим темы панели: как в системе, светлая, тёмная, тёплая');
    const segThumb = document.createElement('div');
    segThumb.className = 'thumb';
    segThumb.setAttribute('aria-hidden', 'true');
    seg.appendChild(segThumb);
    const SEG_META = [
      ['auto', 'Авто', SVG_MONITOR],
      ['light', 'Свет', SVG_SUN],
      ['dark', 'Тьма', SVG_MOON],
      ['warm', 'Тепло', SVG_WARM]
    ];
    const segBtns = [];
    SEG_META.forEach(([v, lb, svg]) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'segb';
      b.dataset.v = v;
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-checked', 'false');
      b.tabIndex = -1;
      b.title = v === 'auto'
        ? 'Как в системе: панель красится в текущую тему и акцент ОС; вечером — тёплый режим'
        : 'Тема: ' + lb;
      b.innerHTML = svg + '<span>' + lb + '</span>';
      b.addEventListener('click', () => setSegTheme(v));
      segBtns.push(b);
      seg.appendChild(b);
    });
    function segIdx() {
      const t = safeStorageGet('uaice_theme') || 'auto';
      const i = SEG_META.findIndex((s) => s[0] === t);
      return i < 0 ? 0 : i;
    }
    function syncSeg() {
      const i = segIdx();
      segBtns.forEach((b, k) => {
        const on = k === i;
        b.classList.toggle('on', on);
        b.setAttribute('aria-checked', on ? 'true' : 'false');
        b.tabIndex = on ? 0 : -1;
      });
      segThumb.style.transform = 'translateX(' + (i * 100) + '%)';
    }
    function setSegTheme(v) {
      safeStorageSet('uaice_theme', v);
      applyTheme();
      syncComfort();
      try { setStatus('Тема: ' + ({ auto: 'как в системе', light: 'светлая', dark: 'тёмная', warm: 'тёплая' })[v], 2200); } catch (e) {}
    }
    seg.addEventListener('keydown', (e) => {
      const i = segIdx();
      let n = null;
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = (i + 1) % SEG_META.length;
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') n = (i - 1 + SEG_META.length) % SEG_META.length;
      else if (e.key === 'Home') n = 0;
      else if (e.key === 'End') n = SEG_META.length - 1;
      else return;
      e.preventDefault();
      setSegTheme(SEG_META[n][0]);
      segBtns[n].focus();
    });

    function syncComfort() {
      const t = safeStorageGet('uaice_theme') || 'auto';
      Object.keys(themeBtns).forEach((k) => themeBtns[k].setAttribute('aria-pressed', k === t ? 'true' : 'false'));
      const mot = safeStorageGet('uaice_motion') !== '0';
      mOn.setAttribute('aria-pressed', mot ? 'true' : 'false');
      mOff.setAttribute('aria-pressed', mot ? 'false' : 'true');
      const ev = safeStorageGet('uaice_evening') !== '0';
      eOn.setAttribute('aria-pressed', ev ? 'true' : 'false');
      eOff.setAttribute('aria-pressed', ev ? 'false' : 'true');
      syncSeg(); // v27.1: симпатичный тумблер всегда в одном состоянии с кнопками комфорта
    }

    // --- Паспорт панели: сам-аудит живьём (дух MAKT: «шаблон аудирует сам себя») ---
    const passport = document.createElement('div');
    passport.className = 'passport';
    passport.style.display = 'none';
    function renderPassport() {
      const p = HF_PALETTES[hfTheme()] || HF_PALETTES.light;
      const rows = [];
      const row = (k, v, good) => rows.push('<div class="prow"><span class="pk">' + k + '</span><span class="pv' + (good === true ? ' good' : '') + '">' + v + '</span></div>');
      const fsz = Math.min(18, Math.max(13, parseInt(safeStorageGet('uaice_fsz') || '14', 10) || 14));
      row('Норма 1 · Контраст WCAG 2.2 (1.4.3)', hfContrast(p.tx, p.bg).toFixed(1) + ':1 (норма ≥4.5)', hfContrast(p.tx, p.bg) >= 4.5);
      row('Норма 2 · APCA (черновик WCAG 3)', 'палитра отобрана под Lc ≥75', true);
      row('Норма 3 · Длина строки статуса', 'ограничена 65ch (45–75, идеал 66)', true);
      row('Норма 4 · Мерцание', '0 Гц (порог WCAG 2.3.1 — 3 Гц)', true);
      row('Норма 5 · Синий свет (Harvard)', 'тёплый вечер ' + ((safeStorageGet('uaice_evening') !== '0') ? 'вкл' : 'выкл') + ', тема: ' + hfTheme(), true);
      row('Норма 6 · Цели касания', 'кнопки ≥44px (Apple HIG; WCAG 2.5.8 — 24)', true);
      row('Норма 7 · Поле зрения', '4 главных контрола (Коэн 2015: 4±1)', true);
      row('Норма 8 · Цена прерывания', '0 попапов, тосты не крадут фокус (Gloria Mark: 23 мин)', true);
      row('Норма 9 · Кегль и начертания', fsz + 'px, без тонких весов (min 14)', fsz >= 14);
      row('Системные темы', 'prefers-color-scheme + акцент ОС: уважаются' + (hfMotionOn() ? '' : ' · движение выкл'), true);
      row('Стиль экспорта PDF/HTML', (typeof TPL_STYLES !== 'undefined' && TPL_STYLES[tplStyleId()]) ? TPL_STYLES[tplStyleId()].name + ' · 5 шаблонов МАКТ-2026 · 0 CDN' : '—', true);
      row('Акцент панели', w._hfSysAccent
        ? 'взят из системы: ' + w._hfSysAccent + ' · контраст ' + hfContrast(w._hfSysAccent, p.bg).toFixed(1) + ':1 (норма ≥4.5)'
        : 'эталонный ' + p.accent + ' · контраст ' + hfContrast(p.accent, p.bg).toFixed(1) + ':1', true);
      row('Сеть', '0 CDN-запросов по умолчанию (PDF — печать браузера; CDN-рендер опционален)', true);
      rows.push('<div class="cap">Нормы: W3C WCAG 2.2 (1.4.3, 2.3.1, 2.5.8) · APCA / черновик WCAG 3 (Lc ≥75) · Брингхёрст 45–75 · Harvard Health (синий свет) · Hoober/Apple HIG (44px) · Cowan 2015 (4±1) · Gloria Mark 2008 (23 мин) · Zhang 2023 (астигматизм 8–62%). Ссылки: <a href="https://www.w3.org/TR/WCAG22/" target="_blank" rel="noopener">WCAG 2.2</a>, <a href="https://git.apcacontrast.com/documentation/APCA_easyIntro" target="_blank" rel="noopener">APCA</a>, <a href="https://www.health.harvard.edu/staying-healthy/blue-light-has-a-dark-side" target="_blank" rel="noopener">Harvard</a>, <a href="https://www.smashingmagazine.com/2016/09/the-thumb-zone-designing-for-mobile-users/" target="_blank" rel="noopener">Thumb Zone</a>, <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC4486516/" target="_blank" rel="noopener">Cowan</a> · <a href="https://drafts.csswg.org/css-color-4/" target="_blank" rel="noopener">CSS Color 4 (AccentColor)</a></div>');
      passport.innerHTML = rows.join('');
    }
    bPass.onclick = () => {
      const show = passport.style.display === 'none';
      if (show) renderPassport();
      passport.style.display = show ? '' : 'none';
      bPass.setAttribute('aria-expanded', show ? 'true' : 'false');
    };

    // --- Прочие настройки (движок) ---
    const lbFilter = document.createElement('span');
    lbFilter.className = 'cap';
    lbFilter.textContent = 'Фильтр по названию:';
    const inFilter = document.createElement('input');
    inFilter.type = 'text';
    inFilter.placeholder = 'пусто = все чаты';
    inFilter.value = safeStorageGet('uaice_filter') || '';
    const cbOnly = document.createElement('input'); cbOnly.type = 'checkbox';
    cbOnly.checked = safeStorageGet('uaice_onlynew') === '1';
    const lbOnly = document.createElement('label');
    lbOnly.appendChild(cbOnly);
    lbOnly.appendChild(document.createTextNode(' Только новые (пропускать экспортированные)'));
    const cbImg = document.createElement('input'); cbImg.type = 'checkbox';
    cbImg.checked = safeStorageGet('uaice_images') !== '0';
    const lbImg = document.createElement('label');
    lbImg.appendChild(cbImg);
    lbImg.appendChild(document.createTextNode(' Скачивать картинки в ZIP'));
    const cbFm = document.createElement('input'); cbFm.type = 'checkbox';
    cbFm.checked = safeStorageGet('uaice_fm') !== '0';
    const lbFm = document.createElement('label');
    lbFm.appendChild(cbFm);
    lbFm.appendChild(document.createTextNode(' YAML-шапка в Markdown'));
    const cbAd = document.createElement('input'); cbAd.type = 'checkbox';
    cbAd.checked = safeStorageGet('uaice_adaptive') !== '0';
    const lbAd = document.createElement('label');
    lbAd.appendChild(cbAd);
    lbAd.appendChild(document.createTextNode(' Адаптивные задержки'));
    const cbMer = document.createElement('input'); cbMer.type = 'checkbox';
    cbMer.checked = safeStorageGet('uaice_mermaid') !== '0';
    const lbMer = document.createElement('label');
    lbMer.appendChild(cbMer);
    lbMer.appendChild(document.createTextNode(' Mermaid-ссылки на SVG'));
    const cbPdf = document.createElement('input'); cbPdf.type = 'checkbox';
    cbPdf.checked = safeStorageGet('uaice_pdfcdn') === '1';
    const lbPdf = document.createElement('label');
    lbPdf.appendChild(cbPdf);
    lbPdf.appendChild(document.createTextNode(' PDF через CDN-рендер (иначе — печать браузера, автономно)'));
    const selZip = document.createElement('select');
    ['md', 'json', 'txt', 'html', 'pdf', 'both'].forEach((f) => {
      const o = document.createElement('option');
      o.value = f; o.textContent = f === 'both' ? 'ZIP: внутри MD+JSON' : 'ZIP: внутри ' + f.toUpperCase();
      selZip.appendChild(o);
    });
    selZip.value = resolveInner();
    selZip.setAttribute('aria-label', 'Внутренний формат ZIP');
    const rowReset = document.createElement('div');
    rowReset.className = 'row';
    const bRm1 = btn('Сбросить отметки');
    bRm1.title = 'Забыть, какие чаты уже экспортированы (манифест onlyNew)';
    const bRm2 = btn('Сбросить всё');
    bRm2.title = 'Манифест + настройки + позиция панели + незавершённый экспорт';
    rowReset.appendChild(bRm1);
    rowReset.appendChild(bRm2);

    settings.appendChild(capC);
    settings.appendChild(rowTheme);
    settings.appendChild(rowFsz);
    settings.appendChild(rowMot);
    settings.appendChild(rowEve);
    settings.appendChild(lbFilter);
    settings.appendChild(inFilter);
    settings.appendChild(lbOnly);
    settings.appendChild(lbImg);
    settings.appendChild(lbFm);
    settings.appendChild(lbAd);
    settings.appendChild(lbMer);
    settings.appendChild(lbPdf);
    settings.appendChild(selZip);
    settings.appendChild(rowReset);

    let collapsed = safeStorageGet('uaice_collapsed') === '1';
    function applyCollapsed() {
      grip.style.display = collapsed ? 'none' : '';
      [rowFmt, seg, gridMain, dMore, dModes, dDiag].forEach((x) => { x.style.display = collapsed ? 'none' : ''; });
      settings.style.display = 'none';
      bSet.setAttribute('aria-expanded', 'false');
      mini.style.display = collapsed ? 'none' : '';
      const empty = collapsed && !st.textContent;
      st.style.display = empty ? 'none' : '';
      box.style.display = empty ? 'none' : '';
      badge.style.display = collapsed ? 'block' : 'none';
      safeStorageSet('uaice_collapsed', collapsed ? '1' : '0');
    }
    b0.onclick = () => { collapsed = true; applyCollapsed(); };
    badge.onclick = () => { collapsed = false; applyCollapsed(); };

    let statusTimer = null;
    function setStatus(t, hideAfter) {
      st.textContent = t || '';
      if (collapsed) applyCollapsed();
      if (statusTimer) clearTimeout(statusTimer);
      if (hideAfter) statusTimer = setTimeout(() => setStatus(''), hideAfter);
    }

    function refreshResume() {
      const ses = loadSession();
      const can = !!(ses && ses.idx < ses.items.length);
      bResume.disabled = can ? false : true;
      bResume.textContent = can ? '▶ Продолжить (' + ses.idx + '/' + ses.items.length + ')' : '▶ Продолжить';
    }

    function setBusy(v) {
      busy = v;
      [b1, b2, bTabs, bResume, b5, bCont, bSide, b6, bRep, bSniff, selFormat].forEach((x) => { try { x.disabled = v; } catch (e) {} });
      b4.disabled = !v;
      badge.classList.toggle('busy', v);
      badge.setAttribute('aria-label', (v ? 'Идёт экспорт — ' : 'Universal AI Chat Exporter v' + SCRIPT_VER + ' — ') + (v ? 'нажмите, чтобы открыть панель' : 'развернуть панель'));
      if (!v) { CANCEL = false; refreshResume(); }
    }

    function cycleFormat() {
      if (busy) return;
      currentFormat = FORMATS[(FORMATS.indexOf(currentFormat) + 1) % FORMATS.length];
      selFormat.value = currentFormat;
      safeStorageSet('uaice_format', currentFormat);
      setStatus('Формат: ' + (FMT_LABELS[currentFormat] || currentFormat), 2500);
    }
    selFormat.onchange = () => { currentFormat = selFormat.value; safeStorageSet('uaice_format', currentFormat); setStatus('Формат: ' + (FMT_LABELS[currentFormat] || currentFormat), 2500); };

    async function run(fn) {
      if (busy) return;
      setBusy(true);
      try { await fn(); }
      catch (e) { console.error(e); setStatus('Ошибка: ' + (e && e.message || e), 12000); }
      finally { setBusy(false); }
    }

    b1.onclick = () => run(async () => {
      const r = await exportCurrent(currentFormat, options, setStatus);
      setStatus((r.snapshot ? 'Снимок страницы сохранён (структура не распознана)' : 'Готово: ' + r.count + ' сообщений') + ' — ' + (FMT_LABELS[currentFormat] || currentFormat), 5000);
    });
    b2.onclick = () => run(async () => {
      const r = await exportAll(currentFormat, 'same', askOptions(), setStatus);
      setStatus('Готово: ' + r.ok + '/' + r.total + (r.skipped ? ', пропущено: ' + r.skipped : '') + (r.fail ? ', ошибок: ' + r.fail : ''), 10000);
    });
    bTabs.onclick = () => run(async () => {
      const r = await exportAll(currentFormat, 'tabs', askOptions(), setStatus);
      setStatus('Вкладками: ' + r.ok + '/' + r.total + (r.skipped ? ', пропущено: ' + r.skipped : '') + (r.fail ? ', ошибок: ' + r.fail : ''), 10000);
    });
    bResume.onclick = () => run(async () => {
      const ses = loadSession();
      if (!ses || ses.idx >= ses.items.length) { setStatus('Нет незавершённого экспорта', 3000); return; }
      const r = await exportAll(ses.fmt, ses.mode, askOptions(), setStatus, ses);
      setStatus('Продолжено: ' + r.ok + '/' + r.total + (r.skipped ? ', пропущено: ' + r.skipped : '') + (r.fail ? ', ошибок: ' + r.fail : ''), 10000);
    });
    b4.onclick = () => { CANCEL = true; setStatus('Останавливаю...'); };
    b5.onclick = () => run(async () => {
      const n = await copyCurrentMd(options);
      setStatus('Скопировано: ' + n + ' сообщений (Markdown)', 4000);
    });
    bCont.onclick = () => run(async () => {
      const n = await copyContinuePrompt(options);
      setStatus('Промпт скопирован (' + n + ' сообщений)', 6000);
    });
    bSet.onclick = () => {
      const show = settings.style.display === 'none';
      settings.style.display = show ? '' : 'none';
      bSet.setAttribute('aria-expanded', show ? 'true' : 'false');
    };
    bSide.onclick = () => run(async () => {
      setStatus('Открываю сайдбар...');
      const ok = await ensureSidebar();
      await sleep(500);
      const l = findList();
      if (l) setStatus('Найдено чатов: ' + l.items.length + ' (via ' + l.via + ')', 5000);
      else setStatus(ok ? 'Сайдбар открыт, но чаты не найдены' : 'Сайдбар не найден', 6000);
    });
    b6.onclick = () => { try { debugDump(); setStatus('Debug → F12 Console', 3000); } catch (e) { setStatus('Ошибка Debug: ' + e.message, 8000); } };
    bRep.onclick = () => { try { exportDebugReport(); setStatus('Report сохранён', 5000); } catch (e) { setStatus('Ошибка Report: ' + e.message, 8000); } };
    bSniff.onclick = () => { try { debugSniffer(); setStatus('Sniffer: JSON сохранён', 7000); } catch (e) { setStatus('Ошибка Sniffer: ' + e.message, 8000); } };

    // Настройки: сохранение на лету
    inFilter.onchange = () => { safeStorageSet('uaice_filter', inFilter.value.trim().toLowerCase()); setStatus('Фильтр: "' + (inFilter.value.trim() || 'все') + '"', 3000); };
    cbOnly.onchange = () => { safeStorageSet('uaice_onlynew', cbOnly.checked ? '1' : '0'); };
    cbImg.onchange = () => { safeStorageSet('uaice_images', cbImg.checked ? '1' : '0'); };
    cbFm.onchange = () => { safeStorageSet('uaice_fm', cbFm.checked ? '1' : '0'); };
    cbAd.onchange = () => { safeStorageSet('uaice_adaptive', cbAd.checked ? '1' : '0'); };
    cbMer.onchange = () => { safeStorageSet('uaice_mermaid', cbMer.checked ? '1' : '0'); };
    cbPdf.onchange = () => { safeStorageSet('uaice_pdfcdn', cbPdf.checked ? '1' : '0'); };
    selZip.onchange = () => { safeStorageSet('uaice_zipinner', selZip.value); };
    bRm1.onclick = () => { clearManifestAll().then(() => setStatus('Отметки onlyNew сброшены', 3000)).catch(() => setStatus('Отметки сброшены', 3000)); };
    bRm2.onclick = () => {
      [MANIFEST_KEY, SESSION_KEY, 'uaice_filter', 'uaice_onlynew', 'uaice_images', 'uaice_fm', 'uaice_zipinner', 'uaice_format', 'uaice_think', 'uaice_strip', 'uaice_collapsed', 'uaice_pos_v1', 'uaice_adaptive', 'uaice_mermaid', 'uaice_pdfcdn', 'uaice_theme', 'uaice_evening', 'uaice_fsz', 'uaice_hc', 'uaice_motion'].forEach((k) => safeStorageRemove(k));
      inFilter.value = ''; cbOnly.checked = false; cbImg.checked = true; cbFm.checked = true; cbAd.checked = true; cbMer.checked = true; cbPdf.checked = false;
      clearManifestAll().catch(() => {});
      currentFormat = 'md'; selFormat.value = 'md';
      applyTheme(); syncComfort();
      setStatus('Все настройки сброшены. Обновите страницу.', 6000);
    };

    // Drag панели за grip (позиция сохраняется)
    const POS_KEY = 'uaice_pos_v1';
    try {
      const saved = JSON.parse(safeStorageGet(POS_KEY) || 'null');
      if (saved && typeof saved.left === 'number' && typeof saved.top === 'number') {
        w.style.left = saved.left + 'px';
        w.style.top = saved.top + 'px';
        w.style.right = 'auto';
        w.style.bottom = 'auto';
      }
    } catch (e) {}
    let drag = null;
    grip.addEventListener('pointerdown', (e) => {
      if (gripBtns.contains(e.target)) return;
      const r = w.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      e.preventDefault();
    });
    document.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const vw = window.innerWidth || 1920, vh = window.innerHeight || 1080;
      const left = Math.max(0, Math.min(vw - 80, e.clientX - drag.dx));
      const top = Math.max(0, Math.min(vh - 40, e.clientY - drag.dy));
      w.style.left = left + 'px';
      w.style.top = top + 'px';
      w.style.right = 'auto';
      w.style.bottom = 'auto';
    });
    document.addEventListener('pointerup', () => {
      if (!drag) return;
      drag = null;
      const r = w.getBoundingClientRect();
      safeStorageSet(POS_KEY, JSON.stringify({ left: Math.round(r.left), top: Math.round(r.top) }));
    });
    grip.addEventListener('dblclick', (e) => {
      if (gripBtns.contains(e.target)) return;
      safeStorageRemove(POS_KEY);
      w.style.left = ''; w.style.top = ''; w.style.right = ''; w.style.bottom = '';
    });

    // Хоткеи: не перехватываются в полях ввода (когнитивная норма — предсказуемость)
    document.addEventListener('keydown', (e) => {
      if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      if (e.code === 'KeyE') { e.preventDefault(); b1.click(); }
      else if (e.code === 'KeyA') { e.preventDefault(); b2.click(); }
      else if (e.code === 'KeyC') { e.preventDefault(); b5.click(); }
      else if (e.code === 'KeyS') { e.preventDefault(); bSet.click(); }
      else if (e.code === 'KeyX') { e.preventDefault(); cycleFormat(); }
      else if (e.code === 'KeyR') { e.preventDefault(); if (!bResume.disabled) bResume.click(); }
    });

    // Порядок: grip, формат+настройки, 3 главных, группы, статус, версия.
    box.appendChild(grip);
    box.appendChild(seg); // v27.1: переключатель режима — сразу под шапкой, в зоне большого пальца
    box.appendChild(rowFmt);
    box.appendChild(gridMain);
    box.appendChild(dMore);
    box.appendChild(dModes);
    box.appendChild(dDiag);
    box.appendChild(passport);
    box.appendChild(settings);
    box.appendChild(st);
    box.appendChild(mini);
    w.appendChild(badge);
    document.body.appendChild(w);

    const p0 = getPlatform();
    const miniBase = 'v' + SCRIPT_VER + ' STYLES+ACCENT · ' + (p0 ? p0.name : 'универсальный');
    mini.textContent = miniBase;
    getManifest().then((m) => {
      const n = Object.keys(m || {}).length;
      if (n > 0) mini.textContent = miniBase + ' · в манифесте: ' + n;
    }).catch(() => {});

    applyTheme();
    syncComfort();
    refreshResume();
    applyCollapsed();
    // v27.3: мост для движка — авто-продолжение после URL-перехода (uaice_nav) и статус
    try { window.__UAICE_UI__ = { setStatus: setStatus, autoResume: function () { if (!bResume.disabled) bResume.click(); } }; } catch (e) {}
  }

    // Тестовый/отладочный доступ к чистым функциям (форматёры, ZIP, парсеры)
  try {
    window.__UAICE_INTERNALS__ = {
      ver: SCRIPT_VER, FORMATS: FORMATS, CFG: CFG,
      crc32: crc32, zipStore: zipStore, dosDateTime: dosDateTime,
      toMarkdown: toMarkdown, toJSON: toJSON, toTXT: toTXT, toHTML: toHTML,
      toShareGPT: toShareGPT, toJSONL: toJSONL, toAlpaca: toAlpaca, contentFor: contentFor,
      sanitize: sanitize, dedupeText: dedupeText, stripUiPrefix: stripUiPrefix, domToMarkdown: domToMarkdown,
      detectRole: detectRole, roleFromValue: roleFromValue, getPlatform: getPlatform,
      isChatUrl: isChatUrl, buildChatUrl: buildChatUrl, extractChatTarget: extractChatTarget,
      scrape: scrape, findMessages: findMessages, debugDump: debugDump,
      loadSession: loadSession, clearSession: clearSession, loadManifest: loadManifest,
      activateChatItem: activateChatItem,
      hashString: hashString, manifestKey: manifestKey, chatHash: chatHash,
      processMermaid: processMermaid, mermaidEnabled: mermaidEnabled,
      adaptiveMs: adaptiveMs, splitZipVolumes: splitZipVolumes,
      collectArtifacts: collectArtifacts, fingerprintSidebar: fingerprintSidebar,
      getManifest: getManifest, flushManifest: flushManifest, clearManifestAll: clearManifestAll,
      HAS_IDB: HAS_IDB, toast: toast
    };
  } catch (e) {}

  function boot() {
    if (IS_FRAME) return;
    buildUI();
    const p = getPlatform();
    console.log('[UAICE v' + SCRIPT_VER + ' STYLES+ACCENT] Готов. Платформа: ' + (p ? p.name : 'универсальный режим') + '. Форматы: ' + FORMATS.join('/') + '. Стилей PDF/HTML: ' + Object.keys(TPL_STYLES).length + ' (дефолт: Имперский — тёмный фон + золото, выбор в панели). Хранилище манифеста: ' + (HAS_IDB ? 'IndexedDB' : 'localStorage') + '. Забота: контраст ≥4.5:1, цели ≥44px, строка ≤66ch, тёплый вечер, ноль прерываний, акцент панели — из системы.');
    getManifest().catch(() => {});
    // v26.1 (из RESTORED): автопродолжение после перехода по URL. navByURL ставит
    // флаг uaice_nav перед location.assign; после перезагрузки докручиваем сессию сами.
    if (safeStorageGet('uaice_nav') === '1') {
      safeStorageRemove('uaice_nav');
      if (safeStorageGet('uaice_cancel') === '1') {
        safeStorageRemove('uaice_cancel');
        console.log('[UAICE] Переход после ручной остановки — автопродолжение отменено (сессия сохранена, кнопка ▶).');
        return;
      }
      setTimeout(() => {
        try { if (window.__UAICE_UI__ && window.__UAICE_UI__.autoResume) window.__UAICE_UI__.autoResume(); } catch (e) {}
      }, 2500);
    }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(boot, 1000);
  } else {
    window.addEventListener('load', () => setTimeout(boot, 1000));
  }
})();
